#!/bin/bash

# VibeTracker Android Build Script
echo "🚀 Building VibeTracker for Android..."

# Check if Android SDK is available
if ! command -v adb &> /dev/null; then
    echo "⚠️  Android SDK not found. Please install Android Studio and set up ANDROID_HOME."
    exit 1
fi

# Build the web app
echo "📦 Building web app..."
npm run build

# Sync with Capacitor
echo "🔄 Syncing with Capacitor..."
npx cap sync

# Open Android Studio
echo "📱 Opening Android Studio..."
npx cap open android

echo "✅ Build process completed!"
echo "📋 Next steps:"
echo "   1. Android Studio will open"
echo "   2. Wait for Gradle sync to complete"
echo "   3. Build > Build Bundle(s) / APK(s) > Build APK(s)"
echo "   4. Connect your device or use emulator to test"