package com.vibetracker.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
