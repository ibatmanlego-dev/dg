'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Lock, 
  Unlock, 
  Plus, 
  Search, 
  Eye, 
  EyeOff, 
  Shield,
  Key,
  FileText,
  CreditCard,
  User,
  FileAudio
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useCapacitor } from '@/hooks/use-capacitor'
import AudioVault from '@/components/AudioVault'

interface VaultItem {
  id: string
  type: 'password' | 'note' | 'card' | 'document'
  title: string
  content: string
  category: string
  date: string
  isEncrypted: boolean
}

const categories = [
  'Personal',
  'Work',
  'Finance',
  'Health',
  'Travel',
  'Other'
]

const itemTypes = [
  { value: 'password', label: 'Password', icon: Key },
  { value: 'note', label: 'Secure Note', icon: FileText },
  { value: 'card', label: 'Payment Card', icon: CreditCard },
  { value: 'document', label: 'Document', icon: FileText }
]

interface VaultManagerProps {
  showAddForm?: boolean
  onToggleAddForm?: () => void
}

export function VaultManager({ showAddForm: externalShowAddForm, onToggleAddForm }: VaultManagerProps) {
  const { theme } = useTheme()
  const { saveFile, readFile } = useCapacitor()
  const [isUnlocked, setIsUnlocked] = useState(false)
  const [masterPassword, setMasterPassword] = useState('')
  const [internalShowAddForm, setInternalShowAddForm] = useState(false)
  
  const showAddFormState = externalShowAddForm ?? internalShowAddForm
  const setShowAddForm = onToggleAddForm ?? setInternalShowAddForm
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedType, setSelectedType] = useState('All')
  const [showContent, setShowContent] = useState<Record<string, boolean>>({})
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([
    {
      id: '1',
      type: 'password',
      title: 'Email Account',
      content: 'user@example.com\npassword: ********',
      category: 'Personal',
      date: new Date().toISOString(),
      isEncrypted: true
    }
  ])
  const [newItem, setNewItem] = useState({
    type: 'password' as const,
    title: '',
    content: '',
    category: 'Personal'
  })

  const filteredItems = vaultItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory
    const matchesType = selectedType === 'All' || item.type === selectedType
    return matchesSearch && matchesCategory && matchesType
  })

  const handleUnlock = () => {
    // Simple password check (in real app, use proper encryption)
    if (masterPassword === '1234' || masterPassword === 'password') {
      setIsUnlocked(true)
      setMasterPassword('')
    } else {
      alert('Incorrect master password')
    }
  }

  const handleLock = () => {
    setIsUnlocked(false)
    setShowContent({})
  }

  const handleAddItem = () => {
    if (newItem.title.trim() && newItem.content.trim()) {
      const item: VaultItem = {
        id: Date.now().toString(),
        type: newItem.type,
        title: newItem.title,
        content: newItem.content,
        category: newItem.category,
        date: new Date().toISOString(),
        isEncrypted: true
      }
      setVaultItems([...vaultItems, item])
      setNewItem({
        type: 'password',
        title: '',
        content: '',
        category: 'Personal'
      })
      setShowAddForm(false)
    }
  }

  const handleDeleteItem = (id: string) => {
    if (confirm('Are you sure you want to delete this item?')) {
      setVaultItems(vaultItems.filter(item => item.id !== id))
    }
  }

  const toggleContentVisibility = (id: string) => {
    setShowContent(prev => ({ ...prev, [id]: !prev[id] }))
  }

  const getItemIcon = (type: string) => {
    const itemType = itemTypes.find(t => t.value === type)
    return itemType ? itemType.icon : Lock
  }

  if (!isUnlocked) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }} className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Lock className="w-12 h-12" style={{ color: theme.primary }} />
            </div>
            <CardTitle style={{ color: theme.text }}>Secure Vault</CardTitle>
            <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
              Enter your master password to access your secure vault
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="password"
              placeholder="Master password"
              value={masterPassword}
              onChange={(e) => setMasterPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleUnlock()}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <Button
              onClick={handleUnlock}
              className="w-full"
              style={{ backgroundColor: theme.primary }}
            >
              <Unlock className="w-4 h-4 mr-2" />
              Unlock Vault
            </Button>
            <p style={{ color: theme.text, opacity: 0.5 }} className="text-xs text-center">
              Demo: Use "password" or "1234" to unlock
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-6 h-6" style={{ color: theme.primary }} />
          <h2 className="text-2xl font-bold">Secure Vault</h2>
          <Badge variant="secondary">Unlocked</Badge>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleLock}
            style={{ borderColor: theme.borderColor, color: theme.text }}
          >
            <Lock className="w-4 h-4 mr-2" />
            Lock
          </Button>
        </div>
      </div>

      {/* Vault Tabs */}
      <Tabs defaultValue="secure" className="w-full">
        <TabsList className="grid w-full grid-cols-2" style={{ backgroundColor: theme.cardBg }}>
          <TabsTrigger value="secure" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Shield className="w-4 h-4 mr-2" />
            Secure Items
          </TabsTrigger>
          <TabsTrigger value="audio" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <FileAudio className="w-4 h-4 mr-2" />
            Audio Vault
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="secure" className="space-y-6 mt-6">
          {/* Add Item Button */}
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Secure Storage</h3>
            <Button
              onClick={() => setShowAddForm(!showAddFormState)}
              style={{ backgroundColor: theme.primary }}
              className="text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Item
            </Button>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 opacity-50" />
              <Input
                placeholder="Search vault items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                style={{ 
                  backgroundColor: theme.cardBg,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="p-2 rounded border"
                style={{ 
                  backgroundColor: theme.cardBg,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              >
                <option value="All">All Types</option>
                {itemTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="p-2 rounded border"
                style={{ 
                  backgroundColor: theme.cardBg,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              >
                <option value="All">All Categories</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Add Item Form */}
          {showAddFormState && (
            <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
              <CardHeader>
                <CardTitle style={{ color: theme.text }}>Add New Vault Item</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <select
                    value={newItem.type}
                    onChange={(e) => setNewItem({ ...newItem, type: e.target.value as any })}
                    className="flex-1 p-2 rounded border"
                    style={{ 
                      backgroundColor: theme.secondary,
                      borderColor: theme.borderColor,
                      color: theme.text
                    }}
                  >
                    {itemTypes.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                  <select
                    value={newItem.category}
                    onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                    className="flex-1 p-2 rounded border"
                    style={{ 
                      backgroundColor: theme.secondary,
                      borderColor: theme.borderColor,
                      color: theme.text
                    }}
                  >
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                <Input
                  placeholder="Item title"
                  value={newItem.title}
                  onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                  style={{ 
                    backgroundColor: theme.secondary,
                    borderColor: theme.borderColor,
                    color: theme.text
                  }}
                />
                <Textarea
                  placeholder="Content (sensitive information)"
                  value={newItem.content}
                  onChange={(e) => setNewItem({ ...newItem, content: e.target.value })}
                  style={{ 
                    backgroundColor: theme.secondary,
                    borderColor: theme.borderColor,
                    color: theme.text
                  }}
                />
                <div className="flex gap-2">
                  <Button
                    onClick={handleAddItem}
                    style={{ backgroundColor: theme.primary }}
                    className="text-white"
                  >
                    Add Item
                  </Button>
                  <Button
                    variant="outline"
                      onClick={() => setShowAddForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Vault Items */}
          <div className="space-y-4">
            {filteredItems.length === 0 ? (
              <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
                <CardContent className="text-center py-8">
                  <p style={{ color: theme.text, opacity: 0.7 }}>
                    No vault items found. Start by adding your first secure item!
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredItems.map(item => {
                const Icon = getItemIcon(item.type)
                const isContentVisible = showContent[item.id]
                return (
                  <Card
                    key={item.id}
                    style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}
                    className="transition-all duration-200 hover:shadow-lg"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Icon className="w-5 h-5" style={{ color: theme.accent }} />
                            <h3 style={{ color: theme.text }} className="font-semibold">
                              {item.title}
                            </h3>
                            <Badge variant="secondary">{item.category}</Badge>
                            {item.isEncrypted && (
                              <Shield className="w-4 h-4" style={{ color: theme.primary }} />
                            )}
                          </div>
                          <div className="mb-2">
                            <div className="flex items-center gap-2 mb-1">
                              <span style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                                Content:
                              </span>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => toggleContentVisibility(item.id)}
                                className="h-6 px-2"
                              >
                                {isContentVisible ? (
                                  <EyeOff className="w-3 h-3" />
                                ) : (
                                  <Eye className="w-3 h-3" />
                                )}
                              </Button>
                            </div>
                            <div
                              style={{
                                backgroundColor: theme.secondary,
                                color: isContentVisible ? theme.text : 'transparent',
                                textShadow: isContentVisible ? 'none' : `0 0 8px ${theme.text}`,
                                userSelect: isContentVisible ? 'text' : 'none'
                              }}
                              className="p-2 rounded text-sm font-mono break-all"
                            >
                              {isContentVisible ? item.content : '••••••••••••••••••••'}
                            </div>
                          </div>
                          <div className="text-sm" style={{ color: theme.text, opacity: 0.6 }}>
                            {new Date(item.date).toLocaleDateString()}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteItem(item.id)}
                          style={{ borderColor: theme.borderColor, color: theme.text }}
                        >
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="audio" className="mt-6">
          <AudioVault />
        </TabsContent>
      </Tabs>
    </div>
  )
}