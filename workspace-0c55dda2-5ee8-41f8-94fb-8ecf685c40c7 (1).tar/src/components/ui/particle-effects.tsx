'use client'

import { useEffect, useRef } from 'react'
import { useTheme } from '@/contexts/ThemeContext'
import { useAnimation } from '@/contexts/AnimationContext'

interface Particle {
  id: number
  x: number
  y: number
  size: number
  speedX: number
  speedY: number
  opacity: number
  life: number
}

export function ParticleEffects() {
  const { theme } = useTheme()
  const { settings } = useAnimation()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const particlesRef = useRef<Particle[]>([])
  const animationRef = useRef<number>()

  useEffect(() => {
    if (!settings.enabled || !settings.particleEffects) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resizeCanvas()
    window.addEventListener('resize', resizeCanvas)

    // Create particles
    const createParticle = (): Particle => ({
      id: Math.random(),
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      size: Math.random() * 3 + 1,
      speedX: (Math.random() - 0.5) * 0.5,
      speedY: (Math.random() - 0.5) * 0.5,
      opacity: Math.random() * 0.5 + 0.2,
      life: Math.random() * 100 + 100
    })

    // Initialize particles
    const particleCount = Math.min(50, Math.floor((canvas.width * canvas.height) / 20000))
    particlesRef.current = Array.from({ length: particleCount }, createParticle)

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particlesRef.current = particlesRef.current.map(particle => {
        // Update particle position
        particle.x += particle.speedX
        particle.y += particle.speedY
        particle.life--

        // Wrap around edges
        if (particle.x < 0) particle.x = canvas.width
        if (particle.x > canvas.width) particle.x = 0
        if (particle.y < 0) particle.y = canvas.height
        if (particle.y > canvas.height) particle.y = 0

        // Respawn dead particles
        if (particle.life <= 0) {
          return createParticle()
        }

        // Draw particle
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = theme.particleColor || theme.accent
        ctx.globalAlpha = particle.opacity * (particle.life / 100)
        ctx.fill()

        // Add glow effect
        if (theme.glowColor) {
          ctx.shadowBlur = 10
          ctx.shadowColor = theme.glowColor
          ctx.fill()
          ctx.shadowBlur = 0
        }

        return particle
      })

      ctx.globalAlpha = 1
      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener('resize', resizeCanvas)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [theme, settings.enabled, settings.particleEffects])

  if (!settings.enabled || !settings.particleEffects) {
    return null
  }

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ 
        opacity: 0.6
        // No transition to prevent blinking
      }}
    />
  )
}

// Alternative CSS-based particle effect for performance
export function CSSParticles() {
  const { theme } = useTheme()
  const { settings } = useAnimation()

  if (!settings.enabled || !settings.particleEffects) {
    return null
  }

  return (
    <div className="particle-container">
      {Array.from({ length: 20 }, (_, i) => (
        <div
          key={i}
          className="particle"
          style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 10}s`,
            animationDuration: `${10 + Math.random() * 20}s`,
            backgroundColor: theme.particleColor || theme.accent,
            boxShadow: theme.glowColor ? `0 0 6px ${theme.glowColor}` : undefined
            // No transition to prevent blinking
          }}
        />
      ))}
    </div>
  )
}