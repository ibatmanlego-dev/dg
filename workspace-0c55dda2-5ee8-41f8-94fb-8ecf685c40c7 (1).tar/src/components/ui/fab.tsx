import React from 'react'
import { cn } from '@/lib/utils'
import { Button } from './button'

interface FabProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: React.ReactNode
  position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left'
  size?: 'sm' | 'md' | 'lg'
  variant?: 'primary' | 'secondary' | 'accent'
}

export function Fab({
  children,
  icon,
  className,
  position = 'bottom-right',
  size = 'md',
  variant = 'primary',
  ...props
}: FabProps) {
  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6',
    'top-right': 'top-6 right-6',
    'top-left': 'top-6 left-6',
  }

  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-14 h-14',
    lg: 'w-16 h-16',
  }

  const iconSizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-6 h-6',
    lg: 'w-7 h-7',
  }

  const variantClasses = {
    primary: 'bg-[var(--theme-primary)] hover:bg-[var(--theme-primary)]/90 text-white',
    secondary: 'bg-[var(--theme-secondary)] hover:bg-[var(--theme-secondary)]/90 text-[var(--theme-text)]',
    accent: 'bg-[var(--theme-accent)] hover:bg-[var(--theme-accent)]/90 text-white',
  }

  return (
    <Button
      className={cn(
        // Fixed positioning
        'fixed z-50',
        positionClasses[position],
        
        // Size
        sizeClasses[size],
        
        // Shape and appearance
        'rounded-full',
        'shadow-lg hover:shadow-xl',
        'transition-all duration-300 ease-in-out',
        
        // Variant
        variantClasses[variant],
        
        // Effects
        'hover:scale-110 active:scale-95',
        
        className
      )}
      {...props}
    >
      <span className={cn('flex items-center justify-center', iconSizeClasses[size])}>
        {icon}
      </span>
      {children}
    </Button>
  )
}