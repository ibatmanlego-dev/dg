'use client'

import React, { useState } from 'react'
import { useTheme } from '@/contexts/ThemeContext'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { 
  Sliders, 
  Palette, 
  Download, 
  Upload, 
  RefreshCw,
  Square,
  Circle,
  Hexagon
} from 'lucide-react'

interface ButtonStyle {
  borderRadius: string
  padding: string
  fontSize: string
  fontWeight: string
  shadow: boolean
  border: boolean
  background: string
  color: string
}

const defaultButtonStyle: ButtonStyle = {
  borderRadius: '0.5rem',
  padding: '0.5rem 1rem',
  fontSize: '0.875rem',
  fontWeight: '500',
  shadow: true,
  border: false,
  background: '',
  color: ''
}

export function ButtonCustomizer() {
  const { theme } = useTheme()
  const [buttonStyle, setButtonStyle] = useState<ButtonStyle>(defaultButtonStyle)
  const [previewText, setPreviewText] = useState('Click Me')

  const updateStyle = (key: keyof ButtonStyle, value: any) => {
    setButtonStyle(prev => ({ ...prev, [key]: value }))
  }

  const getButtonStyle = () => {
    return {
      borderRadius: buttonStyle.borderRadius,
      padding: buttonStyle.padding,
      fontSize: buttonStyle.fontSize,
      fontWeight: buttonStyle.fontWeight,
      boxShadow: buttonStyle.shadow ? '0 4px 6px -1px rgba(0, 0, 0, 0.1)' : 'none',
      border: buttonStyle.border ? `1px solid ${theme.borderColor}` : 'none',
      backgroundColor: buttonStyle.background || theme.primary,
      color: buttonStyle.color || '#ffffff',
      transition: 'all 0.2s ease'
    }
  }

  const exportButtonStyle = () => {
    const dataStr = JSON.stringify(buttonStyle, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'button-style.json'
    link.click()
    URL.revokeObjectURL(url)
  }

  const importButtonStyle = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string)
          setButtonStyle(data)
        } catch (error) {
          alert('Invalid button style file')
        }
      }
      reader.readAsText(file)
    }
  }

  const resetStyle = () => {
    setButtonStyle(defaultButtonStyle)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Sliders className="w-6 h-6" style={{ color: theme.accent }} />
          <h3 className="text-xl font-semibold" style={{ color: theme.text }}>
            Button Customizer
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={resetStyle}
            className="flex items-center gap-1"
          >
            <RefreshCw className="w-4 h-4" />
            Reset
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Controls */}
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
              <Palette className="w-5 h-5" />
              Style Properties
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Border Radius */}
            <div>
              <Label style={{ color: theme.text }}>Border Radius</Label>
              <Input
                type="text"
                value={buttonStyle.borderRadius}
                onChange={(e) => updateStyle('borderRadius', e.target.value)}
                placeholder="0.5rem"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text,
                  marginTop: '0.5rem'
                }}
              />
            </div>

            {/* Padding */}
            <div>
              <Label style={{ color: theme.text }}>Padding</Label>
              <Input
                type="text"
                value={buttonStyle.padding}
                onChange={(e) => updateStyle('padding', e.target.value)}
                placeholder="0.5rem 1rem"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text,
                  marginTop: '0.5rem'
                }}
              />
            </div>

            {/* Font Size */}
            <div>
              <Label style={{ color: theme.text }}>Font Size</Label>
              <Input
                type="text"
                value={buttonStyle.fontSize}
                onChange={(e) => updateStyle('fontSize', e.target.value)}
                placeholder="0.875rem"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text,
                  marginTop: '0.5rem'
                }}
              />
            </div>

            {/* Font Weight */}
            <div>
              <Label style={{ color: theme.text }}>Font Weight</Label>
              <select
                value={buttonStyle.fontWeight}
                onChange={(e) => updateStyle('fontWeight', e.target.value)}
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text,
                  marginTop: '0.5rem',
                  width: '100%',
                  padding: '0.5rem'
                }}
              >
                <option value="400">Normal</option>
                <option value="500">Medium</option>
                <option value="600">Semibold</option>
                <option value="700">Bold</option>
              </select>
            </div>

            {/* Background Color */}
            <div>
              <Label style={{ color: theme.text }}>Background Color</Label>
              <div className="flex gap-2" style={{ marginTop: '0.5rem' }}>
                <Input
                  type="color"
                  value={buttonStyle.background || theme.primary}
                  onChange={(e) => updateStyle('background', e.target.value)}
                  style={{ backgroundColor: theme.secondary, borderColor: theme.borderColor }}
                />
                <Input
                  type="text"
                  value={buttonStyle.background || theme.primary}
                  onChange={(e) => updateStyle('background', e.target.value)}
                  placeholder="#000000"
                  style={{ 
                    backgroundColor: theme.secondary,
                    borderColor: theme.borderColor,
                    color: theme.text
                  }}
                />
              </div>
            </div>

            {/* Text Color */}
            <div>
              <Label style={{ color: theme.text }}>Text Color</Label>
              <div className="flex gap-2" style={{ marginTop: '0.5rem' }}>
                <Input
                  type="color"
                  value={buttonStyle.color || '#ffffff'}
                  onChange={(e) => updateStyle('color', e.target.value)}
                  style={{ backgroundColor: theme.secondary, borderColor: theme.borderColor }}
                />
                <Input
                  type="text"
                  value={buttonStyle.color || '#ffffff'}
                  onChange={(e) => updateStyle('color', e.target.value)}
                  placeholder="#ffffff"
                  style={{ 
                    backgroundColor: theme.secondary,
                    borderColor: theme.borderColor,
                    color: theme.text
                  }}
                />
              </div>
            </div>

            {/* Toggle Switches */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label style={{ color: theme.text }}>Shadow</Label>
                <Switch
                  checked={buttonStyle.shadow}
                  onCheckedChange={(checked) => updateStyle('shadow', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label style={{ color: theme.text }}>Border</Label>
                <Switch
                  checked={buttonStyle.border}
                  onCheckedChange={(checked) => updateStyle('border', checked)}
                />
              </div>
            </div>

            {/* Preview Text */}
            <div>
              <Label style={{ color: theme.text }}>Preview Text</Label>
              <Input
                type="text"
                value={previewText}
                onChange={(e) => setPreviewText(e.target.value)}
                placeholder="Button text"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text,
                  marginTop: '0.5rem'
                }}
              />
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardHeader>
            <CardTitle style={{ color: theme.text }}>Preview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Button Preview */}
            <div className="space-y-4">
              <div>
                <p style={{ color: theme.text, opacity: 0.8, marginBottom: '1rem' }}>Button Preview:</p>
                <div className="flex justify-center">
                  <button style={getButtonStyle()}>
                    {previewText}
                  </button>
                </div>
              </div>

              {/* Different States */}
              <div>
                <p style={{ color: theme.text, opacity: 0.8, marginBottom: '1rem' }}>Different Sizes:</p>
                <div className="space-y-2">
                  <button style={{...getButtonStyle(), padding: '0.25rem 0.5rem', fontSize: '0.75rem'}}>
                    Small
                  </button>
                  <button style={getButtonStyle()}>
                    {previewText}
                  </button>
                  <button style={{...getButtonStyle(), padding: '0.75rem 1.5rem', fontSize: '1rem'}}>
                    Large
                  </button>
                </div>
              </div>

              {/* Shape Variants */}
              <div>
                <p style={{ color: theme.text, opacity: 0.8, marginBottom: '1rem' }}>Shape Variants:</p>
                <div className="flex gap-2">
                  <button style={{...getButtonStyle(), borderRadius: '0'}}>
                    <Square className="w-4 h-4" />
                  </button>
                  <button style={getButtonStyle()}>
                    <Circle className="w-4 h-4" />
                  </button>
                  <button style={{...getButtonStyle(), borderRadius: '0.25rem'}}>
                    <Hexagon className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Export/Import */}
            <div className="space-y-3">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={exportButtonStyle}
                  className="flex items-center gap-2 flex-1"
                >
                  <Download className="w-4 h-4" />
                  Export Style
                </Button>
                <div className="relative flex-1">
                  <input
                    type="file"
                    accept=".json"
                    onChange={importButtonStyle}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <Button
                    variant="outline"
                    className="w-full flex items-center gap-2"
                  >
                    <Upload className="w-4 h-4" />
                    Import Style
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}