import React from 'react'
import { cn } from '@/lib/utils'
import { Button } from './button'

interface NavItem {
  id: string
  label: string
  icon: React.ReactNode
  active?: boolean
  onClick: () => void
}

interface BottomNavProps {
  items: NavItem[]
  className?: string
}

export function BottomNav({ items, className }: BottomNavProps) {
  return (
    <nav
      className={cn(
        // Fixed positioning
        'fixed bottom-0 left-0 right-0 z-40',
        
        // Glassmorphism background
        'bg-[var(--theme-card-bg)]',
        'backdrop-blur-lg',
        'border-t border-[var(--theme-border-color)]',
        
        // Layout
        'flex items-center justify-around',
        'px-2 py-2',
        
        // Safe area for mobile
        'pb-safe',
        
        className
      )}
    >
      {items.map((item) => (
        <Button
          key={item.id}
          variant="ghost"
          size="sm"
          onClick={item.onClick}
          className={cn(
            // Base styles
            'flex flex-col items-center gap-1',
            'px-3 py-2',
            'rounded-lg',
            'transition-all duration-200 ease-in-out',
            
            // Text styles
            'text-xs',
            
            // Active state
            item.active
              ? 'text-[var(--theme-primary)] bg-[var(--theme-primary)]/10'
              : 'text-[var(--theme-text)]/95 hover:text-[var(--theme-text)] hover:bg-[var(--theme-secondary)]/20',
            
            // Mobile-friendly touch target
            'min-h-[44px] min-w-[44px]'
          )}
        >
          <span className={cn(
            'flex items-center justify-center',
            'w-5 h-5',
            item.active ? 'text-[var(--theme-primary)]' : 'text-[var(--theme-text)]/95'
          )}>
            {item.icon}
          </span>
          <span className="text-xs font-medium">
            {item.label}
          </span>
        </Button>
      ))}
    </nav>
  )
}