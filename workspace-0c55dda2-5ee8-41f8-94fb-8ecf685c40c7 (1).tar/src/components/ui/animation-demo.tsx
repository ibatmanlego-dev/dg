'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useTheme } from '@/contexts/ThemeContext'
import { useAnimation } from '@/contexts/AnimationContext'
import { 
  Sparkles, 
  Zap, 
  Eye, 
  EyeOff,
  Play,
  Pause,
  Settings
} from 'lucide-react'

export function AnimationDemo() {
  const { theme } = useTheme()
  const { settings, toggleAnimations } = useAnimation()
  const [isAnimating, setIsAnimating] = useState(false)

  const handleDemoAnimation = () => {
    setIsAnimating(true)
    setTimeout(() => setIsAnimating(false), 2000)
  }

  return (
    <div className="space-y-6">
      {/* Animation Status */}
      <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
            <Settings className="w-5 h-5" />
            Animation Control Demo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {settings.enabled ? (
                <Eye className="w-5 h-5" style={{ color: theme.primary }} />
              ) : (
                <EyeOff className="w-5 h-5" style={{ color: theme.text, opacity: 0.5 }} />
              )}
              <div>
                <p style={{ color: theme.text }} className="font-medium">
                  Animations {settings.enabled ? 'Enabled' : 'Disabled'}
                </p>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                  Performance: {settings.performanceMode}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge 
                variant={settings.enabled ? 'default' : 'secondary'}
                className={settings.enabled ? 'bg-green-500' : ''}
              >
                {settings.enabled ? 'Active' : 'Inactive'}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={toggleAnimations}
                className="flex items-center gap-2"
              >
                {settings.enabled ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {settings.enabled ? 'Disable' : 'Enable'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Demo Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Hover Demo */}
        <Card 
          className={`cursor-pointer ${settings.hoverEffects ? 'hover:transform hover:-translate-y-2' : ''}`}
          style={{ 
            backgroundColor: theme.cardBg, 
            borderColor: theme.borderColor,
            transition: settings.enabled ? settings.customTransitions.hover : 'none'
          }}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
              <Sparkles className="w-5 h-5" />
              Hover Effect
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p style={{ color: theme.text, opacity: 0.8 }}>
              Hover over this card to see the animation effect. {settings.hoverEffects ? 'Effects are enabled!' : 'Effects are disabled.'}
            </p>
          </CardContent>
        </Card>

        {/* Click Demo */}
        <Card 
          className={`cursor-pointer ${settings.enabled ? 'animate-click' : ''}`}
          style={{ 
            backgroundColor: theme.cardBg, 
            borderColor: theme.borderColor,
            transition: settings.enabled ? settings.customTransitions.click : 'none'
          }}
          onClick={handleDemoAnimation}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
              <Zap className="w-5 h-5" />
              Click Animation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p style={{ color: theme.text, opacity: 0.8 }}>
              Click this card to trigger a click animation. {settings.enabled ? 'Click me!' : 'Animations disabled.'}
            </p>
            {isAnimating && (
              <div className="mt-2">
                <Badge variant="default" className="bg-blue-500">
                  Animating...
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Animation Settings Summary */}
      <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
        <CardHeader>
          <CardTitle style={{ color: theme.text }}>Current Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl mb-1">{settings.duration}ms</div>
              <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Duration</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-1">{settings.performanceMode}</div>
              <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Performance</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-1">{settings.particleEffects ? '✓' : '✗'}</div>
              <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Particles</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-1">{settings.hoverEffects ? '✓' : '✗'}</div>
              <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Hover</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Custom Transitions Display */}
      <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
        <CardHeader>
          <CardTitle style={{ color: theme.text }}>Custom Transitions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span style={{ color: theme.text, opacity: 0.8 }}>Enter:</span>
              <code style={{ color: theme.primary, fontSize: '0.875rem' }}>
                {settings.customTransitions.enter}
              </code>
            </div>
            <div className="flex justify-between">
              <span style={{ color: theme.text, opacity: 0.8 }}>Exit:</span>
              <code style={{ color: theme.primary, fontSize: '0.875rem' }}>
                {settings.customTransitions.exit}
              </code>
            </div>
            <div className="flex justify-between">
              <span style={{ color: theme.text, opacity: 0.8 }}>Hover:</span>
              <code style={{ color: theme.primary, fontSize: '0.875rem' }}>
                {settings.customTransitions.hover}
              </code>
            </div>
            <div className="flex justify-between">
              <span style={{ color: theme.text, opacity: 0.8 }}>Click:</span>
              <code style={{ color: theme.primary, fontSize: '0.875rem' }}>
                {settings.customTransitions.click}
              </code>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}