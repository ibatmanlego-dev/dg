'use client'

import { forwardRef } from 'react'
import { cn } from '@/lib/utils'
import { useTheme } from '@/contexts/ThemeContext'
import { useAnimation } from '@/contexts/AnimationContext'

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'dark' | 'neon' | 'enhanced'
  glow?: boolean
  float?: boolean
}

const GlassCard = forwardRef<HTMLDivElement, GlassCardProps>(
  ({ className, variant = 'default', glow = false, float = false, children, ...props }, ref) => {
    const { theme } = useTheme()
    const { settings } = useAnimation()

    const getCardClasses = () => {
      const baseClasses = 'relative overflow-hidden'
      
      // Only add transition classes if animations are enabled
      const transitionClasses = settings.enabled ? 'animate-hover' : ''
      
      const variantClasses = {
        default: 'glass-card',
        dark: 'glass-card-dark',
        neon: 'neon-border',
        enhanced: 'enhanced-card'
      }

      const effectClasses = []
      if (glow) effectClasses.push('shadow-2xl')
      if (float && settings.hoverEffects) effectClasses.push('hover:transform hover:-translate-y-2')

      return cn(
        baseClasses,
        transitionClasses,
        variantClasses[variant],
        ...effectClasses,
        className
      )
    }

    const getCardStyle = () => {
      const baseStyle = {
        background: variant === 'enhanced' ? theme.cardBg : undefined,
        borderColor: theme.borderColor,
        ...(glow && { boxShadow: `0 8px 32px ${theme.shadowColor}` })
      }

      // Instant changes - no transitions or blurs
      return baseStyle
    }

    return (
      <div
        ref={ref}
        className={getCardClasses()}
        style={getCardStyle()}
        {...props}
      >
        {/* Shimmer effect - disabled to prevent blinking */}
        {/* {settings.enabled && (
          <div className="absolute inset-0 opacity-0 hover:opacity-100 animate-enter">
            <div 
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-12 -translate-x-full hover:translate-x-full"
              style={{
                transition: settings.customTransitions.enter
              }}
            />
          </div>
        )} */}
        
        {/* Glow effect - simplified without blur */}
        {glow && theme.glowColor && (
          <div 
            className="absolute inset-0 rounded-lg opacity-10"
            style={{
              background: `radial-gradient(circle at center, ${theme.glowColor} 0%, transparent 70%)`
            }}
          />
        )}
        
        {children}
      </div>
    )
  }
)

GlassCard.displayName = 'GlassCard'

export { GlassCard }