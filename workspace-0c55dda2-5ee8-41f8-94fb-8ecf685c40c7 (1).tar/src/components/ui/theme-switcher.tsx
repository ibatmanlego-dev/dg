'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useTheme } from '@/contexts/ThemeContext'
import { cn } from '@/lib/utils'
import { Palette, Sparkles, Eye, Settings, Sliders } from 'lucide-react'
import { ThemeCustomizer } from '@/components/theme/theme-customizer'

export function ThemeSwitcher() {
  const { theme, themeName, setTheme, themes, isTransitioning, customTheme } = useTheme()
  const [isOpen, setIsOpen] = useState(false)
  const [showCustomizer, setShowCustomizer] = useState(false)
  const [previewTheme, setPreviewTheme] = useState<string | null>(null)

  const handleThemePreview = (themeKey: string) => {
    setPreviewTheme(themeKey)
    setTheme(themeKey)
  }

  const handleThemeSelect = (themeKey: string) => {
    setTheme(themeKey)
    setIsOpen(false)
    setPreviewTheme(null)
  }

  const handleMouseLeave = () => {
    if (previewTheme && previewTheme !== themeName) {
      setTheme(themeName)
      setPreviewTheme(null)
    }
  }

  if (showCustomizer) {
    return (
      <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
        <div className="absolute inset-4 bg-black/80 rounded-2xl border border-white/20 overflow-y-auto">
          <div className="sticky top-0 bg-black/90 border-b border-white/20 p-4 flex justify-between items-center">
            <h2 className="text-xl font-bold text-white">Theme Customizer</h2>
            <Button
              onClick={() => setShowCustomizer(false)}
              variant="outline"
              size="sm"
              className="text-white border-white/20 hover:bg-white/10"
            >
              Close
            </Button>
          </div>
          <div className="p-4">
            <ThemeCustomizer />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="relative">
      {/* Theme Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        variant="outline"
        size="sm"
        className={cn(
          "glass-card neon-border relative overflow-hidden group",
          isTransitioning && "animate-pulse"
        )}
        style={{
          borderColor: theme.glowColor,
          boxShadow: `0 0 20px ${theme.shadowColor}`
        }}
      >
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4" style={{ color: theme.accent }} />
          <span className="text-sm font-medium">
            {customTheme ? customTheme.displayName : theme.displayName}
          </span>
          {customTheme && (
            <div className="w-2 h-2 rounded-full bg-green-500" />
          )}
          <Sparkles className="w-3 h-3" style={{ color: theme.particleColor }} />
        </div>
      </Button>

      {/* Theme Dropdown */}
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 z-50 min-w-80">
          <Card className="glass-card enhanced-card border-2" style={{ borderColor: theme.glowColor }}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Eye className="w-5 h-5" style={{ color: theme.accent }} />
                  Visual Masterpiece Themes
                </CardTitle>
                <Button
                  onClick={() => {
                    setShowCustomizer(true)
                    setIsOpen(false)
                  }}
                  variant="outline"
                  size="sm"
                  className="text-xs px-2 py-1"
                  style={{ borderColor: theme.accent, color: theme.accent }}
                >
                  <Sliders className="w-3 h-3 mr-1" />
                  Customize
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                {Object.entries(themes).map(([key, themeOption]) => (
                  <div
                    key={key}
                    className="group relative"
                    onMouseLeave={handleMouseLeave}
                  >
                    <Button
                      variant={themeName === key && !customTheme ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleThemeSelect(key)}
                      onMouseEnter={() => handleThemePreview(key)}
                      className={cn(
                        "w-full h-auto p-3 flex flex-col items-center gap-2",
                        "glass-card hover:neon-border",
                        themeName === key && !customTheme && "ring-2 ring-offset-2"
                      )}
                      style={{
                        borderColor: themeName === key && !customTheme ? themeOption.glowColor : themeOption.borderColor,
                        backgroundColor: themeName === key && !customTheme ? themeOption.primary : themeOption.cardBg,
                        ...(themeName === key && !customTheme && {
                          boxShadow: `0 0 25px ${themeOption.glowColor}`
                        })
                      }}
                    >
                      {/* Theme Preview */}
                      <div className="w-full h-8 rounded-md overflow-hidden relative">
                        <div 
                          className="w-full h-full"
                          style={{
                            background: themeOption.gradientBg || themeOption.bg
                          }}
                        />
                      </div>
                      
                      {/* Theme Name */}
                      <span className="text-xs font-medium text-center">
                        {themeOption.displayName}
                      </span>
                      
                      {/* Active Indicator */}
                      {themeName === key && !customTheme && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full"
                             style={{ backgroundColor: themeOption.accent }} />
                      )}
                    </Button>
                  </div>
                ))}
              </div>
              
              {/* Custom Theme Indicator */}
              {customTheme && (
                <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                  <div className="flex items-center gap-2 text-sm text-green-400">
                    <Settings className="w-4 h-4" />
                    <span>Custom Theme Active: {customTheme.displayName}</span>
                  </div>
                </div>
              )}
              
              {/* Visual Effects Legend */}
              <div className="text-xs space-y-1 pt-2 border-t border-opacity-20" 
                   style={{ borderColor: theme.borderColor }}>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.particleColor }} />
                  <span style={{ opacity: 0.7 }}>Static Colors</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.glowColor }} />
                  <span style={{ opacity: 0.7 }}>Neon Glow</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-500" />
                  <span style={{ opacity: 0.7 }}>Instant Themes</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}