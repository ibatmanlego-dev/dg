'use client'

import { useState, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Mic, 
  Square, 
  Play, 
  Pause, 
  Upload, 
  Trash2, 
  Download,
  Clock,
  FileAudio,
  Tag
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface AudioItem {
  id: string
  title: string
  content: string
  duration: number
  fileSize: number
  mimeType: string
  tags: string[]
  createdAt: string
}

export default function AudioVault() {
  const [audioItems, setAudioItems] = useState<AudioItem[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [isPlaying, setIsPlaying] = useState<string | null>(null)
  const [recordingTime, setRecordingTime] = useState(0)
  const [uploadTitle, setUploadTitle] = useState('')
  const [uploadTags, setUploadTags] = useState('')
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [recordingBlob, setRecordingBlob] = useState<Blob | null>(null)
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null)
  
  const { toast } = useToast()

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      
      const chunks: Blob[] = []
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data)
        }
      }
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' })
        setRecordingBlob(blob)
        stream.getTracks().forEach(track => track.stop())
      }
      
      mediaRecorder.start()
      setIsRecording(true)
      setRecordingTime(0)
      
      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1)
      }, 1000)
      
    } catch (error) {
      toast({
        title: "Recording Error",
        description: "Could not access microphone. Please check permissions.",
        variant: "destructive"
      })
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
      
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current)
      }
    }
  }

  const saveRecording = async () => {
    if (!recordingBlob || !uploadTitle) {
      toast({
        title: "Missing Information",
        description: "Please provide a title for your recording.",
        variant: "destructive"
      })
      return
    }

    const reader = new FileReader()
    reader.onloadend = async () => {
      const base64Audio = reader.result as string
      
      const newAudioItem: AudioItem = {
        id: Date.now().toString(),
        title: uploadTitle,
        content: base64Audio,
        duration: recordingTime,
        fileSize: recordingBlob.size,
        mimeType: recordingBlob.type,
        tags: uploadTags.split(',').map(tag => tag.trim()).filter(Boolean),
        createdAt: new Date().toISOString()
      }
      
      setAudioItems(prev => [newAudioItem, ...prev])
      setRecordingBlob(null)
      setUploadTitle('')
      setUploadTags('')
      setRecordingTime(0)
      
      toast({
        title: "Recording Saved",
        description: "Your audio has been saved to the vault."
      })
    }
    
    reader.readAsDataURL(recordingBlob)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.type.startsWith('audio/')) {
      setAudioFile(file)
      setUploadTitle(file.name.replace(/\.[^/.]+$/, ''))
    } else {
      toast({
        title: "Invalid File",
        description: "Please select a valid audio file.",
        variant: "destructive"
      })
    }
  }

  const uploadAudioFile = async () => {
    if (!audioFile || !uploadTitle) {
      toast({
        title: "Missing Information",
        description: "Please provide a title for your audio file.",
        variant: "destructive"
      })
      return
    }

    const reader = new FileReader()
    reader.onloadend = async () => {
      const base64Audio = reader.result as string
      
      // Get audio duration
      const tempAudio = new Audio(base64Audio)
      tempAudio.addEventListener('loadedmetadata', () => {
        const newAudioItem: AudioItem = {
          id: Date.now().toString(),
          title: uploadTitle,
          content: base64Audio,
          duration: Math.round(tempAudio.duration),
          fileSize: audioFile.size,
          mimeType: audioFile.type,
          tags: uploadTags.split(',').map(tag => tag.trim()).filter(Boolean),
          createdAt: new Date().toISOString()
        }
        
        setAudioItems(prev => [newAudioItem, ...prev])
        setAudioFile(null)
        setUploadTitle('')
        setUploadTags('')
        
        toast({
          title: "File Uploaded",
          description: "Your audio file has been saved to the vault."
        })
      })
    }
    
    reader.readAsDataURL(audioFile)
  }

  const playAudio = (audioItem: AudioItem) => {
    if (audioRef.current) {
      if (isPlaying === audioItem.id) {
        audioRef.current.pause()
        setIsPlaying(null)
      } else {
        audioRef.current.src = audioItem.content
        audioRef.current.play()
        setIsPlaying(audioItem.id)
        
        audioRef.current.onended = () => {
          setIsPlaying(null)
        }
      }
    }
  }

  const deleteAudio = (id: string) => {
    setAudioItems(prev => prev.filter(item => item.id !== id))
    toast({
      title: "Audio Deleted",
      description: "The audio has been removed from your vault."
    })
  }

  const downloadAudio = (audioItem: AudioItem) => {
    const link = document.createElement('a')
    link.href = audioItem.content
    link.download = `${audioItem.title}.webm`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <FileAudio className="w-5 h-5 text-primary" />
        <h2 className="text-xl font-semibold">Audio Vault</h2>
      </div>

      {/* Recording Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="w-5 h-5" />
            Record Audio
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Button
              onClick={isRecording ? stopRecording : startRecording}
              variant={isRecording ? "destructive" : "default"}
              className="flex items-center gap-2"
            >
              {isRecording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              {isRecording ? "Stop Recording" : "Start Recording"}
            </Button>
            
            {isRecording && (
              <div className="flex items-center gap-2 text-red-500">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="font-mono">{formatTime(recordingTime)}</span>
              </div>
            )}
          </div>

          {recordingBlob && (
            <div className="space-y-4 p-4 border rounded-lg">
              <div className="flex items-center gap-2 text-green-600">
                <Clock className="w-4 h-4" />
                <span>Recording completed: {formatTime(recordingTime)}</span>
              </div>
              
              <div>
                <Label htmlFor="recording-title">Title</Label>
                <Input
                  id="recording-title"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="Enter recording title..."
                />
              </div>
              
              <div>
                <Label htmlFor="recording-tags">Tags (comma-separated)</Label>
                <Input
                  id="recording-tags"
                  value={uploadTags}
                  onChange={(e) => setUploadTags(e.target.value)}
                  placeholder="personal, memo, idea..."
                />
              </div>
              
              <Button onClick={saveRecording} className="w-full">
                Save Recording
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload Audio File
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="audio-file">Select Audio File</Label>
            <Input
              id="audio-file"
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
            />
          </div>
          
          {audioFile && (
            <div className="space-y-4 p-4 border rounded-lg">
              <div className="flex items-center gap-2 text-blue-600">
                <FileAudio className="w-4 h-4" />
                <span>File: {audioFile.name}</span>
                <span className="text-sm text-muted-foreground">
                  ({formatFileSize(audioFile.size)})
                </span>
              </div>
              
              <div>
                <Label htmlFor="upload-title">Title</Label>
                <Input
                  id="upload-title"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="Enter title..."
                />
              </div>
              
              <div>
                <Label htmlFor="upload-tags">Tags (comma-separated)</Label>
                <Input
                  id="upload-tags"
                  value={uploadTags}
                  onChange={(e) => setUploadTags(e.target.value)}
                  placeholder="music, podcast, lecture..."
                />
              </div>
              
              <Button onClick={uploadAudioFile} className="w-full">
                Upload File
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Audio List */}
      <Card>
        <CardHeader>
          <CardTitle>Your Audio Collection ({audioItems.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {audioItems.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileAudio className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No audio files yet. Start recording or upload a file.</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {audioItems.map((item) => (
                <div key={item.id} className="flex items-center gap-4 p-4 border rounded-lg">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => playAudio(item)}
                    className="flex items-center gap-2"
                  >
                    {isPlaying === item.id ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                    {isPlaying === item.id ? "Pause" : "Play"}
                  </Button>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium truncate">{item.title}</h4>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{formatTime(item.duration)}</span>
                      <span>{formatFileSize(item.fileSize)}</span>
                      <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                    </div>
                    {item.tags.length > 0 && (
                      <div className="flex items-center gap-1 mt-1">
                        <Tag className="w-3 h-3 text-muted-foreground" />
                        {item.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadAudio(item)}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteAudio(item.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Hidden audio element for playback */}
      <audio ref={audioRef} className="hidden" />
    </div>
  )
}