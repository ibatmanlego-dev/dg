'use client'

import React, { useState } from 'react'
import { useTheme } from '@/contexts/ThemeContext'
import { GlassCard } from '@/components/ui/glass-card'
import { 
  Palette, 
  Download, 
  Upload, 
  RefreshCw, 
  Plus,
  Eye,
  EyeOff,
  Sliders,
  Sparkles,
  Save,
  Trash2
} from 'lucide-react'

interface ColorPickerProps {
  label: string
  value: string
  onChange: (color: string) => void
  showPreview?: boolean
}

const ColorPicker: React.FC<ColorPickerProps> = ({ label, value, onChange, showPreview = true }) => {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10">
      <label className="text-sm font-medium text-white/80">{label}</label>
      <div className="flex items-center gap-2">
        {showPreview && (
          <div 
            className="w-6 h-6 rounded-full border-2 border-white/20"
            style={{ backgroundColor: value }}
          />
        )}
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-12 h-8 rounded cursor-pointer bg-transparent"
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-20 px-2 py-1 text-xs bg-white/10 border border-white/20 rounded text-white/80"
        />
      </div>
    </div>
  )
}

export function ThemeCustomizer() {
  const { 
    theme, 
    themes, 
    themeName, 
    setTheme, 
    updateThemeColor, 
    resetThemeColors, 
    exportTheme, 
    importTheme,
    createCustomTheme,
    customTheme
  } = useTheme()
  
  const [activeTab, setActiveTab] = useState<'presets' | 'colors' | 'effects' | 'advanced'>('presets')
  const [showPreview, setShowPreview] = useState(true)
  const [importText, setImportText] = useState('')
  const [customThemeName, setCustomThemeName] = useState('')

  const handleExportTheme = () => {
    const themeJson = exportTheme()
    const blob = new Blob([themeJson], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${theme.name || 'custom'}-theme.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImportTheme = () => {
    if (importTheme(importText)) {
      setImportText('')
      alert('Theme imported successfully!')
    } else {
      alert('Invalid theme format!')
    }
  }

  const handleCreateCustomTheme = () => {
    if (customThemeName.trim()) {
      createCustomTheme(themeName, customThemeName)
      setCustomThemeName('')
    }
  }

  const allThemes = Object.entries(themes)

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Palette className="w-6 h-6" style={{ color: theme.accent }} />
          <h2 className="text-2xl font-bold" style={{ color: theme.text }}>
            Theme Customizer
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
            style={{ color: theme.text }}
          >
            {showPreview ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
          {customTheme && (
            <button
              onClick={resetThemeColors}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              style={{ color: theme.text }}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 p-1 rounded-lg bg-white/5">
        {[
          { id: 'presets', label: 'Presets', icon: <Sparkles className="w-4 h-4" /> },
          { id: 'colors', label: 'Colors', icon: <Palette className="w-4 h-4" /> },
          { id: 'effects', label: 'Effects', icon: <Sliders className="w-4 h-4" /> },
          { id: 'advanced', label: 'Advanced', icon: <Download className="w-4 h-4" /> }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
              activeTab === tab.id
                ? 'bg-white/20 shadow-lg'
                : 'hover:bg-white/10'
            }`}
            style={{ 
              color: activeTab === tab.id ? theme.text : theme.text + '80',
              backgroundColor: activeTab === tab.id ? theme.primary + '30' : undefined
            }}
          >
            {tab.icon}
            <span className="text-sm font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <GlassCard variant="enhanced" className="p-6">
        {/* Presets Tab */}
        {activeTab === 'presets' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4" style={{ color: theme.text }}>
                Visual Masterpiece Themes
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {allThemes.map(([key, themeOption]) => (
                  <button
                    key={key}
                    onClick={() => setTheme(key)}
                    className={`p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                      themeName === key && !customTheme
                        ? 'border-white/50 shadow-xl'
                        : 'border-white/20 hover:border-white/30'
                    }`}
                    style={{
                      background: `linear-gradient(135deg, ${themeOption.primary}40, ${themeOption.secondary}40)`,
                      borderColor: themeName === key && !customTheme ? themeOption.accent : undefined
                    }}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2" style={{ color: themeOption.text }}>
                        {themeOption.displayName.split(' ')[0]}
                      </div>
                      <div className="text-xs font-medium" style={{ color: themeOption.text }}>
                        {themeOption.displayName.split(' ').slice(1).join(' ')}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Create Custom Theme */}
            <div className="p-4 rounded-lg bg-white/5 border border-white/10">
              <h4 className="text-sm font-semibold mb-3" style={{ color: theme.text }}>
                Create Custom Theme
              </h4>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customThemeName}
                  onChange={(e) => setCustomThemeName(e.target.value)}
                  placeholder="Enter theme name..."
                  className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                />
                <button
                  onClick={handleCreateCustomTheme}
                  className="px-4 py-2 rounded-lg font-medium transition-colors"
                  style={{ backgroundColor: theme.primary, color: '#ffffff' }}
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Colors Tab */}
        {activeTab === 'colors' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4" style={{ color: theme.text }}>
              Color Customization
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <ColorPicker
                label="Background"
                value={theme.bg}
                onChange={(color) => updateThemeColor('bg', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Text"
                value={theme.text}
                onChange={(color) => updateThemeColor('text', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Primary"
                value={theme.primary}
                onChange={(color) => updateThemeColor('primary', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Secondary"
                value={theme.secondary}
                onChange={(color) => updateThemeColor('secondary', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Accent"
                value={theme.accent}
                onChange={(color) => updateThemeColor('accent', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Card Background"
                value={theme.cardBg}
                onChange={(color) => updateThemeColor('cardBg', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Border Color"
                value={theme.borderColor}
                onChange={(color) => updateThemeColor('borderColor', color)}
                showPreview={showPreview}
              />
              <ColorPicker
                label="Glow Color"
                value={theme.glowColor || '#ffffff'}
                onChange={(color) => updateThemeColor('glowColor', color)}
                showPreview={showPreview}
              />
            </div>
          </div>
        )}

        {/* Effects Tab */}
        {activeTab === 'effects' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4" style={{ color: theme.text }}>
              Visual Effects
            </h3>
            
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <label className="text-sm font-medium mb-2 block" style={{ color: theme.text }}>
                  Animation Type
                </label>
                <select
                  value={theme.animationType}
                  onChange={(e) => updateThemeColor('animationType', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                >
                  <option value="none">None</option>
                  <option value="pulse">Pulse</option>
                  <option value="wave">Wave</option>
                  <option value="aurora">Aurora</option>
                  <option value="cosmic">Cosmic</option>
                </select>
              </div>

              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <label className="text-sm font-medium mb-2 block" style={{ color: theme.text }}>
                  Gradient Overlay
                </label>
                <textarea
                  value={theme.gradient || ''}
                  onChange={(e) => updateThemeColor('gradient', e.target.value)}
                  placeholder="Enter CSS gradient..."
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 h-20 resize-none"
                />
              </div>

              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <label className="text-sm font-medium mb-2 block" style={{ color: theme.text }}>
                  Background Gradient
                </label>
                <textarea
                  value={theme.gradientBg || ''}
                  onChange={(e) => updateThemeColor('gradientBg', e.target.value)}
                  placeholder="Enter background gradient..."
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 h-20 resize-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Advanced Tab */}
        {activeTab === 'advanced' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4" style={{ color: theme.text }}>
              Import/Export Themes
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Export */}
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2" style={{ color: theme.text }}>
                  <Download className="w-4 h-4" />
                  Export Theme
                </h4>
                <p className="text-xs mb-3" style={{ color: theme.text + '80' }}>
                  Download your custom theme as JSON
                </p>
                <button
                  onClick={handleExportTheme}
                  className="w-full px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                  style={{ backgroundColor: theme.primary, color: '#ffffff' }}
                >
                  <Download className="w-4 h-4" />
                  Export Current Theme
                </button>
              </div>

              {/* Import */}
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2" style={{ color: theme.text }}>
                  <Upload className="w-4 h-4" />
                  Import Theme
                </h4>
                <p className="text-xs mb-3" style={{ color: theme.text + '80' }}>
                  Paste theme JSON code below
                </p>
                <textarea
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder="Paste theme JSON..."
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 h-20 resize-none mb-2"
                />
                <button
                  onClick={handleImportTheme}
                  className="w-full px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                  style={{ backgroundColor: theme.accent, color: '#ffffff' }}
                >
                  <Upload className="w-4 h-4" />
                  Import Theme
                </button>
              </div>
            </div>

            {/* Reset */}
            {customTheme && (
              <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2" style={{ color: '#ef4444' }}>
                  <Trash2 className="w-4 h-4" />
                  Reset Custom Theme
                </h4>
                <p className="text-xs mb-3" style={{ color: theme.text + '80' }}>
                  This will discard all your custom changes and revert to the original theme.
                </p>
                <button
                  onClick={resetThemeColors}
                  className="px-4 py-2 rounded-lg font-medium transition-colors bg-red-500/20 hover:bg-red-500/30 text-red-400"
                >
                  Reset to Original Theme
                </button>
              </div>
            )}
          </div>
        )}
      </GlassCard>
    </div>
  )
}