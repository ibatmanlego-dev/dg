'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { DollarSign, Plus, Search, TrendingUp, TrendingDown, Calendar, ChevronDown } from 'lucide-react'
import { useData } from '@/contexts/DataContext'
import { useTheme } from '@/contexts/ThemeContext'

interface Expense {
  id: string
  title: string
  amount: number
  category: string
  date: string
  description?: string
}

const categories = [
  'Food',
  'Transport',
  'Shopping',
  'Entertainment',
  'Bills',
  'Health',
  'Education',
  'Other'
]

interface ExpensesManagerProps {
  showAddForm?: boolean
  onToggleAddForm?: () => void
}

export function ExpensesManager({ showAddForm: externalShowAddForm, onToggleAddForm }: ExpensesManagerProps) {
  const { theme } = useTheme()
  const { filteredExpenses, addExpense, updateExpense, deleteExpense } = useData()
  const [internalShowAddForm, setInternalShowAddForm] = useState(false)
  
  const showAddFormState = externalShowAddForm ?? internalShowAddForm
  const setShowAddForm = onToggleAddForm ?? setInternalShowAddForm
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [editingExpense, setEditingExpense] = useState<string | null>(null)
  const [newExpense, setNewExpense] = useState({
    title: '',
    amount: '',
    category: 'Food',
    description: ''
  })

  const displayExpenses = filteredExpenses.filter(expense => {
    const matchesSearch = expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (expense.description?.toLowerCase().includes(searchTerm.toLowerCase()) || false)
    const matchesCategory = selectedCategory === 'All' || expense.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const totalExpenses = displayExpenses.reduce((sum, expense) => sum + expense.amount, 0)
  const averageExpense = displayExpenses.length > 0 ? totalExpenses / displayExpenses.length : 0

  const handleAddExpense = () => {
    if (newExpense.title.trim() && newExpense.amount && parseFloat(newExpense.amount) > 0) {
      if (editingExpense) {
        // Update existing expense
        updateExpense(editingExpense, {
          title: newExpense.title,
          amount: parseFloat(newExpense.amount),
          category: newExpense.category,
          description: newExpense.description || undefined
        })
        setEditingExpense(null)
      } else {
        // Add new expense
        addExpense({
          title: newExpense.title,
          amount: parseFloat(newExpense.amount),
          category: newExpense.category,
          date: new Date().toISOString(),
          description: newExpense.description || undefined
        })
      }
      
      setNewExpense({
        title: '',
        amount: '',
        category: 'Food',
        description: ''
      })
      setShowAddForm(false)
    }
  }

  const handleEditExpense = (expense: Expense) => {
    setEditingExpense(expense.id)
    setNewExpense({
      title: expense.title,
      amount: expense.amount.toString(),
      category: expense.category,
      description: expense.description || ''
    })
    setShowAddForm(true)
  }

  const handleCancelEdit = () => {
    setEditingExpense(null)
    setNewExpense({
      title: '',
      amount: '',
      category: 'Food',
      description: ''
    })
    setShowAddForm(false)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Expenses</h2>
        <Button
          onClick={() => setShowAddForm(!showAddFormState)}
          style={{ backgroundColor: theme.primary }}
          className="text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Expense
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Total Expenses</p>
                <p style={{ color: theme.text }} className="text-2xl font-bold">
                  ${totalExpenses.toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-8 h-8" style={{ color: theme.accent }} />
            </div>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Average</p>
                <p style={{ color: theme.text }} className="text-2xl font-bold">
                  ${averageExpense.toFixed(2)}
                </p>
              </div>
              <DollarSign className="w-8 h-8" style={{ color: theme.primary }} />
            </div>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Transactions</p>
                <p style={{ color: theme.text }} className="text-2xl font-bold">
                  {displayExpenses.length}
                </p>
              </div>
              <Calendar className="w-8 h-8" style={{ color: theme.secondary }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 opacity-50" />
          <Input
            placeholder="Search expenses..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            style={{ 
              backgroundColor: theme.cardBg,
              borderColor: theme.borderColor,
              color: theme.text
            }}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={selectedCategory === 'All' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('All')}
            size="sm"
          >
            All
          </Button>
          {categories.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(category)}
              size="sm"
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Add/Edit Expense Form */}
      {showAddFormState && (
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardHeader>
            <CardTitle style={{ color: theme.text }}>
              {editingExpense ? 'Edit Expense' : 'Add New Expense'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Expense title"
              value={newExpense.title}
              onChange={(e) => setNewExpense({ ...newExpense, title: e.target.value })}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <div className="flex gap-4">
              <Input
                type="number"
                step="0.01"
                placeholder="Amount"
                value={newExpense.amount}
                onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
                className="flex-1"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              />
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="flex-1 justify-between"
                    style={{ 
                      backgroundColor: theme.secondary,
                      borderColor: theme.borderColor,
                      color: theme.name === 'light' ? '#000000' : theme.text
                    }}
                  >
                    {newExpense.category}
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {categories.map(category => (
                    <DropdownMenuItem
                      key={category}
                      onClick={() => setNewExpense({ ...newExpense, category: category })}
                      style={{ color: theme.text }}
                    >
                      {category}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <Input
              placeholder="Description (optional)"
              value={newExpense.description}
              onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <div className="flex gap-2">
              <Button
                onClick={handleAddExpense}
                style={{ backgroundColor: theme.primary }}
                className="text-white"
              >
                {editingExpense ? 'Update Expense' : 'Add Expense'}
              </Button>
              <Button
                variant="outline"
                onClick={handleCancelEdit}
                style={{ borderColor: theme.borderColor, color: theme.text }}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Expenses List */}
      <div className="space-y-4">
        {displayExpenses.length === 0 ? (
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardContent className="text-center py-8">
              <p style={{ color: theme.text, opacity: 0.7 }}>
                No expenses found. Start by adding your first expense!
              </p>
            </CardContent>
          </Card>
        ) : (
          displayExpenses.map(expense => (
            <Card
              key={expense.id}
              style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}
              className="transition-all duration-200 hover:shadow-lg"
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 style={{ color: theme.text }} className="font-semibold">
                        {expense.title}
                      </h3>
                      <Badge variant="secondary">{expense.category}</Badge>
                    </div>
                    {expense.description && (
                      <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm mb-2">
                        {expense.description}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-sm" style={{ color: theme.text, opacity: 0.6 }}>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(expense.date).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span style={{ color: theme.accent }} className="text-xl font-bold">
                      ${expense.amount.toFixed(2)}
                    </span>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditExpense(expense)}
                        style={{ borderColor: theme.borderColor, color: theme.text }}
                      >
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteExpense(expense.id)}
                        style={{ borderColor: theme.borderColor, color: theme.text }}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}