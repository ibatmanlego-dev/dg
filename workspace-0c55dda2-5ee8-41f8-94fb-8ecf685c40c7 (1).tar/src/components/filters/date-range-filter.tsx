'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Calendar, 
  Filter, 
  X, 
  ChevronDown,
  BarChart3,
  DollarSign,
  Heart,
  Activity
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useData } from '@/contexts/DataContext'

export function DateRangeFilter() {
  const { theme } = useTheme()
  const { dateFilter, setDateFilter, filteredActivities, filteredExpenses, filteredHealthMetrics } = useData()
  
  const [startDate, setStartDate] = useState(dateFilter.startDate || '')
  const [endDate, setEndDate] = useState(dateFilter.endDate || '')
  const [showAdvanced, setShowAdvanced] = useState(false)

  // Update local state when context changes
  useEffect(() => {
    setStartDate(dateFilter.startDate || '')
    setEndDate(dateFilter.endDate || '')
  }, [dateFilter])

  // Set default date range to last 30 days
  useEffect(() => {
    if (!dateFilter.startDate && !dateFilter.endDate) {
      const today = new Date()
      const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)
      
      const newFilter = {
        startDate: thirtyDaysAgo.toISOString().split('T')[0],
        endDate: today.toISOString().split('T')[0],
        dataTypes: dateFilter.dataTypes
      }
      
      setEndDate(today.toISOString().split('T')[0])
      setStartDate(thirtyDaysAgo.toISOString().split('T')[0])
      setDateFilter(newFilter)
    }
  }, [])

  // Update context when dates change
  useEffect(() => {
    setDateFilter({
      ...dateFilter,
      startDate,
      endDate
    })
  }, [startDate, endDate])

  const handleQuickFilter = (days: number) => {
    const today = new Date()
    const pastDate = new Date(today.getTime() - days * 24 * 60 * 60 * 1000)
    
    const newStartDate = pastDate.toISOString().split('T')[0]
    const newEndDate = today.toISOString().split('T')[0]
    
    setStartDate(newStartDate)
    setEndDate(newEndDate)
  }

  const handleClearFilters = () => {
    setStartDate('')
    setEndDate('')
    setDateFilter({
      ...dateFilter,
      startDate: undefined,
      endDate: undefined
    })
  }

  const handleDataTypeToggle = (type: 'activities' | 'expenses' | 'health') => {
    setDateFilter({
      ...dateFilter,
      dataTypes: {
        ...dateFilter.dataTypes,
        [type]: !dateFilter.dataTypes[type]
      }
    })
  }

  const totalItems = filteredActivities.length + filteredExpenses.length + filteredHealthMetrics.length

  return (
    <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between" style={{ color: theme.text }}>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Date Range Filter
          </div>
          <Badge variant="secondary">
            {totalItems} items
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Quick Filters */}
        <div>
          <Label style={{ color: theme.text }} className="text-sm font-medium mb-2 block">
            Quick Filters
          </Label>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickFilter(7)}
              className="text-xs"
            >
              Last 7 days
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickFilter(30)}
              className="text-xs"
            >
              Last 30 days
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickFilter(90)}
              className="text-xs"
            >
              Last 90 days
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickFilter(365)}
              className="text-xs"
            >
              Last year
            </Button>
          </div>
        </div>

        {/* Date Range */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label style={{ color: theme.text }} className="text-sm font-medium">
              Start Date
            </Label>
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text,
                marginTop: '0.5rem'
              }}
            />
          </div>
          <div>
            <Label style={{ color: theme.text }} className="text-sm font-medium">
              End Date
            </Label>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text,
                marginTop: '0.5rem'
              }}
            />
          </div>
        </div>

        {/* Advanced Filters */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center gap-2"
          >
            <ChevronDown className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
            Advanced Filters
          </Button>
          
          {showAdvanced && (
            <div className="mt-4 space-y-4">
              <Label style={{ color: theme.text }} className="text-sm font-medium">
                Data Types to Include
              </Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="activities-filter"
                    checked={dateFilter.dataTypes.activities}
                    onChange={() => handleDataTypeToggle('activities')}
                    className="rounded"
                  />
                  <Label htmlFor="activities-filter" className="flex items-center gap-2 cursor-pointer">
                    <Activity className="w-4 h-4" style={{ color: theme.primary }} />
                    <span style={{ color: theme.text }}>Activities</span>
                    <Badge variant="secondary" className="text-xs">
                      {filteredActivities.length}
                    </Badge>
                  </Label>
                </div>
                
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="expenses-filter"
                    checked={dateFilter.dataTypes.expenses}
                    onChange={() => handleDataTypeToggle('expenses')}
                    className="rounded"
                  />
                  <Label htmlFor="expenses-filter" className="flex items-center gap-2 cursor-pointer">
                    <DollarSign className="w-4 h-4" style={{ color: theme.accent }} />
                    <span style={{ color: theme.text }}>Expenses</span>
                    <Badge variant="secondary" className="text-xs">
                      {filteredExpenses.length}
                    </Badge>
                  </Label>
                </div>
                
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="health-filter"
                    checked={dateFilter.dataTypes.health}
                    onChange={() => handleDataTypeToggle('health')}
                    className="rounded"
                  />
                  <Label htmlFor="health-filter" className="flex items-center gap-2 cursor-pointer">
                    <Heart className="w-4 h-4" style={{ color: theme.secondary }} />
                    <span style={{ color: theme.text }}>Health</span>
                    <Badge variant="secondary" className="text-xs">
                      {filteredHealthMetrics.length}
                    </Badge>
                  </Label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-3 rounded-lg border" style={{ borderColor: theme.borderColor }}>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4" style={{ color: theme.primary }} />
              <span style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Activities</span>
            </div>
            <p style={{ color: theme.text }} className="text-xl font-bold">
              {filteredActivities.length}
            </p>
          </div>
          
          <div className="p-3 rounded-lg border" style={{ borderColor: theme.borderColor }}>
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" style={{ color: theme.accent }} />
              <span style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Expenses</span>
            </div>
            <p style={{ color: theme.text }} className="text-xl font-bold">
              ${filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0).toFixed(2)}
            </p>
          </div>
          
          <div className="p-3 rounded-lg border" style={{ borderColor: theme.borderColor }}>
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4" style={{ color: theme.secondary }} />
              <span style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Health Metrics</span>
            </div>
            <p style={{ color: theme.text }} className="text-xl font-bold">
              {filteredHealthMetrics.length}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={handleClearFilters}
            className="flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            Clear Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}