'use client'

import React from 'react'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { useData } from '@/contexts/DataContext'
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts'

export function DashboardCharts() {
  const { expenses, activities } = useData()

  // Expense breakdown data
  const currentMonth = new Date().getMonth()
  const currentYear = new Date().getFullYear()
  const monthlyExpenses = expenses.filter(e => {
    const expenseDate = new Date(e.date)
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear
  })

  const expenseByCategory = monthlyExpenses.reduce((acc, expense) => {
    acc[expense.category] = (acc[expense.category] || 0) + expense.amount
    return acc
  }, {} as Record<string, number>)

  const expenseData = Object.entries(expenseByCategory).map(([category, amount]) => ({
    name: category,
    value: amount,
  }))

  // Activity completion data
  const recentActivities = activities.filter(a => 
    new Date(a.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
  )
  
  const completedCount = recentActivities.filter(a => a.status === 'completed').length
  const pendingCount = recentActivities.filter(a => a.status === 'pending').length
  const cancelledCount = recentActivities.filter(a => a.status === 'cancelled').length

  const activityData = [
    { name: 'Completed', value: completedCount, color: '#10b981' },
    { name: 'Pending', value: pendingCount, color: '#f59e0b' },
    { name: 'Cancelled', value: cancelledCount, color: '#ef4444' },
  ]

  const COLORS = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']

  if (expenseData.length === 0 && activityData.every(d => d.value === 0)) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <GlassCard>
          <GlassCardHeader>
            <GlassCardTitle>Expense Breakdown</GlassCardTitle>
          </GlassCardHeader>
          <GlassCardContent>
            <div className="flex items-center justify-center h-64 text-[var(--theme-text)]/60">
              No expenses this month
            </div>
          </GlassCardContent>
        </GlassCard>
        
        <GlassCard>
          <GlassCardHeader>
            <GlassCardTitle>Activity Completion</GlassCardTitle>
          </GlassCardHeader>
          <GlassCardContent>
            <div className="flex items-center justify-center h-64 text-[var(--theme-text)]/60">
              No recent activities
            </div>
          </GlassCardContent>
        </GlassCard>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Expense Breakdown Chart */}
      <GlassCard>
        <GlassCardHeader>
          <GlassCardTitle>Expense Breakdown</GlassCardTitle>
        </GlassCardHeader>
        <GlassCardContent>
          {expenseData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={expenseData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number) => [`$${value.toFixed(2)}`, 'Amount']}
                  contentStyle={{
                    backgroundColor: 'var(--theme-card-bg)',
                    border: '1px solid var(--theme-border-color)',
                    borderRadius: '8px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-64 text-[var(--theme-text)]/60">
              No expenses this month
            </div>
          )}
        </GlassCardContent>
      </GlassCard>

      {/* Activity Completion Chart */}
      <GlassCard>
        <GlassCardHeader>
          <GlassCardTitle>Activity Completion</GlassCardTitle>
        </GlassCardHeader>
        <GlassCardContent>
          {activityData.some(d => d.value > 0) ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={activityData}>
                <XAxis 
                  dataKey="name" 
                  stroke="var(--theme-text)"
                  tick={{ fill: 'var(--theme-text)', fontSize: 12 }}
                />
                <YAxis 
                  stroke="var(--theme-text)"
                  tick={{ fill: 'var(--theme-text)', fontSize: 12 }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--theme-card-bg)',
                    border: '1px solid var(--theme-border-color)',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="value" fill="var(--theme-primary)" radius={[8, 8, 0, 0]}>
                  {activityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-64 text-[var(--theme-text)]/60">
              No recent activities
            </div>
          )}
        </GlassCardContent>
      </GlassCard>
    </div>
  )
}