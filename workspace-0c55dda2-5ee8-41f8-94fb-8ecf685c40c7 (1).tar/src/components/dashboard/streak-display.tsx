'use client'

import React from 'react'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Badge } from '@/components/ui/badge'
import { useData } from '@/contexts/DataContext'
import { Flame, Calendar, Target } from 'lucide-react'

export function StreakDisplay() {
  const { settings } = useData()

  if (!settings) return null

  const streak = settings.streak
  const lastActive = new Date(settings.lastActive)
  const today = new Date()
  const isTodayActive = lastActive.toDateString() === today.toDateString()

  const getStreakColor = (streak: number) => {
    if (streak >= 30) return 'text-purple-500'
    if (streak >= 14) return 'text-red-500'
    if (streak >= 7) return 'text-orange-500'
    if (streak >= 3) return 'text-yellow-500'
    return 'text-blue-500'
  }

  const getStreakMessage = (streak: number) => {
    if (streak >= 100) return "Legendary! You're on fire! 🔥"
    if (streak >= 30) return "Incredible consistency! Keep it up!"
    if (streak >= 14) return "Two weeks strong! Amazing dedication!"
    if (streak >= 7) return "One week! You're building a great habit!"
    if (streak >= 3) return "Three days! Great start!"
    if (streak >= 1) return "Good start! Keep the momentum going!"
    return "Start your streak today!"
  }

  const getStreakMilestone = (streak: number) => {
    const milestones = [1, 3, 7, 14, 30, 60, 100, 365]
    return milestones.find(m => streak >= m && streak < m * 2) || 1
  }

  const nextMilestone = getStreakMilestone(streak) * 2
  const progressToNext = (streak / nextMilestone) * 100

  return (
    <GlassCard>
      <GlassCardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <GlassCardTitle className="text-lg font-semibold">
          Daily Streak
        </GlassCardTitle>
        <div className="flex items-center gap-1">
          <Flame className={cn("w-5 h-5", getStreakColor(streak), isTodayActive && "animate-pulse")} />
          {isTodayActive && (
            <Badge variant="secondary" className="text-xs">
              Active Today
            </Badge>
          )}
        </div>
      </GlassCardHeader>
      <GlassCardContent className="space-y-4">
        <div className="flex items-center justify-center">
          <div className="text-center">
            <div className={cn("text-5xl font-bold", getStreakColor(streak))}>
              {streak}
            </div>
            <div className="text-sm text-[var(--theme-text)]/60 mt-1">
              {streak === 1 ? 'Day' : 'Days'}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-[var(--theme-text)]/60">Progress to {nextMilestone} days</span>
            <span className="text-[var(--theme-text)]/80 font-medium">{streak}/{nextMilestone}</span>
          </div>
          <div className="w-full bg-[var(--theme-secondary)]/20 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-[var(--theme-primary)] to-[var(--theme-accent)] h-2 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, progressToNext)}%` }}
            />
          </div>
        </div>

        <div className="p-3 rounded-lg bg-[var(--theme-secondary)]/20 border border-[var(--theme-border-color)]">
          <p className="text-sm text-[var(--theme-text)]/80 text-center">
            {getStreakMessage(streak)}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="p-2 rounded-lg bg-[var(--theme-secondary)]/20 text-center">
            <Calendar className="w-4 h-4 mx-auto mb-1 text-[var(--theme-primary)]" />
            <div className="text-xs text-[var(--theme-text)]/60">Last Active</div>
            <div className="text-xs font-medium text-[var(--theme-text)]">
              {lastActive.toLocaleDateString()}
            </div>
          </div>
          <div className="p-2 rounded-lg bg-[var(--theme-secondary)]/20 text-center">
            <Target className="w-4 h-4 mx-auto mb-1 text-[var(--theme-accent)]" />
            <div className="text-xs text-[var(--theme-text)]/60">Next Milestone</div>
            <div className="text-xs font-medium text-[var(--theme-text)]">
              {nextMilestone} days
            </div>
          </div>
        </div>
      </GlassCardContent>
    </GlassCard>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}