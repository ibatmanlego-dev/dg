'use client'

import React from 'react'
import { GlassCard, GlassCardContent } from '@/components/ui/glass-card'
import { useData } from '@/contexts/DataContext'
import { CheckCircle, DollarSign, Trophy, Target } from 'lucide-react'

export function SummaryCards() {
  const { activities, expenses, settings } = useData()

  // Calculate summary stats
  const todayActivities = activities.filter(a => 
    new Date(a.createdAt).toDateString() === new Date().toDateString()
  )
  const completedToday = todayActivities.filter(a => a.status === 'completed').length

  const currentMonth = new Date().getMonth()
  const currentYear = new Date().getFullYear()
  const monthlyExpenses = expenses.filter(e => {
    const expenseDate = new Date(e.date)
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear
  })
  const totalExpenses = monthlyExpenses.reduce((sum, e) => sum + e.amount, 0)

  const allCompletedActivities = activities.filter(a => a.status === 'completed').length
  const totalGoals = activities.filter(a => a.priority === 'high').length
  const achievedGoals = activities.filter(a => a.priority === 'high' && a.status === 'completed').length

  const cards = [
    {
      title: 'Activities Today',
      value: completedToday.toString(),
      subtitle: `${todayActivities.length} total`,
      icon: <CheckCircle className="w-5 h-5 text-green-500" />,
      color: 'from-green-500/20 to-emerald-500/20',
    },
    {
      title: 'Monthly Expenses',
      value: `$${totalExpenses.toFixed(2)}`,
      subtitle: `${monthlyExpenses.length} transactions`,
      icon: <DollarSign className="w-5 h-5 text-blue-500" />,
      color: 'from-blue-500/20 to-cyan-500/20',
    },
    {
      title: 'Achievements',
      value: '12', // Mock data for now
      subtitle: '3 unlocked this week',
      icon: <Trophy className="w-5 h-5 text-yellow-500" />,
      color: 'from-yellow-500/20 to-orange-500/20',
    },
    {
      title: 'Goals Achieved',
      value: `${achievedGoals}/${totalGoals}`,
      subtitle: `${totalGoals > 0 ? Math.round((achievedGoals / totalGoals) * 100) : 0}% completion`,
      icon: <Target className="w-5 h-5 text-purple-500" />,
      color: 'from-purple-500/20 to-pink-500/20',
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {cards.map((card, index) => (
        <GlassCard key={index} variant="subtle">
          <GlassCardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className={cn(
                "p-2 rounded-lg bg-gradient-to-r",
                card.color
              )}>
                {card.icon}
              </div>
            </div>
            <div className="space-y-1">
              <div className="text-xl font-bold text-[var(--theme-text)]">
                {card.value}
              </div>
              <div className="text-xs text-[var(--theme-text)]/60">
                {card.title}
              </div>
              <div className="text-xs text-[var(--theme-text)]/40">
                {card.subtitle}
              </div>
            </div>
          </GlassCardContent>
        </GlassCard>
      ))}
    </div>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}