'use client'

import React, { useState, useEffect } from 'react'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useData } from '@/contexts/DataContext'
import { TrendingUp, TrendingDown, Minus, RefreshCw } from 'lucide-react'

interface VibeScoreData {
  score: number
  factors: string[]
  suggestion: string
  trend: 'up' | 'down' | 'stable'
  previousScore?: number
}

export function VibeScore() {
  const { user, activities, expenses, healthLogs, settings } = useData()
  const [vibeData, setVibeData] = useState<VibeScoreData | null>(null)
  const [loading, setLoading] = useState(false)

  const calculateVibeScore = async () => {
    if (!user) return

    setLoading(true)
    try {
      // Try to get AI-powered Vibe Score first
      try {
        const response = await fetch('/api/vibe-score', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId: user.id }),
        })

        if (response.ok) {
          const aiData = await response.json()
          setVibeData({
            score: aiData.score,
            factors: aiData.factors,
            suggestion: aiData.suggestion,
            trend: aiData.trend,
            previousScore: Math.max(0, Math.min(100, aiData.score + (Math.random() - 0.5) * 10)),
          })
          return
        }
      } catch (aiError) {
        console.log('AI Vibe Score unavailable, using fallback calculation')
      }

      // Fallback to local calculation
      const factors = []
      let score = 50 // Base score

      // Activity completion factor
      const recentActivities = activities.filter(a => 
        new Date(a.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      )
      const completedActivities = recentActivities.filter(a => a.status === 'completed')
      const activityScore = Math.min(30, (completedActivities.length / Math.max(1, recentActivities.length)) * 30)
      score += activityScore
      factors.push(`Activity completion: ${Math.round(activityScore)} points`)

      // Expense management factor
      const currentMonth = new Date().getMonth()
      const currentYear = new Date().getFullYear()
      const monthlyExpenses = expenses.filter(e => {
        const expenseDate = new Date(e.date)
        return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear
      })
      const totalExpenses = monthlyExpenses.reduce((sum, e) => sum + e.amount, 0)
      const expenseScore = totalExpenses > 0 ? Math.max(-20, 20 - (totalExpenses / 100)) : 20
      score += expenseScore
      factors.push(`Expense management: ${Math.round(expenseScore)} points`)

      // Health tracking factor
      const recentHealthLogs = healthLogs.filter(h => 
        new Date(h.date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      )
      const healthScore = Math.min(20, (recentHealthLogs.length / 7) * 20)
      score += healthScore
      factors.push(`Health tracking: ${Math.round(healthScore)} points`)

      // Streak bonus
      if (settings?.streak && settings.streak > 0) {
        const streakBonus = Math.min(10, settings.streak)
        score += streakBonus
        factors.push(`Daily streak: +${streakBonus} points`)
      }

      // Ensure score is within bounds
      score = Math.max(0, Math.min(100, score))

      // Generate suggestion based on score
      let suggestion = ''
      if (score >= 80) {
        suggestion = "Excellent! You're crushing it. Keep up the amazing work!"
      } else if (score >= 60) {
        suggestion = "Great progress! Focus on completing more activities to level up."
      } else if (score >= 40) {
        suggestion = "Good start! Try to log your health data and manage expenses better."
      } else {
        suggestion = "Time to get back on track! Start with small, achievable goals."
      }

      // Calculate trend (mock data for now)
      const previousScore = Math.max(0, Math.min(100, score + (Math.random() - 0.5) * 20))
      let trend: 'up' | 'down' | 'stable' = 'stable'
      if (score > previousScore + 5) trend = 'up'
      else if (score < previousScore - 5) trend = 'down'

      setVibeData({
        score: Math.round(score),
        factors,
        suggestion,
        trend,
        previousScore: Math.round(previousScore),
      })

    } catch (error) {
      console.error('Error calculating Vibe Score:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    calculateVibeScore()
  }, [activities, expenses, healthLogs, settings])

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500'
    if (score >= 60) return 'text-yellow-500'
    if (score >= 40) return 'text-orange-500'
    return 'text-red-500'
  }

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent'
    if (score >= 60) return 'Good'
    if (score >= 40) return 'Fair'
    return 'Needs Work'
  }

  const getTrendIcon = () => {
    if (!vibeData) return null
    switch (vibeData.trend) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-500" />
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-500" />
      default:
        return <Minus className="w-4 h-4 text-gray-500" />
    }
  }

  if (!vibeData) {
    return (
      <GlassCard>
        <GlassCardContent className="flex items-center justify-center h-32">
          <RefreshCw className="w-6 h-6" />
        </GlassCardContent>
      </GlassCard>
    )
  }

  return (
    <GlassCard>
      <GlassCardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <GlassCardTitle className="text-lg font-semibold">
          Vibe Score
        </GlassCardTitle>
        <div className="flex items-center gap-2">
          {getTrendIcon()}
          <Button
            variant="ghost"
            size="sm"
            onClick={calculateVibeScore}
            disabled={loading}
            className="h-8 w-8 p-0"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </GlassCardHeader>
      <GlassCardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className={cn("text-3xl font-bold", getScoreColor(vibeData.score))}>
              {vibeData.score}
            </div>
            <Badge variant="secondary" className="mt-1">
              {getScoreLabel(vibeData.score)}
            </Badge>
          </div>
          <div className="text-right">
            {vibeData.previousScore && (
              <div className="text-sm text-[var(--theme-text)]/60">
                Last: {vibeData.previousScore}
              </div>
            )}
          </div>
        </div>

        <Progress 
          value={vibeData.score} 
          className="h-2"
        />

        <div className="space-y-2">
          <h4 className="text-sm font-medium text-[var(--theme-text)]/80">
            Key Factors:
          </h4>
          <div className="space-y-1">
            {vibeData.factors.slice(0, 3).map((factor, index) => (
              <div key={index} className="text-xs text-[var(--theme-text)]/60">
                • {factor}
              </div>
            ))}
          </div>
        </div>

        <div className="p-3 rounded-lg bg-[var(--theme-secondary)]/20 border border-[var(--theme-border-color)]">
          <p className="text-sm text-[var(--theme-text)]/80 italic">
            💡 {vibeData.suggestion}
          </p>
        </div>
      </GlassCardContent>
    </GlassCard>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}