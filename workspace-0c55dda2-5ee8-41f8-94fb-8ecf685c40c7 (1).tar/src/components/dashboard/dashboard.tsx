'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useData } from '@/contexts/DataContext'
import { useTheme } from '@/contexts/ThemeContext'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { GlassCard } from '@/components/ui/glass-card'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { 
  Settings, 
  Plus, 
  TrendingUp, 
  Target, 
  Calendar,
  Activity,
  DollarSign,
  Heart,
  Shield
} from 'lucide-react'

// Quick summary components
function QuickSummary() {
  const { settings } = useData()
  const { theme } = useTheme()

  const summaryData = [
    {
      title: 'Activities',
      value: '12',
      icon: <Activity className="w-5 h-5" />,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10'
    },
    {
      title: 'Expenses',
      value: '$245',
      icon: <DollarSign className="w-5 h-5" />,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10'
    },
    {
      title: 'Health Score',
      value: '85%',
      icon: <Heart className="w-5 h-5" />,
      color: 'text-red-500',
      bgColor: 'bg-red-500/10'
    },

  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {summaryData.map((item, index) => (
        <motion.div
          key={item.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <GlassCard variant="enhanced" className="p-4 hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 rounded-lg glass-card" style={{ 
                backgroundColor: theme.cardBg,
                color: theme.accent 
              }}>
                {item.icon}
              </div>
            </div>
            <div>
              <p className="text-sm mb-1" style={{ color: theme.text, opacity: 0.7 }}>{item.title}</p>
              <p className="text-xl font-bold neon-text" style={{ color: theme.text }}>{item.value}</p>
            </div>
          </GlassCard>
        </motion.div>
      ))}
    </div>
  )
}

function VibeScoreCard() {
  const { theme } = useTheme()
  const score = 75

  return (
    <GlassCard variant="enhanced" glow className="p-6">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Target className="w-6 h-6" style={{ color: theme.primary }} />
          <h3 className="text-lg font-semibold" style={{ color: theme.text }}>Vibe Score</h3>
        </div>
        <div className="text-4xl font-bold neon-text mb-3" style={{ color: theme.primary }}>{score}</div>
        <div className="relative">
          <Progress value={score} className="h-3" />
          <div 
            className="absolute inset-0 rounded-full animate-pulse opacity-30"
            style={{ backgroundColor: theme.glowColor }}
          />
        </div>
        <p className="text-sm mt-2" style={{ color: theme.text, opacity: 0.8 }}>Great progress today!</p>
      </div>
    </GlassCard>
  )
}

function LevelProgressCard() {
  const { settings } = useData()
  const { theme } = useTheme()
  const level = settings?.level || 1
  const progress = 65

  return (
    <GlassCard variant="enhanced" glow className="p-6">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <TrendingUp className="w-6 h-6" style={{ color: theme.accent }} />
          <h3 className="text-lg font-semibold" style={{ color: theme.text }}>Level Progress</h3>
        </div>
        <div className="text-2xl font-bold neon-text mb-3" style={{ color: theme.accent }}>Level {level}</div>
        <div className="relative">
          <Progress value={progress} className="h-3" />
          <div 
            className="absolute inset-0 rounded-full animate-pulse opacity-30"
            style={{ backgroundColor: theme.glowColor }}
          />
        </div>
        <p className="text-sm mt-2" style={{ color: theme.text, opacity: 0.8 }}>{progress}% to next level</p>
      </div>
    </GlassCard>
  )
}

function StreakCard() {
  const { settings } = useData()
  const { theme } = useTheme()
  const streak = settings?.streak || 0

  return (
    <GlassCard variant="enhanced" glow className="p-6">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Calendar className="w-6 h-6" style={{ color: '#ff6b35' }} />
          <h3 className="text-lg font-semibold" style={{ color: theme.text }}>Daily Streak</h3>
        </div>
        <div className="text-3xl font-bold neon-text mb-3" style={{ color: '#ff6b35' }}>
          {streak} 🔥
        </div>
        <div className="flex justify-center gap-1">
          {Array.from({ length: Math.min(7, streak) }).map((_, i) => (
            <div 
              key={i}
              className="w-2 h-2 rounded-full animate-pulse"
              style={{ 
                backgroundColor: '#ff6b35',
                animationDelay: `${i * 0.2}s`
              }}
            />
          ))}
        </div>
        <p className="text-sm mt-2" style={{ color: theme.text, opacity: 0.8 }}>Keep it going!</p>
      </div>
    </GlassCard>
  )
}

export function Dashboard() {
  const { settings, updateSettings } = useData()
  const { theme } = useTheme()
  const [customizationOpen, setCustomizationOpen] = useState(false)

  const handleWidgetToggle = async (widget: string, checked: boolean) => {
    if (!settings) return
    
    const updates: any = {}
    updates[`show${widget}`] = checked
    
    await updateSettings(updates)
  }

  // Show dashboard immediately with default settings
  const displaySettings = settings || {
    showVibeScore: true,
    showLevelProgress: true,
    showStreak: true,
    showCharts: true,
    showSummaryCards: true,
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-center"
      >
        <h1 className="text-3xl font-bold neon-text mb-2" style={{ color: theme.text }}>
          Welcome to Your Visual Masterpiece ✨
        </h1>
        <p className="text-lg" style={{ color: theme.text, opacity: 0.8 }}>
          Experience tracking like never before
        </p>
      </motion.div>

      {/* Summary Cards */}
      {displaySettings.showSummaryCards && (
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <QuickSummary />
        </motion.div>
      )}

      {/* Top Row - Vibe Score, Level Progress, Streak */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {displaySettings.showVibeScore && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <VibeScoreCard />
          </motion.div>
        )}
        
        {displaySettings.showLevelProgress && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <LevelProgressCard />
          </motion.div>
        )}
        
        {displaySettings.showStreak && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <StreakCard />
          </motion.div>
        )}
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <GlassCard variant="enhanced" glow className="p-6">
          <h3 className="text-xl font-semibold mb-4 neon-text" style={{ color: theme.text }}>
            Quick Actions
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button 
              variant="outline" 
              className="h-16 flex flex-col gap-1 glass-card hover:neon-border enhanced-button"
              style={{ borderColor: theme.borderColor }}
            >
              <Plus className="w-5 h-5" />
              <span className="text-xs">Add Activity</span>
            </Button>
            <Button 
              variant="outline" 
              className="h-16 flex flex-col gap-1 glass-card hover:neon-border enhanced-button"
              style={{ borderColor: theme.borderColor }}
            >
              <DollarSign className="w-5 h-5" />
              <span className="text-xs">Add Expense</span>
            </Button>
            <Button 
              variant="outline" 
              className="h-16 flex flex-col gap-1 glass-card hover:neon-border enhanced-button"
              style={{ borderColor: theme.borderColor }}
            >
              <Heart className="w-5 h-5" />
              <span className="text-xs">Log Health</span>
            </Button>
            <Button 
              variant="outline" 
              className="h-16 flex flex-col gap-1 glass-card hover:neon-border enhanced-button"
              style={{ borderColor: theme.borderColor }}
            >
              <Shield className="w-5 h-5" />
              <span className="text-xs">Open Vault</span>
            </Button>
          </div>
        </GlassCard>
      </motion.div>


    </div>
  )
}