'use client'

import React from 'react'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { useData } from '@/contexts/DataContext'
import { Trophy, Star, Zap } from 'lucide-react'

export function LevelProgress() {
  const { settings } = useData()

  if (!settings) return null

  const currentLevel = settings.level
  const currentPoints = settings.vibePoints
  const pointsForNextLevel = currentLevel * 100
  const pointsInCurrentLevel = currentPoints - ((currentLevel - 1) * 100)
  const progressToNextLevel = (pointsInCurrentLevel / 100) * 100

  const getLevelTitle = (level: number) => {
    const titles = [
      'Beginner', 'Novice', 'Apprentice', 'Journeyman', 'Expert',
      'Master', 'Grandmaster', 'Legend', 'Mythic', 'Transcendent'
    ]
    return titles[Math.min(level - 1, titles.length - 1)]
  }

  const getLevelColor = (level: number) => {
    if (level >= 8) return 'text-purple-500'
    if (level >= 6) return 'text-red-500'
    if (level >= 4) return 'text-orange-500'
    if (level >= 2) return 'text-blue-500'
    return 'text-green-500'
  }

  return (
    <GlassCard>
      <GlassCardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <GlassCardTitle className="text-lg font-semibold">
          Level Progress
        </GlassCardTitle>
        <Trophy className={cn("w-5 h-5", getLevelColor(currentLevel))} />
      </GlassCardHeader>
      <GlassCardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-[var(--theme-text)]">
                Level {currentLevel}
              </span>
              <Badge variant="outline" className="text-xs">
                {getLevelTitle(currentLevel)}
              </Badge>
            </div>
            <div className="text-sm text-[var(--theme-text)]/60 mt-1">
              {currentPoints} Vibe Points
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-1">
              <Zap className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-medium text-[var(--theme-text)]">
                {pointsInCurrentLevel}/100
              </span>
            </div>
            <div className="text-xs text-[var(--theme-text)]/60">
              to Level {currentLevel + 1}
            </div>
          </div>
        </div>

        <Progress 
          value={progressToNextLevel} 
          className="h-3"
        />

        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-lg bg-[var(--theme-secondary)]/20">
            <Star className="w-4 h-4 mx-auto mb-1 text-yellow-500" />
            <div className="text-xs text-[var(--theme-text)]/60">Current</div>
            <div className="text-sm font-bold text-[var(--theme-text)]">{currentLevel}</div>
          </div>
          <div className="p-2 rounded-lg bg-[var(--theme-secondary)]/20">
            <Zap className="w-4 h-4 mx-auto mb-1 text-blue-500" />
            <div className="text-xs text-[var(--theme-text)]/60">Points</div>
            <div className="text-sm font-bold text-[var(--theme-text)]">{currentPoints}</div>
          </div>
          <div className="p-2 rounded-lg bg-[var(--theme-secondary)]/20">
            <Trophy className="w-4 h-4 mx-auto mb-1 text-purple-500" />
            <div className="text-xs text-[var(--theme-text)]/60">Next Level</div>
            <div className="text-sm font-bold text-[var(--theme-text)]">{pointsForNextLevel}</div>
          </div>
        </div>

        <div className="p-3 rounded-lg bg-gradient-to-r from-[var(--theme-primary)]/10 to-[var(--theme-accent)]/10 border border-[var(--theme-border-color)]">
          <p className="text-xs text-[var(--theme-text)]/80">
            🎯 Complete activities, track expenses, and maintain your daily streak to earn more Vibe Points!
          </p>
        </div>
      </GlassCardContent>
    </GlassCard>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}