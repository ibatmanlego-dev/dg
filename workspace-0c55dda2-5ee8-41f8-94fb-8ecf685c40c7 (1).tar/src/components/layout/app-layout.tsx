'use client'

import React, { useState } from 'react'
import { BottomNav } from '@/components/ui/bottom-nav'
import { GlassCard } from '@/components/ui/glass-card'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { useTheme } from '@/contexts/ThemeContext'
import { 
  Home, 
  CheckSquare, 
  DollarSign, 
  Heart, 
  Calendar, 
  Settings,
  CalendarDays,
  Shield,
  Sparkles
} from 'lucide-react'

// Import components
import { Dashboard } from '@/components/dashboard/dashboard'
import ActivityManager from '@/components/ActivityManager'
import BudgetTracker from '@/components/BudgetTracker'
import { HealthManager } from '@/components/health/health-manager'
import { PeriodTracker } from '@/components/period/period-tracker'
import { SettingsManager } from '@/components/settings/settings-manager'
import { VaultManager } from '@/components/vault/vault-manager'
import { DateRangeFilter } from '@/components/filters/date-range-filter'
import { useSettings } from '@/contexts/SettingsContext'

type TabType = 'dashboard' | 'activities' | 'expenses' | 'health' | 'period' | 'vault' | 'settings'

export function AppLayout() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard')
  const { theme } = useTheme()
  const { periodTrackerEnabled, vaultEnabled, userName, profilePicture } = useSettings()

  const getUserInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .slice(0, 2)
      .join('')
  }

  const navItems = [
    {
      id: 'dashboard',
      label: 'Home',
      icon: <Home className="w-5 h-5" />,
      active: activeTab === 'dashboard',
      onClick: () => setActiveTab('dashboard'),
    },
    {
      id: 'activities',
      label: 'Activities',
      icon: <CheckSquare className="w-5 h-5" />,
      active: activeTab === 'activities',
      onClick: () => setActiveTab('activities'),
    },
    {
      id: 'expenses',
      label: 'Expenses',
      icon: <DollarSign className="w-5 h-5" />,
      active: activeTab === 'expenses',
      onClick: () => setActiveTab('expenses'),
    },
    {
      id: 'health',
      label: 'Health',
      icon: <Heart className="w-5 h-5" />,
      active: activeTab === 'health',
      onClick: () => setActiveTab('health'),
    },
    ...(periodTrackerEnabled ? [{
      id: 'period' as const,
      label: 'Period',
      icon: <Calendar className="w-5 h-5" />,
      active: activeTab === 'period',
      onClick: () => setActiveTab('period'),
    }] : []),
    ...(vaultEnabled ? [{
      id: 'vault' as const,
      label: 'Vault',
      icon: <Shield className="w-5 h-5" />,
      active: activeTab === 'vault',
      onClick: () => setActiveTab('vault'),
    }] : []),
    {
      id: 'settings',
      label: 'Settings',
      icon: <Settings className="w-5 h-5" />,
      active: activeTab === 'settings',
      onClick: () => setActiveTab('settings'),
    },
  ]

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />
      case 'activities':
        return <ActivityManager />
      case 'expenses':
        return <BudgetTracker />
      case 'health':
        return <HealthManager />
      case 'period':
        return periodTrackerEnabled ? <PeriodTracker /> : <Dashboard />
      case 'vault':
        return vaultEnabled ? <VaultManager /> : <Dashboard />
      case 'settings':
        return <SettingsManager />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="relative min-h-screen gradient-bg">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-40 p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6" style={{ color: theme.accent }} />
          <h1 className="text-xl font-bold neon-text" style={{ color: theme.text }}>
            VibeTracker
          </h1>
        </div>
        
        {/* User Profile */}
        <div className="flex items-center gap-2">
          <span 
            className="text-sm font-medium hidden sm:block" 
            style={{ color: theme.text }}
          >
            {userName}
          </span>
          <Avatar className="w-8 h-8">
            {profilePicture ? (
              <AvatarImage src={profilePicture} alt="Profile" />
            ) : (
              <AvatarFallback 
                style={{ 
                  backgroundColor: theme.primary,
                  color: '#ffffff'
                }}
                className="text-xs font-semibold"
              >
                {getUserInitials(userName)}
              </AvatarFallback>
            )}
          </Avatar>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="pt-20 pb-24 px-4">
        <div className="max-w-6xl mx-auto space-y-4">
          {/* Date Range Filter - Show on data tabs */}
          {(activeTab === 'activities' || activeTab === 'expenses' || activeTab === 'health') && (
            <DateRangeFilter />
          )}
          
          <GlassCard variant="enhanced" className="p-6">
            {renderContent()}
          </GlassCard>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-40">
        <GlassCard variant="dark" className="mx-4 mb-4 rounded-t-2xl">
          <BottomNav items={navItems} />
        </GlassCard>
      </div>
    </div>
  )
}