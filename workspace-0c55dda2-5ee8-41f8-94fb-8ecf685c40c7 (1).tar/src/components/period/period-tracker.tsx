'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Calendar, Plus, Clock, Droplets, Activity, Heart } from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'

interface PeriodEntry {
  id: string
  date: string
  flow: 'light' | 'medium' | 'heavy'
  symptoms: string[]
  notes?: string
  mood: 'great' | 'good' | 'okay' | 'bad' | 'terrible'
}

interface CycleInfo {
  averageLength: number
  averagePeriodLength: number
  lastPeriodStart: string | null
  nextPeriodPredicted: string | null
  daysUntilNext: number | null
}

const flowLevels = [
  { value: 'light', label: 'Light', color: '#10b981' },
  { value: 'medium', label: 'Medium', color: '#f59e0b' },
  { value: 'heavy', label: 'Heavy', color: '#ef4444' }
]

const moodLevels = [
  { value: 'great', label: 'Great', emoji: '😊' },
  { value: 'good', label: 'Good', emoji: '🙂' },
  { value: 'okay', label: 'Okay', emoji: '😐' },
  { value: 'bad', label: 'Bad', emoji: '😔' },
  { value: 'terrible', label: 'Terrible', emoji: '😢' }
]

const commonSymptoms = [
  'Cramps', 'Bloating', 'Headache', 'Fatigue', 'Back Pain',
  'Breast Tenderness', 'Acne', 'Food Cravings', 'Nausea', 'Insomnia'
]

interface PeriodTrackerProps {
  showAddForm?: boolean
  onToggleAddForm?: () => void
}

export function PeriodTracker({ showAddForm: externalShowAddForm, onToggleAddForm }: PeriodTrackerProps) {
  const { theme } = useTheme()
  const [entries, setEntries] = useState<PeriodEntry[]>([
    {
      id: '1',
      date: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      flow: 'medium',
      symptoms: ['Cramps', 'Bloating'],
      mood: 'okay',
      notes: 'Regular period'
    }
  ])
  const [internalShowAddForm, setInternalShowAddForm] = useState(false)
  
  const showAddFormState = externalShowAddForm ?? internalShowAddForm
  const setShowAddForm = onToggleAddForm ?? setInternalShowAddForm
  const [newEntry, setNewEntry] = useState({
    date: new Date().toISOString().split('T')[0],
    flow: 'medium' as const,
    symptoms: [] as string[],
    mood: 'okay' as const,
    notes: ''
  })
  const [cycleInfo, setCycleInfo] = useState<CycleInfo>({
    averageLength: 28,
    averagePeriodLength: 5,
    lastPeriodStart: null,
    nextPeriodPredicted: null,
    daysUntilNext: null
  })

  useEffect(() => {
    calculateCycleInfo()
  }, [entries])

  const calculateCycleInfo = () => {
    if (entries.length < 2) {
      setCycleInfo({
        averageLength: 28,
        averagePeriodLength: 5,
        lastPeriodStart: null,
        nextPeriodPredicted: null,
        daysUntilNext: null
      })
      return
    }

    const sortedEntries = [...entries].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    )

    // Find period start dates (assuming first day of each period)
    const periodStarts: Date[] = []
    let lastPeriodDate: Date | null = null

    sortedEntries.forEach(entry => {
      const entryDate = new Date(entry.date)
      if (!lastPeriodDate || (entryDate.getTime() - lastPeriodDate.getTime()) > 7 * 24 * 60 * 60 * 1000) {
        periodStarts.push(entryDate)
        lastPeriodDate = entryDate
      }
    })

    if (periodStarts.length >= 2) {
      // Calculate average cycle length
      const cycleLengths: number[] = []
      for (let i = 1; i < periodStarts.length; i++) {
        const diff = (periodStarts[i].getTime() - periodStarts[i-1].getTime()) / (24 * 60 * 60 * 1000)
        cycleLengths.push(diff)
      }
      const averageLength = Math.round(cycleLengths.reduce((a, b) => a + b, 0) / cycleLengths.length)

      // Calculate average period length
      const periodLengths: number[] = []
      let currentPeriodStart = periodStarts[0]
      let periodEnd = currentPeriodStart

      sortedEntries.forEach(entry => {
        const entryDate = new Date(entry.date)
        if (entryDate.getTime() - periodEnd.getTime() <= 2 * 24 * 60 * 60 * 1000) {
          periodEnd = entryDate
        } else {
          periodLengths.push((periodEnd.getTime() - currentPeriodStart.getTime()) / (24 * 60 * 60 * 1000) + 1)
          currentPeriodStart = entryDate
          periodEnd = entryDate
        }
      })

      const averagePeriodLength = periodLengths.length > 0 
        ? Math.round(periodLengths.reduce((a, b) => a + b, 0) / periodLengths.length)
        : 5

      const lastPeriodStart = periodStarts[periodStarts.length - 1]
      const nextPeriodPredicted = new Date(lastPeriodStart.getTime() + averageLength * 24 * 60 * 60 * 1000)
      const daysUntilNext = Math.ceil((nextPeriodPredicted.getTime() - Date.now()) / (24 * 60 * 60 * 1000))

      setCycleInfo({
        averageLength,
        averagePeriodLength,
        lastPeriodStart: lastPeriodStart.toISOString().split('T')[0],
        nextPeriodPredicted: nextPeriodPredicted.toISOString().split('T')[0],
        daysUntilNext
      })
    }
  }

  const handleAddEntry = () => {
    if (newEntry.date) {
      const entry: PeriodEntry = {
        id: Date.now().toString(),
        date: newEntry.date,
        flow: newEntry.flow,
        symptoms: newEntry.symptoms,
        mood: newEntry.mood,
        notes: newEntry.notes || undefined
      }
      setEntries([...entries, entry])
      setNewEntry({
        date: new Date().toISOString().split('T')[0],
        flow: 'medium',
        symptoms: [],
        mood: 'okay',
        notes: ''
      })
      setShowAddForm(false)
    }
  }

  const handleDeleteEntry = (id: string) => {
    if (confirm('Are you sure you want to delete this entry?')) {
      setEntries(entries.filter(entry => entry.id !== id))
    }
  }

  const toggleSymptom = (symptom: string) => {
    setNewEntry(prev => ({
      ...prev,
      symptoms: prev.symptoms.includes(symptom)
        ? prev.symptoms.filter(s => s !== symptom)
        : [...prev.symptoms, symptom]
    }))
  }

  const getPhaseInfo = () => {
    if (!cycleInfo.nextPeriodPredicted || cycleInfo.daysUntilNext === null) {
      return { phase: 'Tracking...', color: theme.text, description: 'Add more entries to predict your cycle' }
    }

    if (cycleInfo.daysUntilNext <= 0) {
      return { phase: 'Period', color: '#ef4444', description: 'Your period is expected now' }
    } else if (cycleInfo.daysUntilNext <= 7) {
      return { phase: 'Premenstrual', color: '#f59e0b', description: `${cycleInfo.daysUntilNext} days until period` }
    } else if (cycleInfo.daysUntilNext <= 14) {
      return { phase: 'Follicular', color: '#10b981', description: `${cycleInfo.daysUntilNext} days until period` }
    } else {
      return { phase: 'Ovulation', color: '#6366f1', description: `${cycleInfo.daysUntilNext} days until period` }
    }
  }

  const phaseInfo = getPhaseInfo()

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Droplets className="w-6 h-6" style={{ color: theme.primary }} />
          <h2 className="text-2xl font-bold">Period Tracker</h2>
        </div>
        <Button
          onClick={() => setShowAddForm(!showAddFormState)}
          style={{ backgroundColor: theme.primary }}
          className="text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Entry
        </Button>
      </div>

      {/* Cycle Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Current Phase</p>
                <p style={{ color: phaseInfo.color }} className="text-lg font-bold">
                  {phaseInfo.phase}
                </p>
              </div>
              <Activity className="w-8 h-8" style={{ color: phaseInfo.color }} />
            </div>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Cycle Length</p>
                <p style={{ color: theme.text }} className="text-lg font-bold">
                  {cycleInfo.averageLength} days
                </p>
              </div>
              <Calendar className="w-8 h-8" style={{ color: theme.primary }} />
            </div>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Period Length</p>
                <p style={{ color: theme.text }} className="text-lg font-bold">
                  {cycleInfo.averagePeriodLength} days
                </p>
              </div>
              <Clock className="w-8 h-8" style={{ color: theme.accent }} />
            </div>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Next Period</p>
                <p style={{ color: theme.text }} className="text-lg font-bold">
                  {cycleInfo.nextPeriodPredicted ? 
                    new Date(cycleInfo.nextPeriodPredicted).toLocaleDateString() : 
                    '---'
                  }
                </p>
              </div>
              <Droplets className="w-8 h-8" style={{ color: theme.secondary }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Phase Description */}
      <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
        <CardContent className="p-4">
          <p style={{ color: theme.text }}>{phaseInfo.description}</p>
        </CardContent>
      </Card>

      {/* Add Entry Form */}
      {showAddFormState && (
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardHeader>
            <CardTitle style={{ color: theme.text }}>Add Period Entry</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Input
                type="date"
                value={newEntry.date}
                onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              />
              <select
                value={newEntry.flow}
                onChange={(e) => setNewEntry({ ...newEntry, flow: e.target.value as any })}
                className="flex-1 p-2 rounded border"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              >
                {flowLevels.map(level => (
                  <option key={level.value} value={level.value}>{level.label}</option>
                ))}
              </select>
              <select
                value={newEntry.mood}
                onChange={(e) => setNewEntry({ ...newEntry, mood: e.target.value as any })}
                className="flex-1 p-2 rounded border"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              >
                {moodLevels.map(level => (
                  <option key={level.value} value={level.value}>
                    {level.emoji} {level.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm mb-2">Symptoms:</p>
              <div className="flex flex-wrap gap-2">
                {commonSymptoms.map(symptom => (
                  <Button
                    key={symptom}
                    size="sm"
                    variant={newEntry.symptoms.includes(symptom) ? 'default' : 'outline'}
                    onClick={() => toggleSymptom(symptom)}
                  >
                    {symptom}
                  </Button>
                ))}
              </div>
            </div>
            <Textarea
              placeholder="Notes (optional)"
              value={newEntry.notes}
              onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <div className="flex gap-2">
              <Button
                onClick={handleAddEntry}
                style={{ backgroundColor: theme.primary }}
                className="text-white"
              >
                Add Entry
              </Button>
              <Button
                variant="outline"
                  onClick={() => setShowAddForm(false)}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Period Entries */}
      <div className="space-y-4">
        <h3 style={{ color: theme.text }} className="text-lg font-semibold">History</h3>
        {entries.length === 0 ? (
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardContent className="text-center py-8">
              <p style={{ color: theme.text, opacity: 0.7 }}>
                No entries yet. Start tracking your period!
              </p>
            </CardContent>
          </Card>
        ) : (
          [...entries]
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(entry => {
              const flowLevel = flowLevels.find(f => f.value === entry.flow)
              const moodLevel = moodLevels.find(m => m.value === entry.mood)
              return (
                <Card
                  key={entry.id}
                  style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}
                  className="transition-all duration-200 hover:shadow-lg"
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Calendar className="w-4 h-4" style={{ color: theme.text, opacity: 0.6 }} />
                          <span style={{ color: theme.text }} className="font-medium">
                            {new Date(entry.date).toLocaleDateString()}
                          </span>
                          <Badge 
                            variant="secondary"
                            style={{ backgroundColor: flowLevel?.color + '20', color: flowLevel?.color }}
                          >
                            {flowLevel?.label}
                          </Badge>
                          <Badge variant="outline">
                            {moodLevel?.emoji} {moodLevel?.label}
                          </Badge>
                        </div>
                        {entry.symptoms.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-2">
                            {entry.symptoms.map(symptom => (
                              <Badge key={symptom} variant="outline" className="text-xs">
                                {symptom}
                              </Badge>
                            ))}
                          </div>
                        )}
                        {entry.notes && (
                          <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm">
                            {entry.notes}
                          </p>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteEntry(entry.id)}
                        style={{ borderColor: theme.borderColor, color: theme.text }}
                      >
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })
        )}
      </div>
    </div>
  )
}