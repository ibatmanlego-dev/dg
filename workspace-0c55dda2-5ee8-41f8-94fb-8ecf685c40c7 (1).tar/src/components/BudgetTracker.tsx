'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { 
  DollarSign, 
  TrendingUp, 
  AlertTriangle, 
  Plus,
  Edit,
  Trash2,
  Target,
  Calendar
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Budget {
  id: string
  category: string
  amount: number
  spent: number
  currency: string
  month: number
  year: number
  alertThreshold: number
  alertEnabled: boolean
}

interface Expense {
  id: string
  title: string
  category: string
  amount: number
  date: string
}

const CATEGORIES = [
  'Food & Dining',
  'Transportation',
  'Shopping',
  'Entertainment',
  'Bills & Utilities',
  'Healthcare',
  'Education',
  'Travel',
  'Other'
]

const COLORS = [
  'bg-blue-500',
  'bg-green-500',
  'bg-yellow-500',
  'bg-red-500',
  'bg-purple-500',
  'bg-pink-500',
  'bg-indigo-500',
  'bg-orange-500',
  'bg-teal-500'
]

export default function BudgetTracker() {
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [showAddBudget, setShowAddBudget] = useState(false)
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null)
  const [newBudget, setNewBudget] = useState({
    category: '',
    amount: '',
    alertThreshold: 80
  })
  const [newExpense, setNewExpense] = useState({
    title: '',
    category: '',
    amount: ''
  })
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth())
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  
  const { toast } = useToast()

  const currentMonthBudgets = budgets.filter(
    b => b.month === selectedMonth && b.year === selectedYear
  )

  const currentMonthExpenses = expenses.filter(
    e => new Date(e.date).getMonth() === selectedMonth && 
         new Date(e.date).getFullYear() === selectedYear
  )

  const totalBudget = currentMonthBudgets.reduce((sum, b) => sum + b.amount, 0)
  const totalSpent = currentMonthBudgets.reduce((sum, b) => sum + b.spent, 0)
  const remainingBudget = totalBudget - totalSpent

  const getBudgetStatus = (budget: Budget) => {
    const percentage = (budget.spent / budget.amount) * 100
    if (percentage >= 100) return { status: 'exceeded', color: 'bg-red-500' }
    if (percentage >= budget.alertThreshold * 100) return { status: 'warning', color: 'bg-yellow-500' }
    return { status: 'good', color: 'bg-green-500' }
  }

  const addBudget = () => {
    if (!newBudget.category || !newBudget.amount) {
      toast({
        title: "Missing Information",
        description: "Please fill in all budget fields.",
        variant: "destructive"
      })
      return
    }

    const budget: Budget = {
      id: Date.now().toString(),
      category: newBudget.category,
      amount: parseFloat(newBudget.amount),
      spent: 0,
      currency: 'USD',
      month: selectedMonth,
      year: selectedYear,
      alertThreshold: newBudget.alertThreshold / 100,
      alertEnabled: true
    }

    setBudgets(prev => [...prev, budget])
    setNewBudget({ category: '', amount: '', alertThreshold: 80 })
    setShowAddBudget(false)
    
    toast({
      title: "Budget Created",
      description: `Budget for ${newBudget.category} has been set.`
    })
  }

  const updateBudget = () => {
    if (!editingBudget) return

    setBudgets(prev => prev.map(b => 
      b.id === editingBudget.id ? editingBudget : b
    ))
    setEditingBudget(null)
    
    toast({
      title: "Budget Updated",
      description: `Budget for ${editingBudget.category} has been updated.`
    })
  }

  const deleteBudget = (id: string) => {
    setBudgets(prev => prev.filter(b => b.id !== id))
    toast({
      title: "Budget Deleted",
      description: "The budget has been removed."
    })
  }

  const addExpense = () => {
    if (!newExpense.title || !newExpense.category || !newExpense.amount) {
      toast({
        title: "Missing Information",
        description: "Please fill in all expense fields.",
        variant: "destructive"
      })
      return
    }

    const expense: Expense = {
      id: Date.now().toString(),
      title: newExpense.title,
      category: newExpense.category,
      amount: parseFloat(newExpense.amount),
      date: new Date().toISOString()
    }

    setExpenses(prev => [...prev, expense])

    // Update budget spent amount
    setBudgets(prev => prev.map(b => {
      if (b.category === newExpense.category && 
          b.month === selectedMonth && 
          b.year === selectedYear) {
        return { ...b, spent: b.spent + parseFloat(newExpense.amount) }
      }
      return b
    }))

    setNewExpense({ title: '', category: '', amount: '' })
    
    toast({
      title: "Expense Added",
      description: `${newExpense.title} has been recorded.`
    })

    // Check budget alerts
    const budget = currentMonthBudgets.find(b => b.category === newExpense.category)
    if (budget && budget.alertEnabled) {
      const percentage = (budget.spent / budget.amount) * 100
      if (percentage >= budget.alertThreshold * 100) {
        toast({
          title: "Budget Alert",
          description: `You've used ${percentage.toFixed(1)}% of your ${newExpense.category} budget!`,
          variant: "destructive"
        })
      }
    }
  }

  const deleteExpense = (id: string, category: string, amount: number) => {
    setExpenses(prev => prev.filter(e => e.id !== id))
    
    // Update budget spent amount
    setBudgets(prev => prev.map(b => {
      if (b.category === category && 
          b.month === selectedMonth && 
          b.year === selectedYear) {
        return { ...b, spent: Math.max(0, b.spent - amount) }
      }
      return b
    }))
    
    toast({
      title: "Expense Deleted",
      description: "The expense has been removed."
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  const getMonthName = (month: number) => {
    return new Date(2024, month, 1).toLocaleString('default', { month: 'long' })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-semibold">Budget Tracker</h2>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(parseInt(value))}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 12 }, (_, i) => (
                <SelectItem key={i} value={i.toString()}>
                  {getMonthName(i)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total Budget</p>
                <p className="text-2xl font-bold">{formatCurrency(totalBudget)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total Spent</p>
                <p className="text-2xl font-bold">{formatCurrency(totalSpent)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Remaining</p>
                <p className={`text-2xl font-bold ${remainingBudget < 0 ? 'text-red-500' : 'text-green-500'}`}>
                  {formatCurrency(remainingBudget)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Budget/Expense */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Budget Management</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAddBudget(!showAddBudget)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Budget
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showAddBudget && (
              <div className="space-y-4 p-4 border rounded-lg">
                <div>
                  <Label htmlFor="budget-category">Category</Label>
                  <Select value={newBudget.category} onValueChange={(value) => setNewBudget(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="budget-amount">Budget Amount</Label>
                  <Input
                    id="budget-amount"
                    type="number"
                    value={newBudget.amount}
                    onChange={(e) => setNewBudget(prev => ({ ...prev, amount: e.target.value }))}
                    placeholder="0.00"
                  />
                </div>
                
                <div>
                  <Label htmlFor="alert-threshold">Alert Threshold ({newBudget.alertThreshold}%)</Label>
                  <Input
                    id="alert-threshold"
                    type="range"
                    min="50"
                    max="100"
                    value={newBudget.alertThreshold}
                    onChange={(e) => setNewBudget(prev => ({ ...prev, alertThreshold: parseInt(e.target.value) }))}
                  />
                </div>
                
                <Button onClick={addBudget} className="w-full">
                  Create Budget
                </Button>
              </div>
            )}

            <div className="space-y-3 max-h-64 overflow-y-auto">
              {currentMonthBudgets.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">
                  No budgets set for this month.
                </p>
              ) : (
                currentMonthBudgets.map((budget) => {
                  const status = getBudgetStatus(budget)
                  const percentage = (budget.spent / budget.amount) * 100
                  
                  return (
                    <div key={budget.id} className="p-4 border rounded-lg space-y-3">
                      {editingBudget?.id === budget.id ? (
                        <div className="space-y-3">
                          <Input
                            value={editingBudget.amount}
                            onChange={(e) => setEditingBudget(prev => prev ? { ...prev, amount: parseFloat(e.target.value) } : null)}
                            type="number"
                          />
                          <div className="flex items-center gap-2">
                            <Label htmlFor="edit-alert">Alert</Label>
                            <Switch
                              id="edit-alert"
                              checked={editingBudget.alertEnabled}
                              onCheckedChange={(checked) => setEditingBudget(prev => prev ? { ...prev, alertEnabled: checked } : null)}
                            />
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" onClick={updateBudget}>Save</Button>
                            <Button size="sm" variant="outline" onClick={() => setEditingBudget(null)}>Cancel</Button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className={`w-3 h-3 rounded-full ${status.color}`} />
                              <span className="font-medium">{budget.category}</span>
                              {status.status === 'warning' && (
                                <AlertTriangle className="w-4 h-4 text-yellow-500" />
                              )}
                              {status.status === 'exceeded' && (
                                <Badge variant="destructive">Exceeded</Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setEditingBudget(budget)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteBudget(budget.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>{formatCurrency(budget.spent)} / {formatCurrency(budget.amount)}</span>
                              <span>{percentage.toFixed(1)}%</span>
                            </div>
                            <Progress value={Math.min(percentage, 100)} className="h-2" />
                          </div>
                        </>
                      )}
                    </div>
                  )
                })
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Add Expense</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="expense-title">Title</Label>
              <Input
                id="expense-title"
                value={newExpense.title}
                onChange={(e) => setNewExpense(prev => ({ ...prev, title: e.target.value }))}
                placeholder="What did you spend on?"
              />
            </div>
            
            <div>
              <Label htmlFor="expense-category">Category</Label>
              <Select value={newExpense.category} onValueChange={(value) => setNewExpense(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="expense-amount">Amount</Label>
              <Input
                id="expense-amount"
                type="number"
                value={newExpense.amount}
                onChange={(e) => setNewExpense(prev => ({ ...prev, amount: e.target.value }))}
                placeholder="0.00"
              />
            </div>
            
            <Button onClick={addExpense} className="w-full">
              Add Expense
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Expenses */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          {currentMonthExpenses.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">
              No expenses recorded for this month.
            </p>
          ) : (
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {currentMonthExpenses.slice(-10).reverse().map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{expense.title}</p>
                    <p className="text-sm text-muted-foreground">
                      {expense.category} • {new Date(expense.date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{formatCurrency(expense.amount)}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteExpense(expense.id, expense.category, expense.amount)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}