'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Calendar, Clock, Plus, Search, Filter, ChevronDown } from 'lucide-react'
import { useData } from '@/contexts/DataContext'
import { useTheme } from '@/contexts/ThemeContext'

interface Activity {
  id: string
  title: string
  description: string
  category: string
  date: string
  duration: number
  completed: boolean
}

const categories = [
  'Work',
  'Exercise',
  'Hobby',
  'Social',
  'Learning',
  'Health',
  'Other'
]

interface ActivitiesManagerProps {
  showAddForm?: boolean
  onToggleAddForm?: () => void
}

export function ActivitiesManager({ showAddForm: externalShowAddForm, onToggleAddForm }: ActivitiesManagerProps) {
  const { theme } = useTheme()
  const { filteredActivities, addActivity, updateActivity, deleteActivity } = useData()
  const [internalShowAddForm, setInternalShowAddForm] = useState(false)
  
  const showAddFormState = externalShowAddForm ?? internalShowAddForm
  const setShowAddForm = onToggleAddForm ?? setInternalShowAddForm
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [newActivity, setNewActivity] = useState({
    title: '',
    description: '',
    category: 'Work',
    duration: 30
  })

  const displayActivities = filteredActivities.filter(activity => {
    const matchesSearch = activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (activity.description && activity.description.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = selectedCategory === 'All' || activity.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleAddActivity = () => {
    if (newActivity.title.trim()) {
      addActivity({
        ...newActivity,
        date: new Date().toISOString(),
        completed: false
      })
      setNewActivity({
        title: '',
        description: '',
        category: 'Work',
        duration: 30
      })
      setShowAddForm(false)
    }
  }

  const toggleActivityComplete = (id: string) => {
    const activity = filteredActivities.find(a => a.id === id)
    if (activity) {
      updateActivity(id, { ...activity, completed: !activity.completed })
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Activities</h2>
        <Button
          onClick={() => setShowAddForm(!showAddFormState)}
          style={{ backgroundColor: theme.primary }}
          className="text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Activity
        </Button>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 opacity-50" />
          <Input
            placeholder="Search activities..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            style={{ 
              backgroundColor: theme.cardBg,
              borderColor: theme.borderColor,
              color: theme.text
            }}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={selectedCategory === 'All' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('All')}
            size="sm"
          >
            All
          </Button>
          {categories.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(category)}
              size="sm"
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Add Activity Form */}
      {showAddFormState && (
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardHeader>
            <CardTitle style={{ color: theme.text }}>Add New Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Activity title"
              value={newActivity.title}
              onChange={(e) => setNewActivity({ ...newActivity, title: e.target.value })}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <Textarea
              placeholder="Description (optional)"
              value={newActivity.description}
              onChange={(e) => setNewActivity({ ...newActivity, description: e.target.value })}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <div className="flex gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="flex-1 justify-between"
                    style={{ 
                      backgroundColor: theme.secondary,
                      borderColor: theme.borderColor,
                      color: theme.name === 'light' ? '#000000' : theme.text
                    }}
                  >
                    {newActivity.category}
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {categories.map(category => (
                    <DropdownMenuItem
                      key={category}
                      onClick={() => setNewActivity({ ...newActivity, category: category })}
                      style={{ color: theme.text }}
                    >
                      {category}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              <Input
                type="number"
                placeholder="Duration (min)"
                value={newActivity.duration}
                onChange={(e) => setNewActivity({ ...newActivity, duration: parseInt(e.target.value) || 0 })}
                className="w-32"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleAddActivity}
                style={{ backgroundColor: theme.primary }}
                className="text-white"
              >
                Add Activity
              </Button>
              <Button
                variant="outline"
                  onClick={() => setShowAddForm(false)}
                  style={{ borderColor: theme.borderColor, color: theme.text }}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Activities List */}
      <div className="space-y-4">
        {displayActivities.length === 0 ? (
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardContent className="text-center py-8">
              <p style={{ color: theme.text, opacity: 0.7 }}>
                No activities found. Start by adding your first activity!
              </p>
            </CardContent>
          </Card>
        ) : (
          displayActivities.map(activity => (
            <Card
              key={activity.id}
              style={{ 
                backgroundColor: theme.cardBg, 
                borderColor: theme.borderColor,
                opacity: activity.completed ? 0.6 : 1
              }}
              className={`transition-all duration-200 ${activity.completed ? 'line-through' : ''}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 style={{ color: theme.text }} className="font-semibold">
                        {activity.title}
                      </h3>
                      <Badge variant="secondary">{activity.category}</Badge>
                      {activity.completed && (
                        <Badge style={{ backgroundColor: theme.accent }}>Completed</Badge>
                      )}
                    </div>
                    {activity.description && (
                      <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm mb-2">
                        {activity.description}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-sm" style={{ color: theme.text, opacity: 0.6 }}>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(activity.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {activity.duration} min
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={activity.completed ? "outline" : "default"}
                      onClick={() => toggleActivityComplete(activity.id)}
                      style={{ 
                        backgroundColor: activity.completed ? 'transparent' : theme.accent,
                        borderColor: theme.accent,
                        color: activity.completed ? theme.accent : 'white'
                      }}
                    >
                      {activity.completed ? 'Undo' : 'Complete'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => deleteActivity(activity.id)}
                      style={{ borderColor: theme.borderColor, color: theme.text }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}