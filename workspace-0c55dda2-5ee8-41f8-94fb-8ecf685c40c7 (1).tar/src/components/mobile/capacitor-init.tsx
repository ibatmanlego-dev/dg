'use client'

import { useEffect, useState } from 'react'
import { useCapacitor } from '@/hooks/use-capacitor'

export function CapacitorInit() {
  const [mounted, setMounted] = useState(false)
  const { 
    isNative, 
    setStatusBarStyle, 
    hideSplashScreen,
    requestNotificationPermission 
  } = useCapacitor()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && isNative) {
      const initializeNative = async () => {
        try {
          // Set status bar style
          await setStatusBarStyle('DARK')
          
          // Hide splash screen after a delay
          setTimeout(async () => {
            await hideSplashScreen()
          }, 2000)
          
          // Request notification permissions
          await requestNotificationPermission()
          
          console.log('Capacitor initialized successfully')
        } catch (error) {
          console.error('Error initializing Capacitor:', error)
        }
      }

      initializeNative()
    }
  }, [mounted, isNative, setStatusBarStyle, hideSplashScreen, requestNotificationPermission])

  return null
}