'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Heart, Plus, Search, Activity, Droplets, Weight, Moon } from 'lucide-react'
import { useData } from '@/contexts/DataContext'
import { useTheme } from '@/contexts/ThemeContext'
import type { HealthMetric } from '@/contexts/DataContext'

const metricTypes = [
  { value: 'weight', label: 'Weight', unit: 'kg', icon: Weight },
  { value: 'blood_pressure', label: 'Blood Pressure', unit: 'mmHg', icon: Heart },
  { value: 'heart_rate', label: 'Heart Rate', unit: 'bpm', icon: Activity },
  { value: 'water', label: 'Water Intake', unit: 'ml', icon: Droplets },
  { value: 'sleep', label: 'Sleep', unit: 'hours', icon: Moon },
  { value: 'exercise', label: 'Exercise', unit: 'min', icon: Activity }
]

interface HealthManagerProps {
  showAddForm?: boolean
  onToggleAddForm?: () => void
}

export function HealthManager({ showAddForm: externalShowAddForm, onToggleAddForm }: HealthManagerProps) {
  const { theme } = useTheme()
  const { filteredHealthMetrics, addHealthMetric, deleteHealthMetric } = useData()
  const [internalShowAddForm, setInternalShowAddForm] = useState(false)
  
  const showAddFormState = externalShowAddForm ?? internalShowAddForm
  const setShowAddForm = onToggleAddForm ?? setInternalShowAddForm
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState('All')
  const [newMetric, setNewMetric] = useState({
    type: 'weight' as const,
    value: '',
    notes: ''
  })

  const displayMetrics = (filteredHealthMetrics || []).filter(metric => {
    const matchesSearch = metric.notes?.toLowerCase().includes(searchTerm.toLowerCase()) || false
    const matchesType = selectedType === 'All' || metric.type === selectedType
    return matchesSearch && matchesType
  })

  const getLatestMetrics = () => {
    const latest: Record<string, HealthMetric> = {}
    displayMetrics.forEach(metric => {
      if (!latest[metric.type] || new Date(metric.date) > new Date(latest[metric.type].date)) {
        latest[metric.type] = metric
      }
    })
    return latest
  }

  const latestMetrics = getLatestMetrics()

  const handleAddMetric = () => {
    if (newMetric.value.trim()) {
      const metricType = metricTypes.find(t => t.value === newMetric.type)
      if (metricType) {
        addHealthMetric({
          type: newMetric.type,
          value: newMetric.value,
          unit: metricType.unit,
          date: new Date().toISOString(),
          notes: newMetric.notes || undefined
        })
        setNewMetric({
          type: 'weight',
          value: '',
          notes: ''
        })
        setShowAddForm(false)
      }
    }
  }

  const getMetricIcon = (type: string) => {
    const metricType = metricTypes.find(t => t.value === type)
    return metricType ? metricType.icon : Activity
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Health Tracking</h2>
        <Button
          onClick={() => setShowAddForm(!showAddFormState)}
          style={{ backgroundColor: theme.primary }}
          className="text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Metric
        </Button>
      </div>

      {/* Latest Metrics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metricTypes.map(type => {
          const Icon = type.icon
          const latest = latestMetrics[type.value]
          return (
            <Card key={type.value} style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">{type.label}</p>
                    <p style={{ color: theme.text }} className="text-xl font-bold">
                      {latest ? `${latest.value} ${latest.unit}` : 'No data'}
                    </p>
                    {latest && (
                      <p style={{ color: theme.text, opacity: 0.6 }} className="text-xs">
                        {new Date(latest.date).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <Icon className="w-8 h-8" style={{ color: theme.accent }} />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 opacity-50" />
          <Input
            placeholder="Search health metrics..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            style={{ 
              backgroundColor: theme.cardBg,
              borderColor: theme.borderColor,
              color: theme.text
            }}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={selectedType === 'All' ? 'default' : 'outline'}
            onClick={() => setSelectedType('All')}
            size="sm"
          >
            All
          </Button>
          {metricTypes.map(type => (
            <Button
              key={type.value}
              variant={selectedType === type.value ? 'default' : 'outline'}
              onClick={() => setSelectedType(type.value)}
              size="sm"
            >
              {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Add Metric Form */}
      {showAddFormState && (
        <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
          <CardHeader>
            <CardTitle style={{ color: theme.text }}>Add Health Metric</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <select
                value={newMetric.type}
                onChange={(e) => setNewMetric({ ...newMetric, type: e.target.value as any })}
                className="flex-1 p-2 rounded border"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              >
                {metricTypes.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label} ({type.unit})
                  </option>
                ))}
              </select>
              <Input
                placeholder="Value"
                value={newMetric.value}
                onChange={(e) => setNewMetric({ ...newMetric, value: e.target.value })}
                className="flex-1"
                style={{ 
                  backgroundColor: theme.secondary,
                  borderColor: theme.borderColor,
                  color: theme.text
                }}
              />
            </div>
            <Input
              placeholder="Notes (optional)"
              value={newMetric.notes}
              onChange={(e) => setNewMetric({ ...newMetric, notes: e.target.value })}
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
            <div className="flex gap-2">
              <Button
                onClick={handleAddMetric}
                style={{ backgroundColor: theme.primary }}
                className="text-white"
              >
                Add Metric
              </Button>
              <Button
                variant="outline"
                  onClick={() => setShowAddForm(false)}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Health Metrics List */}
      <div className="space-y-4">
        {displayMetrics.length === 0 ? (
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardContent className="text-center py-8">
              <p style={{ color: theme.text, opacity: 0.7 }}>
                No health metrics found. Start by adding your first metric!
              </p>
            </CardContent>
          </Card>
        ) : (
          displayMetrics
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(metric => {
              const Icon = getMetricIcon(metric.type)
              const metricType = metricTypes.find(t => t.value === metric.type)
              return (
                <Card
                  key={metric.id}
                  style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}
                  className="transition-all duration-200 hover:shadow-lg"
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Icon className="w-5 h-5" style={{ color: theme.accent }} />
                          <h3 style={{ color: theme.text }} className="font-semibold">
                            {metricType?.label || metric.type}
                          </h3>
                          <Badge variant="secondary">
                            {metric.value} {metric.unit}
                          </Badge>
                        </div>
                        {metric.notes && (
                          <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm mb-2">
                            {metric.notes}
                          </p>
                        )}
                        <div className="text-sm" style={{ color: theme.text, opacity: 0.6 }}>
                          {new Date(metric.date).toLocaleDateString()} at {new Date(metric.date).toLocaleTimeString()}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteHealthMetric(metric.id)}
                        style={{ borderColor: theme.borderColor, color: theme.text }}
                      >
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })
        )}
      </div>
    </div>
  )
}