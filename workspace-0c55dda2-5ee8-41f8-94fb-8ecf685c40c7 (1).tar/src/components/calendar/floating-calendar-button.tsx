'use client'

import React, { useState } from 'react'
import { Calendar as CalendarIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { GlobalCalendarView } from './global-calendar-view'

export function FloatingCalendarButton() {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false)

  return (
    <>
      <Button
        size="lg"
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-40 bg-primary hover:bg-primary/90"
        onClick={() => setIsCalendarOpen(true)}
      >
        <CalendarIcon className="h-6 w-6" />
      </Button>

      <GlobalCalendarView
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
      />
    </>
  )
}