'use client'

import React, { useState, useEffect } from 'react'
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, addMonths, subMonths, isSameMonth, isSameDay, isToday, parseISO } from 'date-fns'
import { X, ChevronLeft, ChevronRight, Calendar as CalendarIcon, Activity, DollarSign, Heart, Plus, Palette } from 'lucide-react'
import { useData } from '@/contexts/DataContext'
import { useSettings } from '@/contexts/SettingsContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'

interface CalendarEvent {
  id: string
  title: string
  date: Date
  type: 'activity' | 'expense' | 'health'
  category: string
  amount?: number
  priority?: string
  completed?: boolean
}

interface LegendColor {
  activityPending: string
  activityCompleted: string
  expense: string
  health: string
  calendarBackground: string
}

export function GlobalCalendarView({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { activities, expenses, healthMetrics } = useData()
  const { currency } = useSettings()
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const [legendColors, setLegendColors] = useState<LegendColor>({
    activityPending: '#dbeafe',
    activityCompleted: '#dcfce7',
    expense: '#fee2e2',
    health: '#f3e8ff',
    calendarBackground: '#ffffff'
  })
  const [showColorPicker, setShowColorPicker] = useState<string | null>(null)

  // Convert data to calendar events
  useEffect(() => {
    const calendarEvents: CalendarEvent[] = []

    // Add activities
    activities.forEach(activity => {
      if (activity.scheduledDate) {
        calendarEvents.push({
          id: activity.id,
          title: activity.title,
          date: parseISO(activity.scheduledDate),
          type: 'activity',
          category: activity.category,
          priority: activity.priority,
          completed: activity.completed
        })
      }
    })

    // Add expenses
    expenses.forEach(expense => {
      calendarEvents.push({
        id: expense.id,
        title: expense.title,
        date: parseISO(expense.date),
        type: 'expense',
        category: expense.category,
        amount: expense.amount
      })
    })

    // Add health metrics
    healthMetrics.forEach(metric => {
      calendarEvents.push({
        id: metric.id,
        title: `${metric.type}: ${metric.value}`,
        date: parseISO(metric.date),
        type: 'health',
        category: metric.type
      })
    })

    setEvents(calendarEvents)
  }, [activities, expenses, healthMetrics])

  const monthStart = startOfMonth(currentMonth)
  const monthEnd = endOfMonth(monthStart)
  const startDate = startOfWeek(monthStart)
  const endDate = endOfWeek(monthEnd)

  const days = []
  let day = startDate
  while (day <= endDate) {
    days.push(day)
    day = addDays(day, 1)
  }

  const getEventsForDay = (day: Date) => {
    return events.filter(event => isSameDay(event.date, day))
  }

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'activity':
        return <Activity className="h-3 w-3" />
      case 'expense':
        return <DollarSign className="h-3 w-3" />
      case 'health':
        return <Heart className="h-3 w-3" />
      default:
        return <CalendarIcon className="h-3 w-3" />
    }
  }

  const getEventColor = (type: string, completed?: boolean) => {
    if (type === 'activity') {
      const bgColor = completed ? legendColors.activityCompleted : legendColors.activityPending
      return bgColor
    }
    if (type === 'expense') {
      return legendColors.expense
    }
    if (type === 'health') {
      return legendColors.health
    }
    return 'bg-gray-100'
  }

  const renderDays = () => {
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    return daysOfWeek.map(day => (
      <div key={day} className="text-center text-sm font-medium py-2 text-black border-b border-gray-300">
        {day}
      </div>
    ))
  }

  const renderCells = () => {
    return days.map((day, index) => {
      const dayEvents = getEventsForDay(day)
      const isCurrentMonth = isSameMonth(day, monthStart)
      const isSelected = selectedDate && isSameDay(day, selectedDate)
      const isDayToday = isToday(day)

      return (
        <div
          key={index}
          className={`
            min-h-[120px] p-3 border cursor-pointer transition-colors relative
            ${!isCurrentMonth ? 'bg-gray-100' : 'bg-white'}
            ${isSelected ? 'bg-blue-100 border-blue-400' : ''}
            ${isDayToday ? 'bg-yellow-100 border-yellow-400' : ''}
            hover:bg-gray-50 border-gray-300
          `}
          onClick={() => setSelectedDate(day)}
        >
          {/* Date number - more prominent */}
          <div className={`
            text-lg font-bold mb-2 leading-none
            ${isDayToday ? 'text-blue-600 text-xl' : ''}
            ${!isCurrentMonth ? 'text-gray-500' : 'text-black'}
          `}>
            {format(day, 'd')}
          </div>
          
          {/* Events container */}
          <div className="space-y-1 max-h-[70px] overflow-hidden">
            {dayEvents.slice(0, 2).map((event, eventIndex) => (
              <TooltipProvider key={eventIndex}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className={`
                      text-xs p-1.5 rounded truncate flex items-center gap-1 leading-tight border
                    `}
                    style={{ 
                      backgroundColor: getEventColor(event.type, event.completed),
                      borderColor: getEventColor(event.type, event.completed) + 'cc',
                      color: 'var(--foreground)'
                    }}>
                      {getEventIcon(event.type)}
                      <span className="truncate">
                        {event.type === 'expense' && currency.symbol}
                        {event.type === 'expense' ? event.amount?.toFixed(2) : event.title}
                      </span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="text-sm">
                      <div className="font-medium">{event.title}</div>
                      <div className="text-gray-500">
                        {event.category} • {format(event.date, 'MMM d, yyyy')}
                      </div>
                      {event.amount && (
                        <div className="text-gray-500">
                          Amount: {currency.symbol}{event.amount.toFixed(2)}
                        </div>
                      )}
                      {event.priority && (
                        <div className="text-gray-500">
                          Priority: {event.priority}
                        </div>
                      )}
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
            {dayEvents.length > 2 && (
              <div className="text-xs text-gray-500 pl-1 font-medium">
                +{dayEvents.length - 2} more
              </div>
            )}
          </div>
        </div>
      )
    })
  }

  const handleColorChange = (colorType: keyof LegendColor, color: string) => {
    setLegendColors(prev => ({
      ...prev,
      [colorType]: color
    }))
  }

  const ColorPicker = ({ colorType, currentColor, label }: { colorType: keyof LegendColor; currentColor: string; label: string }) => (
    <Popover open={showColorPicker === colorType} onOpenChange={(open) => setShowColorPicker(open ? colorType : null)}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0 ml-auto">
          <Palette className="h-3 w-3" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64">
        <div className="space-y-3">
          <Label className="text-sm font-medium">Change {label} Color</Label>
          <div className="flex items-center gap-2">
            <Input
              type="color"
              value={currentColor}
              onChange={(e) => handleColorChange(colorType, e.target.value)}
              className="h-8 w-16"
            />
            <Input
              type="text"
              value={currentColor}
              onChange={(e) => handleColorChange(colorType, e.target.value)}
              className="flex-1 text-xs"
              placeholder="#000000"
            />
          </div>
          <div className="flex gap-1">
            {['#dbeafe', '#dcfce7', '#fee2e2', '#f3e8ff', '#fef3c7', '#e0e7ff', '#fce7f3', '#ccfbf1'].map((presetColor) => (
              <button
                key={presetColor}
                className="w-6 h-6 rounded border-gray-300 hover:scale-110 transition-transform"
                style={{ backgroundColor: presetColor }}
                onClick={() => handleColorChange(colorType, presetColor)}
              />
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )

  const selectedDateEvents = selectedDate ? getEventsForDay(selectedDate) : []

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-7xl max-h-[98vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between pb-4 flex-shrink-0">
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Global Calendar View
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="p-6 overflow-auto" style={{ maxHeight: 'calc(98vh - 80px)' }}>
          <div className="flex gap-6 min-w-max">
            {/* Calendar Grid */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <h2 className="text-lg font-semibold">
                  {format(currentMonth, 'MMMM yyyy')}
                </h2>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <div className="grid grid-cols-7 gap-0 border border-gray-300 rounded-lg overflow-hidden"
               style={{ backgroundColor: legendColors.calendarBackground }}>
                {renderDays()}
                {renderCells()}
              </div>
            </div>

            {/* Events Sidebar */}
            <div className="w-80 flex-shrink-0 overflow-y-auto">
              {selectedDate && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">
                      {format(selectedDate, 'MMMM d, yyyy')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedDateEvents.length > 0 ? (
                      <ScrollArea className="h-96">
                        <div className="space-y-3">
                          {selectedDateEvents.map(event => (
                            <div
                              key={event.id}
                              className="p-3 rounded-lg border"
                              style={{ 
                                backgroundColor: getEventColor(event.type, event.completed),
                                borderColor: getEventColor(event.type, event.completed) + 'cc',
                                color: 'var(--foreground)'
                              }}
                            >
                              <div className="flex items-start gap-2">
                                {getEventIcon(event.type)}
                                <div className="flex-1 min-w-0">
                                  <div className="font-medium text-sm truncate">
                                    {event.title}
                                  </div>
                                  <div className="text-xs opacity-75 mt-1">
                                    {event.category}
                                  </div>
                                  {event.amount && (
                                    <div className="text-xs opacity-75 mt-1">
                                      {currency.symbol}{event.amount.toFixed(2)}
                                    </div>
                                  )}
                                  {event.priority && (
                                    <Badge variant="secondary" className="mt-1 text-xs">
                                      {event.priority}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    ) : (
                      <div className="text-center text-muted-foreground py-8">
                        <CalendarIcon className="h-12 w-12 mx-auto mb-2 opacity-50" />
                        <p>No events for this day</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Legend */}
              <Card className="mt-4">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Legend</CardTitle>
                    <span className="text-xs text-muted-foreground">Click palette to customize colors</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center gap-2 group">
                      <div 
                        className="w-4 h-4 rounded border-gray-300" 
                        style={{ backgroundColor: legendColors.activityPending }}
                      ></div>
                      <span className="flex-1">Activity (Pending)</span>
                      <ColorPicker 
                        colorType="activityPending" 
                        currentColor={legendColors.activityPending} 
                        label="Activity (Pending)"
                      />
                    </div>
                    <div className="flex items-center gap-2 group">
                      <div 
                        className="w-4 h-4 rounded border-gray-300" 
                        style={{ backgroundColor: legendColors.activityCompleted }}
                      ></div>
                      <span className="flex-1">Activity (Completed)</span>
                      <ColorPicker 
                        colorType="activityCompleted" 
                        currentColor={legendColors.activityCompleted} 
                        label="Activity (Completed)"
                      />
                    </div>
                    <div className="flex items-center gap-2 group">
                      <div 
                        className="w-4 h-4 rounded border-gray-300" 
                        style={{ backgroundColor: legendColors.expense }}
                      ></div>
                      <span className="flex-1">Expense</span>
                      <ColorPicker 
                        colorType="expense" 
                        currentColor={legendColors.expense} 
                        label="Expense"
                      />
                    </div>
                    <div className="flex items-center gap-2 group">
                      <div 
                        className="w-4 h-4 rounded border-gray-300" 
                        style={{ backgroundColor: legendColors.health }}
                      ></div>
                      <span className="flex-1">Health Metric</span>
                      <ColorPicker 
                        colorType="health" 
                        currentColor={legendColors.health} 
                        label="Health Metric"
                      />
                    </div>
                    <div className="flex items-center gap-2 group pt-2 border-t border-gray-300">
                      <div 
                        className="w-4 h-4 rounded border-gray-300" 
                        style={{ backgroundColor: legendColors.calendarBackground }}
                      ></div>
                      <span className="flex-1">Calendar Background</span>
                      <ColorPicker 
                        colorType="calendarBackground" 
                        currentColor={legendColors.calendarBackground} 
                        label="Calendar Background"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}