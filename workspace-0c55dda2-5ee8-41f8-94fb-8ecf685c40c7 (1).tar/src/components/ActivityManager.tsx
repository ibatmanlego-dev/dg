'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Plus,
  Calendar,
  Clock,
  Bell,
  Edit,
  Trash2,
  Check,
  X,
  Repeat,
  AlertCircle
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Activity {
  id: string
  title: string
  description: string
  category: string
  status: 'pending' | 'completed' | 'cancelled'
  priority: 'low' | 'medium' | 'high'
  scheduledAt: string | null
  completedAt: string | null
  reminderAt: string | null
  isRecurring: boolean
  recurringPattern: string | null
  recurringEndDate: string | null
  alertEnabled: boolean
  alertType: string | null
  alertAdvanceMinutes: number
  createdAt: string
  updatedAt: string
}

const CATEGORIES = [
  'Personal',
  'Work',
  'Health',
  'Shopping',
  'Finance',
  'Learning',
  'Social',
  'Other'
]

const RECURRING_PATTERNS = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Bi-weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'yearly', label: 'Yearly' }
]

const ALERT_TYPES = [
  { value: 'notification', label: 'Notification' },
  { value: 'sound', label: 'Sound' },
  { value: 'email', label: 'Email' }
]

const PRIORITY_COLORS = {
  low: 'bg-blue-500',
  medium: 'bg-yellow-500',
  high: 'bg-red-500'
}

export default function ActivityManager() {
  const [activities, setActivities] = useState<Activity[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null)
  const [filter, setFilter] = useState('all')
  const [newActivity, setNewActivity] = useState({
    title: '',
    description: '',
    category: '',
    priority: 'medium' as 'low' | 'medium' | 'high',
    scheduledAt: '',
    isRecurring: false,
    recurringPattern: 'weekly',
    recurringEndDate: '',
    alertEnabled: false,
    alertType: 'notification',
    alertAdvanceMinutes: 15
  })
  
  const { toast } = useToast()

  const filteredActivities = activities.filter(activity => {
    if (filter === 'all') return true
    if (filter === 'pending') return activity.status === 'pending'
    if (filter === 'completed') return activity.status === 'completed'
    if (filter === 'recurring') return activity.isRecurring
    return true
  })

  const addActivity = () => {
    if (!newActivity.title || !newActivity.category) {
      toast({
        title: "Missing Information",
        description: "Please provide at least a title and category.",
        variant: "destructive"
      })
      return
    }

    const activity: Activity = {
      id: Date.now().toString(),
      title: newActivity.title,
      description: newActivity.description,
      category: newActivity.category,
      status: 'pending',
      priority: newActivity.priority,
      scheduledAt: newActivity.scheduledAt ? new Date(newActivity.scheduledAt).toISOString() : null,
      completedAt: null,
      reminderAt: newActivity.scheduledAt && newActivity.alertEnabled 
        ? new Date(new Date(newActivity.scheduledAt).getTime() - newActivity.alertAdvanceMinutes * 60000).toISOString()
        : null,
      isRecurring: newActivity.isRecurring,
      recurringPattern: newActivity.isRecurring ? newActivity.recurringPattern : null,
      recurringEndDate: newActivity.isRecurring && newActivity.recurringEndDate 
        ? new Date(newActivity.recurringEndDate).toISOString() 
        : null,
      alertEnabled: newActivity.alertEnabled,
      alertType: newActivity.alertEnabled ? newActivity.alertType : null,
      alertAdvanceMinutes: newActivity.alertAdvanceMinutes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    setActivities(prev => [activity, ...prev])
    resetForm()
    setShowAddForm(false)
    
    toast({
      title: "Activity Created",
      description: `${activity.title} has been added to your activities.`
    })

    // Schedule reminder if needed
    if (activity.reminderAt) {
      scheduleReminder(activity)
    }
  }

  const updateActivity = () => {
    if (!editingActivity) return

    setActivities(prev => prev.map(a => 
      a.id === editingActivity.id ? { ...editingActivity, updatedAt: new Date().toISOString() } : a
    ))
    setEditingActivity(null)
    
    toast({
      title: "Activity Updated",
      description: `${editingActivity.title} has been updated.`
    })
  }

  const deleteActivity = (id: string) => {
    const activity = activities.find(a => a.id === id)
    setActivities(prev => prev.filter(a => a.id !== id))
    
    toast({
      title: "Activity Deleted",
      description: activity?.title + " has been removed."
    })
  }

  const toggleComplete = (id: string) => {
    const activity = activities.find(a => a.id === id)
    if (!activity) return

    setActivities(prev => prev.map(a => {
      if (a.id === id) {
        const updated = {
          ...a,
          status: a.status === 'completed' ? 'pending' : 'completed' as const,
          completedAt: a.status === 'completed' ? null : new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }

        // If it's a recurring activity and was just completed, create next occurrence
        if (a.isRecurring && a.status === 'pending' && a.scheduledAt) {
          createNextOccurrence(a)
        }

        return updated
      }
      return a
    }))

    toast({
      title: activity.status === 'completed' ? "Activity Reopened" : "Activity Completed",
      description: activity.title
    })
  }

  const createNextOccurrence = (activity: Activity) => {
    if (!activity.scheduledAt || !activity.recurringPattern || !activity.recurringEndDate) return

    const nextDate = calculateNextOccurrence(
      new Date(activity.scheduledAt),
      activity.recurringPattern
    )

    if (nextDate && nextDate <= new Date(activity.recurringEndDate)) {
      const nextActivity: Activity = {
        ...activity,
        id: Date.now().toString(),
        scheduledAt: nextDate.toISOString(),
        reminderAt: activity.alertEnabled 
          ? new Date(nextDate.getTime() - activity.alertAdvanceMinutes * 60000).toISOString()
          : null,
        status: 'pending',
        completedAt: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }

      setActivities(prev => [nextActivity, ...prev])
      
      toast({
        title: "Next Occurrence Created",
        description: `Next ${activity.title} scheduled for ${nextDate.toLocaleDateString()}`
      })

      if (nextActivity.reminderAt) {
        scheduleReminder(nextActivity)
      }
    }
  }

  const calculateNextOccurrence = (date: Date, pattern: string): Date | null => {
    const next = new Date(date)
    
    switch (pattern) {
      case 'daily':
        next.setDate(next.getDate() + 1)
        break
      case 'weekly':
        next.setDate(next.getDate() + 7)
        break
      case 'biweekly':
        next.setDate(next.getDate() + 14)
        break
      case 'monthly':
        next.setMonth(next.getMonth() + 1)
        break
      case 'quarterly':
        next.setMonth(next.getMonth() + 3)
        break
      case 'yearly':
        next.setFullYear(next.getFullYear() + 1)
        break
      default:
        return null
    }
    
    return next
  }

  const scheduleReminder = (activity: Activity) => {
    if (!activity.reminderAt) return

    const reminderTime = new Date(activity.reminderAt).getTime() - Date.now()
    if (reminderTime > 0) {
      setTimeout(() => {
        toast({
          title: "Activity Reminder",
          description: `Don't forget: ${activity.title}`,
          action: (
            <Button variant="outline" size="sm" onClick={() => toggleComplete(activity.id)}>
              <Check className="w-4 h-4" />
            </Button>
          )
        })

        // Play sound if enabled
        if (activity.alertType === 'sound') {
          playNotificationSound()
        }
      }, reminderTime)
    }
  }

  const playNotificationSound = () => {
    // Create a simple beep sound
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()
    
    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)
    
    oscillator.frequency.value = 800
    oscillator.type = 'sine'
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)
    
    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.5)
  }

  const resetForm = () => {
    setNewActivity({
      title: '',
      description: '',
      category: '',
      priority: 'medium',
      scheduledAt: '',
      isRecurring: false,
      recurringPattern: 'weekly',
      recurringEndDate: '',
      alertEnabled: false,
      alertType: 'notification',
      alertAdvanceMinutes: 15
    })
  }

  const formatDateTime = (dateString: string | null) => {
    if (!dateString) return 'No date set'
    return new Date(dateString).toLocaleString()
  }

  const isOverdue = (activity: Activity) => {
    if (!activity.scheduledAt || activity.status === 'completed') return false
    return new Date(activity.scheduledAt) < new Date()
  }

  useEffect(() => {
    // Check for upcoming reminders on component mount
    activities.forEach(activity => {
      if (activity.reminderAt && activity.status === 'pending') {
        scheduleReminder(activity)
      }
    })
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-semibold">Activity Manager</h2>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="recurring">Recurring</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Activity
          </Button>
        </div>
      </div>

      {/* Add/Edit Activity Form */}
      {(showAddForm || editingActivity) && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingActivity ? 'Edit Activity' : 'Create New Activity'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={editingActivity ? editingActivity.title : newActivity.title}
                  onChange={(e) => editingActivity 
                    ? setEditingActivity({ ...editingActivity, title: e.target.value })
                    : setNewActivity({ ...newActivity, title: e.target.value })
                  }
                  placeholder="Enter activity title..."
                />
              </div>
              
              <div>
                <Label htmlFor="category">Category *</Label>
                <Select 
                  value={editingActivity ? editingActivity.category : newActivity.category}
                  onValueChange={(value) => editingActivity
                    ? setEditingActivity({ ...editingActivity, category: value })
                    : setNewActivity({ ...newActivity, category: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={editingActivity ? editingActivity.description : newActivity.description}
                onChange={(e) => editingActivity
                  ? setEditingActivity({ ...editingActivity, description: e.target.value })
                  : setNewActivity({ ...newActivity, description: e.target.value })
                }
                placeholder="Add description..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select 
                  value={editingActivity ? editingActivity.priority : newActivity.priority}
                  onValueChange={(value: 'low' | 'medium' | 'high') => editingActivity
                    ? setEditingActivity({ ...editingActivity, priority: value })
                    : setNewActivity({ ...newActivity, priority: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="scheduled">Scheduled Date & Time</Label>
                <Input
                  id="scheduled"
                  type="datetime-local"
                  value={editingActivity && editingActivity.scheduledAt 
                    ? new Date(editingActivity.scheduledAt).toISOString().slice(0, 16)
                    : newActivity.scheduledAt
                  }
                  onChange={(e) => editingActivity
                    ? setEditingActivity({ ...editingActivity, scheduledAt: e.target.value })
                    : setNewActivity({ ...newActivity, scheduledAt: e.target.value })
                  }
                />
              </div>

              <div className="flex items-center space-x-2 pt-6">
                <Switch
                  id="recurring"
                  checked={editingActivity ? editingActivity.isRecurring : newActivity.isRecurring}
                  onCheckedChange={(checked) => editingActivity
                    ? setEditingActivity({ ...editingActivity, isRecurring: checked })
                    : setNewActivity({ ...newActivity, isRecurring: checked })
                  }
                />
                <Label htmlFor="recurring">Recurring Activity</Label>
              </div>
            </div>

            {/* Recurring Options */}
            {(editingActivity ? editingActivity.isRecurring : newActivity.isRecurring) && (
              <div className="space-y-4 p-4 border rounded-lg">
                <h4 className="font-medium flex items-center gap-2">
                  <Repeat className="w-4 h-4" />
                  Recurring Options
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="pattern">Pattern</Label>
                    <Select 
                      value={editingActivity ? editingActivity.recurringPattern || 'weekly' : newActivity.recurringPattern}
                      onValueChange={(value) => editingActivity
                        ? setEditingActivity({ ...editingActivity, recurringPattern: value })
                        : setNewActivity({ ...newActivity, recurringPattern: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {RECURRING_PATTERNS.map(pattern => (
                          <SelectItem key={pattern.value} value={pattern.value}>
                            {pattern.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="end-date">End Date</Label>
                    <Input
                      id="end-date"
                      type="date"
                      value={editingActivity && editingActivity.recurringEndDate
                        ? new Date(editingActivity.recurringEndDate).toISOString().split('T')[0]
                        : newActivity.recurringEndDate
                      }
                      onChange={(e) => editingActivity
                        ? setEditingActivity({ ...editingActivity, recurringEndDate: e.target.value })
                        : setNewActivity({ ...newActivity, recurringEndDate: e.target.value })
                      }
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Alert Options */}
            <div className="space-y-4 p-4 border rounded-lg">
              <h4 className="font-medium flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Alert Settings
              </h4>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="alerts"
                  checked={editingActivity ? editingActivity.alertEnabled : newActivity.alertEnabled}
                  onCheckedChange={(checked) => editingActivity
                    ? setEditingActivity({ ...editingActivity, alertEnabled: checked })
                    : setNewActivity({ ...newActivity, alertEnabled: checked })
                  }
                />
                <Label htmlFor="alerts">Enable Alerts</Label>
              </div>

              {(editingActivity ? editingActivity.alertEnabled : newActivity.alertEnabled) && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="alert-type">Alert Type</Label>
                    <Select 
                      value={editingActivity ? editingActivity.alertType || 'notification' : newActivity.alertType}
                      onValueChange={(value) => editingActivity
                        ? setEditingActivity({ ...editingActivity, alertType: value })
                        : setNewActivity({ ...newActivity, alertType: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ALERT_TYPES.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="alert-advance">
                      Alert {editingActivity ? editingActivity.alertAdvanceMinutes : newActivity.alertAdvanceMinutes} minutes before
                    </Label>
                    <Input
                      id="alert-advance"
                      type="range"
                      min="0"
                      max="1440"
                      step="15"
                      value={editingActivity ? editingActivity.alertAdvanceMinutes : newActivity.alertAdvanceMinutes}
                      onChange={(e) => editingActivity
                        ? setEditingActivity({ ...editingActivity, alertAdvanceMinutes: parseInt(e.target.value) })
                        : setNewActivity({ ...newActivity, alertAdvanceMinutes: parseInt(e.target.value) })
                      }
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={editingActivity ? updateActivity : addActivity}
                className="flex-1"
              >
                {editingActivity ? 'Update Activity' : 'Create Activity'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowAddForm(false)
                  setEditingActivity(null)
                  resetForm()
                }}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Activities List */}
      <div className="space-y-4">
        {filteredActivities.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">
                {filter === 'all' ? 'No activities yet. Create your first activity!' : `No ${filter} activities found.`}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredActivities.map((activity) => (
            <Card key={activity.id} className={`${activity.status === 'completed' ? 'opacity-60' : ''} ${isOverdue(activity) ? 'border-red-200 bg-red-50/50' : ''}`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`w-3 h-3 rounded-full ${PRIORITY_COLORS[activity.priority]}`} />
                      <h3 className={`font-semibold ${activity.status === 'completed' ? 'line-through' : ''}`}>
                        {activity.title}
                      </h3>
                      {activity.isRecurring && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <Repeat className="w-3 h-3" />
                          {activity.recurringPattern}
                        </Badge>
                      )}
                      {isOverdue(activity) && (
                        <Badge variant="destructive" className="flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          Overdue
                        </Badge>
                      )}
                      <Badge variant={activity.status === 'completed' ? 'default' : 'secondary'}>
                        {activity.status}
                      </Badge>
                    </div>
                    
                    {activity.description && (
                      <p className="text-muted-foreground mb-2">{activity.description}</p>
                    )}
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDateTime(activity.scheduledAt)}
                      </span>
                      
                      {activity.alertEnabled && activity.reminderAt && (
                        <span className="flex items-center gap-1">
                          <Bell className="w-4 h-4" />
                          Alert set
                        </span>
                      )}
                      
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        Created {new Date(activity.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleComplete(activity.id)}
                      className={activity.status === 'completed' ? 'text-yellow-600' : 'text-green-600'}
                    >
                      {activity.status === 'completed' ? <X className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingActivity(activity)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteActivity(activity.id)}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}