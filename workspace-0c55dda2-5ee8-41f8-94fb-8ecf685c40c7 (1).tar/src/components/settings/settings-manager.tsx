'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { 
  Settings, 
  Palette, 
  Bell, 
  Lock, 
  Database, 
  Smartphone,
  Download,
  Upload,
  Trash2,
  Save,
  User,
  Zap,
  Calendar,
  Camera,
  X,
  Shield,
  Mail,
  LogIn,
  LogOut,
  CheckCircle,
  AlertCircle
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useData } from '@/contexts/DataContext'
import { useCapacitor } from '@/hooks/use-capacitor'
import { useSettings } from '@/contexts/SettingsContext'
import { useCloudSync } from '@/hooks/use-cloud-sync'
import { AnimationSettings } from './animation-settings'
import { AnimationDemo } from '@/components/ui/animation-demo'
import { ThemeCustomizer } from '@/components/theme/theme-customizer'
import { ButtonCustomizer } from '@/components/ui/button-customizer'
import { CategoryColorCustomizer } from './category-color-customizer'
import { CurrencySelector } from './currency-selector'
import { SettingsSearch } from './settings-search'

export function SettingsManager() {
  const { theme, themeName, setTheme, themes, customTheme, setCustomTheme } = useTheme()
  const { exportData, importData, clearAllData } = useData()
  const { isNative, scheduleNotification } = useCapacitor()
  const { 
    periodTrackerEnabled, 
    setPeriodTrackerEnabled, 
    vaultEnabled,
    setVaultEnabled,
    notificationsEnabled, 
    setNotificationsEnabled, 
    autoBackupEnabled, 
    setAutoBackupEnabled, 
    userName, 
    setUserName,
    profilePicture,
    setProfilePicture
  } = useSettings()
  
  const cloudSync = useCloudSync()
  const [activeTab, setActiveTab] = useState('general')
  
  const darkMode = themeName === 'dark'
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showLogin, setShowLogin] = useState(false)

  const handleNavigate = (section: string, tab?: string) => {
    if (tab) {
      setActiveTab(tab)
    } else {
      // Map section to appropriate tab
      const sectionToTab: Record<string, string> = {
        'general': 'general',
        'customize': 'customize', 
        'animations': 'animations',
        'data': 'data'
      }
      setActiveTab(sectionToTab[section] || 'general')
    }
  }

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme)
    setDarkMode(newTheme === 'dark')
  }

  const handleProfilePictureUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Check file type
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file.')
        return
      }
      
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size should be less than 5MB.')
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target?.result as string
        setProfilePicture(result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemoveProfilePicture = () => {
    setProfilePicture(null)
  }

  const getUserInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .slice(0, 2)
      .join('')
  }

  const handleExportData = () => {
    const dataStr = JSON.stringify(exportData(), null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `vibetracker-backup-${new Date().toISOString().split('T')[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string)
          importData(data)
          alert('Data imported successfully!')
        } catch (error) {
          alert('Error importing data. Please check the file format.')
        }
      }
      reader.readAsText(file)
    }
  }

  const handleClearData = () => {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      clearAllData()
      alert('All data has been cleared.')
    }
  }

  const handleTestNotification = async () => {
    if (isNative) {
      await scheduleNotification('Test Notification', 'VibeTracker is working perfectly!')
    } else {
      alert('Notifications are only available on mobile devices')
    }
  }

  const handleLogin = async () => {
    if (!email || !password) {
      alert('Please enter both email and password')
      return
    }

    try {
      await cloudSync.login(email, password)
      setShowLogin(false)
      setEmail('')
      setPassword('')
      alert('Login successful! Cloud sync enabled.')
    } catch (error: any) {
      alert(error.message || 'Login failed')
    }
  }

  const handleLogout = () => {
    if (confirm('Are you sure you want to logout? Cloud sync will be disabled.')) {
      cloudSync.logout().then(() => {
        alert('Logged out successfully. Cloud sync disabled.')
      }).catch((error: any) => {
        alert(error.message || 'Logout failed')
      })
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Settings className="w-6 h-6" style={{ color: theme.primary }} />
        <h2 className="text-2xl font-bold">Settings</h2>
      </div>

      {/* Search Bar */}
      <SettingsSearch onNavigate={handleNavigate} />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4" style={{ 
          backgroundColor: theme.cardBg,
          borderColor: theme.borderColor,
          borderWidth: '1px',
          borderStyle: 'solid'
        }}>
          <TabsTrigger 
            value="general"
            style={{ 
              color: theme.text,
              opacity: 0.9
            }}
          >
            General
          </TabsTrigger>
          <TabsTrigger 
            value="customize"
            style={{ 
              color: theme.text,
              opacity: 0.9
            }}
          >
            Customize
          </TabsTrigger>
          <TabsTrigger 
            value="animations"
            style={{ 
              color: theme.text,
              opacity: 0.9
            }}
          >
            Animations
          </TabsTrigger>
          <TabsTrigger 
            value="data"
            style={{ 
              color: theme.text,
              opacity: 0.9
            }}
          >
            Data
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          {/* User Profile */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <User className="w-5 h-5" />
                User Profile
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Picture */}
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Profile Picture</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Upload your avatar</p>
                </div>
                <div className="flex items-center gap-3">
                  <Avatar className="w-16 h-16">
                    {profilePicture ? (
                      <AvatarImage src={profilePicture} alt="Profile" />
                    ) : (
                      <AvatarFallback 
                        style={{ 
                          backgroundColor: theme.primary,
                          color: '#ffffff'
                        }}
                        className="text-lg font-semibold"
                      >
                        {getUserInitials(userName)}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div className="flex gap-2">
                    {profilePicture ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleRemoveProfilePicture}
                        className="flex items-center gap-1"
                      >
                        <X className="w-4 h-4" />
                        Remove
                      </Button>
                    ) : (
                      <div className="relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleProfilePictureUpload}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex items-center gap-1"
                        >
                          <Camera className="w-4 h-4" />
                          Upload
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Name */}
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Name</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Your display name</p>
                </div>
                <Input
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-48"
                  style={{ 
                    backgroundColor: theme.secondary,
                    borderColor: theme.borderColor,
                    color: theme.text
                  }}
                />
              </div>
            </CardContent>
          </Card>

          {/* Account Authentication */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Lock className="w-5 h-5" />
                Account & Cloud Sync
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!cloudSync.isOnline ? (
                <>
                  <div className="flex items-center justify-between">
                    <div>
                      <p style={{ color: theme.text }} className="font-medium">Email Authentication</p>
                      <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                        Login to enable cloud sync across devices
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => setShowLogin(!showLogin)}
                      className="flex items-center gap-2"
                    >
                      <LogIn className="w-4 h-4" />
                      {showLogin ? 'Cancel' : 'Login'}
                    </Button>
                  </div>
                  
                  {showLogin && (
                    <div className="space-y-4 p-4 border rounded-lg" style={{ borderColor: theme.borderColor }}>
                      <div>
                        <label style={{ color: theme.text, fontSize: '0.875rem', fontWeight: 500 }}>
                          Email Address
                        </label>
                        <Input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="Enter your email"
                          style={{ 
                            backgroundColor: theme.secondary,
                            borderColor: theme.borderColor,
                            color: theme.text,
                            marginTop: '0.5rem'
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ color: theme.text, fontSize: '0.875rem', fontWeight: 500 }}>
                          Password
                        </label>
                        <Input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Enter your password"
                          style={{ 
                            backgroundColor: theme.secondary,
                            borderColor: theme.borderColor,
                            color: theme.text,
                            marginTop: '0.5rem'
                          }}
                        />
                      </div>
                      <Button
                        onClick={handleLogin}
                        disabled={cloudSync.isSyncing}
                        className="w-full flex items-center gap-2"
                      >
                        {cloudSync.isSyncing ? (
                          <>
                            <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                            Signing in...
                          </>
                        ) : (
                          <>
                            <Mail className="w-4 h-4" />
                            Sign In
                          </>
                        )}
                      </Button>
                      {cloudSync.error && (
                        <div className="p-2 rounded-lg" style={{ backgroundColor: '#ef444420' }}>
                          <p style={{ color: '#ef4444' }} className="text-sm">{cloudSync.error}</p>
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="p-3 rounded-lg" style={{ backgroundColor: theme.secondary + '20' }}>
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="w-4 h-4" style={{ color: theme.accent }} />
                      <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm font-medium">
                        Free Cloud Sync Features:
                      </p>
                    </div>
                    <ul style={{ color: theme.text, opacity: 0.7 }} className="text-sm space-y-1 ml-6">
                      <li>• Sync data across all your devices</li>
                      <li>• Automatic backup to secure cloud storage</li>
                      <li>• Restore data when switching devices</li>
                      <li>• No credit card required - completely free</li>
                    </ul>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <div>
                      <p style={{ color: theme.text }} className="font-medium">Cloud Sync Status</p>
                      <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                        Your data is being synced to the cloud
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Connected
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleLogout}
                        disabled={cloudSync.isSyncing}
                        className="flex items-center gap-1"
                      >
                        <LogOut className="w-4 h-4" />
                        Logout
                      </Button>
                    </div>
                  </div>
                  
                  <div className="p-3 rounded-lg" style={{ backgroundColor: theme.secondary + '20' }}>
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-4 h-4" style={{ color: '#22c55e' }} />
                      <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm font-medium">
                        Cloud Sync Active:
                      </p>
                    </div>
                    <ul style={{ color: theme.text, opacity: 0.7 }} className="text-sm space-y-1 ml-6">
                      <li>• Real-time sync enabled</li>
                      <li>• Last sync: {cloudSync.lastSync ? cloudSync.lastSync.toLocaleTimeString() : 'Never'}</li>
                      <li>• Status: {cloudSync.isSyncing ? 'Syncing...' : 'Up to date'}</li>
                      {cloudSync.error && (
                        <li style={{ color: '#ef4444' }}>• Error: {cloudSync.error}</li>
                      )}
                    </ul>
                  </div>
                  
                  <Button
                    variant="outline"
                    onClick={() => cloudSync.syncToCloud().catch(console.error)}
                    disabled={cloudSync.isSyncing}
                    className="w-full flex items-center gap-2"
                  >
                    {cloudSync.isSyncing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        Syncing...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        Sync Now
                      </>
                    )}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          {/* Theme Settings */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Palette className="w-5 h-5" />
                Appearance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Dark Mode</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Toggle dark/light theme</p>
                </div>
                <Switch
                  checked={darkMode}
                  onCheckedChange={(checked) => handleThemeChange(checked ? 'dark' : 'light')}
                />
              </div>
              <div>
                <p style={{ color: theme.text }} className="font-medium mb-3">Theme</p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {Object.keys(themes).map((themeKey) => (
                    <Button
                      key={themeKey}
                      variant={themeName === themeKey ? 'default' : 'outline'}
                      onClick={() => handleThemeChange(themeKey)}
                      size="sm"
                      className="justify-start"
                      style={{
                        backgroundColor: themeName === themeKey ? theme.primary : theme.cardBg,
                        borderColor: theme.borderColor,
                        color: themeName === themeKey ? '#ffffff' : theme.text
                      }}
                    >
                      {themes[themeKey].displayName}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Bell className="w-5 h-5" />
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Push Notifications</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                    {isNative ? 'Enable push notifications' : 'Only available on mobile devices'}
                  </p>
                </div>
                <Switch
                  checked={notificationsEnabled}
                  onCheckedChange={setNotificationsEnabled}
                  disabled={!isNative}
                />
              </div>
              {isNative && (
                <Button
                  variant="outline"
                  onClick={handleTestNotification}
                  className="w-full"
                >
                  Test Notification
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Period Tracker Settings */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Calendar className="w-5 h-5" />
                Period Tracker
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Enable Period Tracker</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                    Show period tracking features in the app
                  </p>
                </div>
                <Switch
                  checked={periodTrackerEnabled}
                  onCheckedChange={setPeriodTrackerEnabled}
                />
              </div>
              {periodTrackerEnabled && (
                <div className="p-3 rounded-lg" style={{ backgroundColor: theme.secondary + '20' }}>
                  <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm">
                    Period tracker is now enabled and visible in the navigation bar.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Vault Settings */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Shield className="w-5 h-5" />
                Vault
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Enable Vault</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                    Show secure vault features in the app
                  </p>
                </div>
                <Switch
                  checked={vaultEnabled}
                  onCheckedChange={setVaultEnabled}
                />
              </div>
              {vaultEnabled && (
                <div className="p-3 rounded-lg" style={{ backgroundColor: theme.secondary + '20' }}>
                  <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm">
                    Vault is now enabled and visible in the navigation bar.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Mobile Settings */}
          {isNative && (
            <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                  <Smartphone className="w-5 h-5" />
                  Mobile Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="secondary">Native App Detected</Badge>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                    You're using the native mobile version of VibeTracker with enhanced features.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="customize" className="space-y-6">
          <CategoryColorCustomizer />
          <CurrencySelector />
          <ThemeCustomizer />
          <ButtonCustomizer />
        </TabsContent>

        <TabsContent value="animations" className="space-y-6">
          <AnimationDemo />
          <AnimationSettings />
        </TabsContent>

        <TabsContent value="data" className="space-y-6">
          {/* Data Management */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Database className="w-5 h-5" />
                Data Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p style={{ color: theme.text }} className="font-medium">Auto Backup</p>
                  <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Automatically backup data</p>
                </div>
                <Switch
                  checked={autoBackupEnabled}
                  onCheckedChange={setAutoBackupEnabled}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  onClick={handleExportData}
                  className="flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export Data
                </Button>
                <div className="relative">
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportData}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <Button
                    variant="outline"
                    className="w-full flex items-center gap-2"
                  >
                    <Upload className="w-4 h-4" />
                    Import Data
                  </Button>
                </div>
              </div>
              <Button
                variant="outline"
                onClick={handleClearData}
                className="w-full flex items-center gap-2"
                style={{ borderColor: '#ef4444', color: '#ef4444' }}
              >
                <Trash2 className="w-4 h-4" />
                Clear All Data
              </Button>
            </CardContent>
          </Card>

          {/* App Info */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle style={{ color: theme.text }}>About</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p style={{ color: theme.text, opacity: 0.8 }}>
                  <strong>VibeTracker</strong> v1.0.0
                </p>
                <p style={{ color: theme.text, opacity: 0.8 }}>
                  Your personal life tracking companion
                </p>
                <p style={{ color: theme.text, opacity: 0.6 }} className="text-sm">
                  © 2024 VibeTracker Team
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}