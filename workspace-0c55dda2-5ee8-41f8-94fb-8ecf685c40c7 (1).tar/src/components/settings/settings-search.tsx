'use client'

import React, { useState, useMemo, useRef, useEffect } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Search, 
  Settings, 
  Palette, 
  Bell, 
  Lock, 
  Database, 
  User,
  Download,
  Upload,
  Trash2,
  Save,
  DollarSign,
  Heart,
  Calendar,
  Camera,
  X,
  Shield,
  Mail,
  LogIn,
  LogOut,
  CheckCircle,
  AlertCircle,
  Globe,
  Volume2,
  Eye,
  Smartphone,
  CreditCard,
  Tag,
  Filter,
  Clock,
  Star,
  Zap,
  Activity,
  BarChart3,
  PieChart,
  TrendingUp,
  FileText,
  Archive,
  RefreshCw,
  HelpCircle,
  Info,
  ArrowRight,
  Cloud
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'

interface SearchResult {
  id: string
  title: string
  description: string
  category: string
  icon: React.ReactNode
  action: () => void
  keywords: string[]
}

interface SettingsSearchProps {
  onNavigate: (section: string, tab?: string) => void
}

export function SettingsSearch({ onNavigate }: SettingsSearchProps) {
  const { theme } = useTheme()
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)

  const searchResults: SearchResult[] = useMemo(() => [
    // General Settings
    {
      id: 'user-profile',
      title: 'User Profile',
      description: 'Manage your profile picture and display name',
      category: 'General',
      icon: <User className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['profile', 'name', 'picture', 'avatar', 'user', 'display']
    },
    {
      id: 'dark-mode',
      title: 'Dark Mode',
      description: 'Toggle between light and dark themes',
      category: 'General',
      icon: <Palette className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['dark', 'light', 'theme', 'mode', 'appearance']
    },
    {
      id: 'theme-selection',
      title: 'Theme Selection',
      description: 'Choose from different color themes',
      category: 'General',
      icon: <Palette className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['theme', 'color', 'style', 'appearance', 'design']
    },
    {
      id: 'notifications',
      title: 'Notifications',
      description: 'Configure app notifications and alerts',
      category: 'General',
      icon: <Bell className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['notification', 'alert', 'sound', 'push', 'notify']
    },
    {
      id: 'cloud-sync',
      title: 'Cloud Sync',
      description: 'Login and sync data across devices',
      category: 'General',
      icon: <Cloud className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['cloud', 'sync', 'backup', 'login', 'account', 'data']
    },

    // Customize Settings
    {
      id: 'theme-customizer',
      title: 'Theme Customizer',
      description: 'Create custom themes with colors and gradients',
      category: 'Customize',
      icon: <Palette className="w-4 h-4" />,
      action: () => onNavigate('customize'),
      keywords: ['custom', 'theme', 'color', 'gradient', 'design', 'create']
    },
    {
      id: 'button-customizer',
      title: 'Button Customizer',
      description: 'Customize button styles and animations',
      category: 'Customize',
      icon: <Zap className="w-4 h-4" />,
      action: () => onNavigate('customize'),
      keywords: ['button', 'style', 'animation', 'custom', 'design']
    },
    {
      id: 'category-colors',
      title: 'Category Colors',
      description: 'Set custom colors for activity categories',
      category: 'Customize',
      icon: <Tag className="w-4 h-4" />,
      action: () => onNavigate('customize'),
      keywords: ['category', 'color', 'activity', 'custom', 'tag']
    },
    {
      id: 'currency',
      title: 'Currency Settings',
      description: 'Configure currency symbol and format',
      category: 'Customize',
      icon: <DollarSign className="w-4 h-4" />,
      action: () => onNavigate('customize'),
      keywords: ['currency', 'money', 'symbol', 'format', 'dollar', 'euro']
    },

    // Animation Settings
    {
      id: 'animations',
      title: 'Animations',
      description: 'Configure app animations and transitions',
      category: 'Animations',
      icon: <Zap className="w-4 h-4" />,
      action: () => onNavigate('animations'),
      keywords: ['animation', 'transition', 'motion', 'effect', 'speed']
    },
    {
      id: 'animation-speed',
      title: 'Animation Speed',
      description: 'Adjust animation speed and duration',
      category: 'Animations',
      icon: <Clock className="w-4 h-4" />,
      action: () => onNavigate('animations'),
      keywords: ['speed', 'duration', 'fast', 'slow', 'animation']
    },
    {
      id: 'animation-effects',
      title: 'Animation Effects',
      description: 'Choose different animation effects',
      category: 'Animations',
      icon: <Star className="w-4 h-4" />,
      action: () => onNavigate('animations'),
      keywords: ['effect', 'style', 'type', 'animation', 'motion']
    },

    // Data Management
    {
      id: 'export-data',
      title: 'Export Data',
      description: 'Export your data as JSON file',
      category: 'Data',
      icon: <Download className="w-4 h-4" />,
      action: () => onNavigate('data'),
      keywords: ['export', 'download', 'backup', 'save', 'json']
    },
    {
      id: 'import-data',
      title: 'Import Data',
      description: 'Import data from JSON file',
      category: 'Data',
      icon: <Upload className="w-4 h-4" />,
      action: () => onNavigate('data'),
      keywords: ['import', 'upload', 'restore', 'load', 'json']
    },
    {
      id: 'clear-data',
      title: 'Clear All Data',
      description: 'Delete all app data permanently',
      category: 'Data',
      icon: <Trash2 className="w-4 h-4" />,
      action: () => onNavigate('data'),
      keywords: ['clear', 'delete', 'remove', 'reset', 'clean']
    },
    {
      id: 'auto-backup',
      title: 'Auto Backup',
      description: 'Configure automatic data backups',
      category: 'Data',
      icon: <Save className="w-4 h-4" />,
      action: () => onNavigate('data'),
      keywords: ['backup', 'auto', 'automatic', 'save', 'schedule']
    },

    // Features
    {
      id: 'period-tracker',
      title: 'Period Tracker',
      description: 'Enable/disable period tracking feature',
      category: 'Features',
      icon: <Calendar className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['period', 'menstrual', 'cycle', 'health', 'female']
    },
    {
      id: 'vault',
      title: 'Secure Vault',
      description: 'Enable/disable secure vault feature',
      category: 'Features',
      icon: <Shield className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['vault', 'secure', 'safe', 'password', 'privacy']
    },

    // App Info
    {
      id: 'about',
      title: 'About',
      description: 'App information and version',
      category: 'About',
      icon: <Info className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['about', 'version', 'info', 'app', 'information']
    },
    {
      id: 'help',
      title: 'Help & Support',
      description: 'Get help and support',
      category: 'About',
      icon: <HelpCircle className="w-4 h-4" />,
      action: () => onNavigate('general'),
      keywords: ['help', 'support', 'guide', 'tutorial', 'faq']
    }
  ], [onNavigate])

  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return []

    const query = searchQuery.toLowerCase()
    return searchResults.filter(result => {
      const titleMatch = result.title.toLowerCase().includes(query)
      const descriptionMatch = result.description.toLowerCase().includes(query)
      const categoryMatch = result.category.toLowerCase().includes(query)
      const keywordsMatch = result.keywords.some(keyword => 
        keyword.toLowerCase().includes(query)
      )
      
      return titleMatch || descriptionMatch || categoryMatch || keywordsMatch
    })
  }, [searchQuery, searchResults])

  const groupedResults = useMemo(() => {
    const groups: Record<string, SearchResult[]> = {}
    
    filteredResults.forEach(result => {
      if (!groups[result.category]) {
        groups[result.category] = []
      }
      groups[result.category].push(result)
    })
    
    return groups
  }, [filteredResults])

  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }, [isSearchOpen])

  const handleResultClick = (result: SearchResult) => {
    result.action()
    setIsSearchOpen(false)
    setSearchQuery('')
  }

  if (!isSearchOpen) {
    return (
      <Button
        variant="outline"
        onClick={() => setIsSearchOpen(true)}
        className="w-full justify-start"
        style={{ 
          backgroundColor: theme.secondary,
          borderColor: theme.borderColor,
          color: theme.text
        }}
      >
        <Search className="w-4 h-4 mr-2" />
        Search Settings...
      </Button>
    )
  }

  return (
    <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Search className="w-4 h-4" style={{ color: theme.text }} />
          <Input
            ref={searchInputRef}
            placeholder="Search settings, features, or anything..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
            style={{ 
              backgroundColor: theme.secondary,
              borderColor: theme.borderColor,
              color: theme.text
            }}
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsSearchOpen(false)}
            style={{ color: theme.text }}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {searchQuery && (
          <ScrollArea className="max-h-96">
            {Object.keys(groupedResults).length > 0 ? (
              <div className="space-y-4">
                {Object.entries(groupedResults).map(([category, results]) => (
                  <div key={category}>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {category}
                      </Badge>
                      <span className="text-xs" style={{ color: theme.text, opacity: 0.6 }}>
                        {results.length} result{results.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                    <div className="space-y-2">
                      {results.map(result => (
                        <button
                          key={result.id}
                          onClick={() => handleResultClick(result)}
                          className="w-full text-left p-3 rounded-lg border transition-colors hover:opacity-80 flex items-center gap-3"
                          style={{ 
                            backgroundColor: theme.secondary,
                            borderColor: theme.borderColor,
                            color: theme.text
                          }}
                        >
                          <div className="flex-shrink-0" style={{ color: theme.primary }}>
                            {result.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm truncate">
                              {result.title}
                            </div>
                            <div className="text-xs" style={{ opacity: 0.7 }}>
                              {result.description}
                            </div>
                          </div>
                          <ArrowRight className="w-4 h-4 flex-shrink-0" style={{ opacity: 0.5 }} />
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Search className="w-12 h-12 mx-auto mb-2" style={{ opacity: 0.3 }} />
                <p style={{ color: theme.text, opacity: 0.6 }}>
                  No results found for "{searchQuery}"
                </p>
                <p className="text-sm mt-1" style={{ opacity: 0.4 }}>
                  Try searching for settings, features, or keywords
                </p>
              </div>
            )}
          </ScrollArea>
        )}

        {!searchQuery && (
          <div className="text-center py-8">
            <Search className="w-12 h-12 mx-auto mb-2" style={{ opacity: 0.3 }} />
            <p style={{ color: theme.text, opacity: 0.6 }}>
              Type to search settings
            </p>
            <p className="text-sm mt-1" style={{ opacity: 0.4 }}>
              Try: "profile", "theme", "backup", "currency"
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}