'use client'

import { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { 
  DollarSign, 
  Search, 
  Globe, 
  Star,
  ChevronDown
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useSettings } from '@/contexts/SettingsContext'
import { currencies, currenciesByRegion, Currency } from '@/lib/currencies'

export function CurrencySelector() {
  const { theme } = useTheme()
  const { currency, setCurrency } = useSettings()
  
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedRegion, setSelectedRegion] = useState<string>('all')

  const filteredCurrencies = useMemo(() => {
    let filtered = currencies

    // Filter by region
    if (selectedRegion !== 'all') {
      filtered = currenciesByRegion[selectedRegion as keyof typeof currenciesByRegion] || []
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(currency => 
        currency.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        currency.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
        currency.symbol.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Sort alphabetically by country name
    return filtered.sort((a, b) => a.country.localeCompare(b.country))
  }, [searchTerm, selectedRegion])

  const popularCurrencies = [
    { code: 'USD', symbol: '$', country: 'United States' },
    { code: 'EUR', symbol: '€', country: 'European Union' },
    { code: 'GBP', symbol: '£', country: 'United Kingdom' },
    { code: 'JPY', symbol: '¥', country: 'Japan' },
    { code: 'CNY', symbol: '¥', country: 'China' },
    { code: 'INR', symbol: '₹', country: 'India' },
  ]

  return (
    <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
          <DollarSign className="w-5 h-5" />
          Currency Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Currency Display */}
        <div className="flex items-center justify-between p-4 rounded-lg border" style={{ borderColor: theme.borderColor }}>
          <div>
            <Label style={{ color: theme.text }}>Current Currency</Label>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-2xl font-bold" style={{ color: theme.primary }}>
                {currency.symbol}
              </span>
              <div>
                <p className="font-semibold" style={{ color: theme.text }}>
                  {currency.code}
                </p>
                <p className="text-sm" style={{ color: theme.text, opacity: 0.7 }}>
                  {currency.country}
                </p>
              </div>
            </div>
          </div>
          <Badge variant="secondary" className="flex items-center gap-1">
            <Star className="w-3 h-3" />
            Active
          </Badge>
        </div>

        {/* Quick Select Popular Currencies */}
        <div>
          <Label style={{ color: theme.text }} className="text-sm font-medium">
            Popular Currencies
          </Label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
            {popularCurrencies.map((popularCurrency) => (
              <Button
                key={popularCurrency.code}
                variant={currency.code === popularCurrency.code ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrency(popularCurrency)}
                className="flex items-center gap-2 justify-start"
              >
                <span className="font-bold">{popularCurrency.symbol}</span>
                <div className="text-left">
                  <div className="text-xs font-medium">{popularCurrency.code}</div>
                  <div className="text-xs opacity-70">{popularCurrency.country}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Search and Filter */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" style={{ color: theme.text, opacity: 0.5 }} />
            <Input
              placeholder="Search by country name, currency code, or symbol..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4" style={{ color: theme.text, opacity: 0.7 }} />
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="flex-1" style={{ 
                backgroundColor: theme.secondary,
                borderColor: theme.borderColor,
                color: theme.text
              }}>
                <SelectValue placeholder="Select region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Regions</SelectItem>
                {Object.keys(currenciesByRegion).map((region) => (
                  <SelectItem key={region} value={region}>
                    {region}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Currency List */}
        <div className="space-y-2">
          <Label style={{ color: theme.text }} className="text-sm font-medium">
            All Currencies ({filteredCurrencies.length})
          </Label>
          <div className="max-h-64 overflow-y-auto rounded-lg border" style={{ borderColor: theme.borderColor }}>
            {filteredCurrencies.map((currencyOption) => (
              <div
                key={currencyOption.code}
                className={`flex items-center justify-between p-3 border-b cursor-pointer transition-colors ${
                  currency.code === currencyOption.code 
                    ? 'bg-blue-500/10' 
                    : 'hover:bg-gray-500/5'
                }`}
                style={{ 
                  borderColor: theme.borderColor,
                  backgroundColor: currency.code === currencyOption.code ? theme.primary + '20' : 'transparent'
                }}
                onClick={() => setCurrency(currencyOption)}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl font-bold" style={{ color: theme.primary }}>
                    {currencyOption.symbol}
                  </span>
                  <div>
                    <p className="font-medium" style={{ color: theme.text }}>
                      {currencyOption.code}
                    </p>
                    <p className="text-sm" style={{ color: theme.text, opacity: 0.7 }}>
                      {currencyOption.country}
                    </p>
                  </div>
                </div>
                {currency.code === currencyOption.code && (
                  <Badge variant="default" className="flex items-center gap-1">
                    <Star className="w-3 h-3" />
                    Selected
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="p-3 rounded-lg" style={{ backgroundColor: theme.secondary + '20' }}>
          <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm">
            Select your preferred currency for all financial transactions and displays throughout the app. 
            This will be used for expense tracking, budgeting, and financial reports.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}