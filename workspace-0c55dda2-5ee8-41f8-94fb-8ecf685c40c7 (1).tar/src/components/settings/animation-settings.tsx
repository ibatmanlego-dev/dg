'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { 
  Zap, 
  Settings, 
  Clock, 
  Sparkles, 
  Eye, 
  EyeOff,
  RefreshCw,
  Play,
  Pause
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useAnimation } from '@/contexts/AnimationContext'

export function AnimationSettings() {
  const { theme } = useTheme()
  const { 
    settings, 
    updateSettings, 
    toggleAnimations, 
    setPresetTransitions, 
    resetToDefaults,
    presets 
  } = useAnimation()
  
  const [isPreviewing, setIsPreviewing] = useState(false)

  const handleDurationChange = (value: number[]) => {
    updateSettings({ duration: value[0] })
  }

  const handlePerformanceModeChange = (mode: 'high' | 'medium' | 'low') => {
    const modeSettings = {
      high: { duration: 300, particleEffects: true, backgroundAnimations: true },
      medium: { duration: 200, particleEffects: false, backgroundAnimations: true },
      low: { duration: 100, particleEffects: false, backgroundAnimations: false }
    }
    
    updateSettings({ 
      performanceMode: mode,
      ...modeSettings[mode]
    })
  }

  const handleCustomTransitionChange = (type: keyof typeof settings.customTransitions, value: string) => {
    updateSettings({
      customTransitions: {
        ...settings.customTransitions,
        [type]: value
      }
    })
  }

  const previewAnimation = () => {
    setIsPreviewing(true)
    setTimeout(() => setIsPreviewing(false), 2000)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-6 h-6" style={{ color: theme.primary }} />
          <h3 className="text-xl font-bold" style={{ color: theme.text }}>Animation Settings</h3>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={previewAnimation}
            className="flex items-center gap-2"
          >
            {isPreviewing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            Preview
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={resetToDefaults}
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Reset
          </Button>
        </div>
      </div>

      {/* Master Animation Toggle */}
      <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
            {settings.enabled ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
            Animation Control
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p style={{ color: theme.text }} className="font-medium">Enable Animations</p>
              <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                Turn all animations on or off
              </p>
            </div>
            <Switch
              checked={settings.enabled}
              onCheckedChange={toggleAnimations}
            />
          </div>
          
          {settings.enabled && (
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: theme.text }} className="font-medium">Status</p>
                <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                  Current animation state
                </p>
              </div>
              <Badge variant="default" className="bg-green-500">
                Active
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>

      {settings.enabled && (
        <>
          {/* Performance Mode */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Settings className="w-5 h-5" />
                Performance Mode
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p style={{ color: theme.text }} className="font-medium mb-3">Performance Level</p>
                <Select
                  value={settings.performanceMode}
                  onValueChange={(value: 'high' | 'medium' | 'low') => handlePerformanceModeChange(value)}
                >
                  <SelectTrigger style={{ backgroundColor: theme.secondary, borderColor: theme.borderColor }}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4" />
                        High Quality (All effects)
                      </div>
                    </SelectItem>
                    <SelectItem value="medium">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Medium (Reduced effects)
                      </div>
                    </SelectItem>
                    <SelectItem value="low">
                      <div className="flex items-center gap-2">
                        <EyeOff className="w-4 h-4" />
                        Low (Minimal effects)
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p style={{ color: theme.text }} className="font-medium">Particle Effects</p>
                    <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Floating particles</p>
                  </div>
                  <Switch
                    checked={settings.particleEffects}
                    onCheckedChange={(checked) => updateSettings({ particleEffects: checked })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p style={{ color: theme.text }} className="font-medium">Background Animations</p>
                    <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Theme background effects</p>
                  </div>
                  <Switch
                    checked={settings.backgroundAnimations}
                    onCheckedChange={(checked) => updateSettings({ backgroundAnimations: checked })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p style={{ color: theme.text }} className="font-medium">Hover Effects</p>
                    <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Interactive hover states</p>
                  </div>
                  <Switch
                    checked={settings.hoverEffects}
                    onCheckedChange={(checked) => updateSettings({ hoverEffects: checked })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p style={{ color: theme.text }} className="font-medium">Transition Effects</p>
                    <p style={{ color: theme.text, opacity: 0.7 }} className="text-sm">Page transitions</p>
                  </div>
                  <Switch
                    checked={settings.transitionEffects}
                    onCheckedChange={(checked) => updateSettings({ transitionEffects: checked })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Animation Timing */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Clock className="w-5 h-5" />
                Animation Timing
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p style={{ color: theme.text }} className="font-medium">Duration</p>
                  <span style={{ color: theme.text, opacity: 0.7 }} className="text-sm">
                    {settings.duration}ms
                  </span>
                </div>
                <Slider
                  value={[settings.duration]}
                  onValueChange={handleDurationChange}
                  max={1000}
                  min={50}
                  step={50}
                  className="w-full"
                />
                <div className="flex justify-between mt-1">
                  <span style={{ color: theme.text, opacity: 0.5 }} className="text-xs">Fast</span>
                  <span style={{ color: theme.text, opacity: 0.5 }} className="text-xs">Slow</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Preset Transitions */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Sparkles className="w-5 h-5" />
                Preset Transitions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p style={{ color: theme.text }} className="font-medium mb-3">Choose a preset</p>
                <div className="grid grid-cols-2 gap-2">
                  {Object.keys(presets).map((preset) => (
                    <Button
                      key={preset}
                      variant="outline"
                      onClick={() => setPresetTransitions(preset as keyof typeof presets)}
                      size="sm"
                      className="capitalize"
                    >
                      {preset}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Custom Transitions */}
          <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
                <Settings className="w-5 h-5" />
                Custom Transitions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p style={{ color: theme.text }} className="font-medium mb-3">Custom CSS Transitions</p>
                <div className="space-y-3">
                  <div>
                    <label style={{ color: theme.text, opacity: 0.8 }} className="text-sm">Enter Animation</label>
                    <input
                      type="text"
                      value={settings.customTransitions.enter}
                      onChange={(e) => handleCustomTransitionChange('enter', e.target.value)}
                      className="w-full mt-1 px-3 py-2 rounded border text-sm"
                      style={{ 
                        backgroundColor: theme.secondary, 
                        borderColor: theme.borderColor,
                        color: theme.text
                      }}
                      placeholder="transform 0.3s ease-out, opacity 0.3s ease-out"
                    />
                  </div>
                  
                  <div>
                    <label style={{ color: theme.text, opacity: 0.8 }} className="text-sm">Exit Animation</label>
                    <input
                      type="text"
                      value={settings.customTransitions.exit}
                      onChange={(e) => handleCustomTransitionChange('exit', e.target.value)}
                      className="w-full mt-1 px-3 py-2 rounded border text-sm"
                      style={{ 
                        backgroundColor: theme.secondary, 
                        borderColor: theme.borderColor,
                        color: theme.text
                      }}
                      placeholder="transform 0.2s ease-in, opacity 0.2s ease-in"
                    />
                  </div>
                  
                  <div>
                    <label style={{ color: theme.text, opacity: 0.8 }} className="text-sm">Hover Effect</label>
                    <input
                      type="text"
                      value={settings.customTransitions.hover}
                      onChange={(e) => handleCustomTransitionChange('hover', e.target.value)}
                      className="w-full mt-1 px-3 py-2 rounded border text-sm"
                      style={{ 
                        backgroundColor: theme.secondary, 
                        borderColor: theme.borderColor,
                        color: theme.text
                      }}
                      placeholder="transform 0.2s ease-out, box-shadow 0.2s ease-out"
                    />
                  </div>
                  
                  <div>
                    <label style={{ color: theme.text, opacity: 0.8 }} className="text-sm">Click Effect</label>
                    <input
                      type="text"
                      value={settings.customTransitions.click}
                      onChange={(e) => handleCustomTransitionChange('click', e.target.value)}
                      className="w-full mt-1 px-3 py-2 rounded border text-sm"
                      style={{ 
                        backgroundColor: theme.secondary, 
                        borderColor: theme.borderColor,
                        color: theme.text
                      }}
                      placeholder="transform 0.1s ease-in-out"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Preview Animation */}
      {isPreviewing && (
        <Card 
          className="animate-pulse"
          style={{ 
            backgroundColor: theme.cardBg, 
            borderColor: theme.borderColor,
            transition: settings.customTransitions.enter
          }}
        >
          <CardContent className="p-4 text-center">
            <p style={{ color: theme.text }}>Animation Preview Active!</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}