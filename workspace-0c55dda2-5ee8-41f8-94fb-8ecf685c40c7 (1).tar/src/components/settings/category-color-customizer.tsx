'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Palette, 
  Save, 
  RotateCcw, 
  Plus,
  X,
  Edit2,
  Check
} from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useSettings } from '@/contexts/SettingsContext'

interface CategoryColor {
  name: string
  color: string
  defaultColor: string
}

const defaultCategories: CategoryColor[] = [
  { name: 'Personal', color: '#3b82f6', defaultColor: '#3b82f6' },
  { name: 'Work', color: '#ef4444', defaultColor: '#ef4444' },
  { name: 'Health', color: '#10b981', defaultColor: '#10b981' },
  { name: 'Shopping', color: '#f59e0b', defaultColor: '#f59e0b' },
  { name: 'Finance', color: '#8b5cf6', defaultColor: '#8b5cf6' },
  { name: 'Learning', color: '#ec4899', defaultColor: '#ec4899' },
  { name: 'Social', color: '#14b8a6', defaultColor: '#14b8a6' },
  { name: 'Other', color: '#6b7280', defaultColor: '#6b7280' },
]

const expenseCategories: CategoryColor[] = [
  { name: 'Food & Dining', color: '#f97316', defaultColor: '#f97316' },
  { name: 'Transportation', color: '#06b6d4', defaultColor: '#06b6d4' },
  { name: 'Shopping', color: '#f59e0b', defaultColor: '#f59e0b' },
  { name: 'Entertainment', color: '#a855f7', defaultColor: '#a855f7' },
  { name: 'Bills & Utilities', color: '#ef4444', defaultColor: '#ef4444' },
  { name: 'Healthcare', color: '#10b981', defaultColor: '#10b981' },
  { name: 'Education', color: '#3b82f6', defaultColor: '#3b82f6' },
  { name: 'Travel', color: '#14b8a6', defaultColor: '#14b8a6' },
  { name: 'Other', color: '#6b7280', defaultColor: '#6b7280' },
]

const healthCategories: CategoryColor[] = [
  { name: 'Weight', color: '#ef4444', defaultColor: '#ef4444' },
  { name: 'Blood Pressure', color: '#f97316', defaultColor: '#f97316' },
  { name: 'Heart Rate', color: '#ec4899', defaultColor: '#ec4899' },
  { name: 'Water Intake', color: '#06b6d4', defaultColor: '#06b6d4' },
  { name: 'Sleep', color: '#8b5cf6', defaultColor: '#8b5cf6' },
  { name: 'Exercise', color: '#10b981', defaultColor: '#10b981' },
  { name: 'Medication', color: '#3b82f6', defaultColor: '#3b82f6' },
  { name: 'Mood', color: '#f59e0b', defaultColor: '#f59e0b' },
  { name: 'Other', color: '#6b7280', defaultColor: '#6b7280' },
]

export function CategoryColorCustomizer() {
  const { theme } = useTheme()
  const { categoryColors, setCategoryColors } = useSettings()
  
  const [activityCategories, setActivityCategories] = useState<CategoryColor[]>(defaultCategories)
  const [expenseCategoryList, setExpenseCategoryList] = useState<CategoryColor[]>(expenseCategories)
  const [healthCategoryList, setHealthCategoryList] = useState<CategoryColor[]>(healthCategories)
  const [editingCategory, setEditingCategory] = useState<string | null>(null)
  const [newCategoryName, setNewCategoryName] = useState('')
  const [newCategoryType, setNewCategoryType] = useState<'activity' | 'expense' | 'health'>('activity')

  useEffect(() => {
    // Load saved colors from settings
    if (categoryColors) {
      if (categoryColors.activities) {
        setActivityCategories(prev => 
          prev.map(cat => ({
            ...cat,
            color: categoryColors.activities[cat.name] || cat.color
          }))
        )
      }
      if (categoryColors.expenses) {
        setExpenseCategoryList(prev => 
          prev.map(cat => ({
            ...cat,
            color: categoryColors.expenses[cat.name] || cat.color
          }))
        )
      }
      if (categoryColors.health) {
        setHealthCategoryList(prev => 
          prev.map(cat => ({
            ...cat,
            color: categoryColors.health[cat.name] || cat.color
          }))
        )
      }
    }
  }, [categoryColors])

  const handleColorChange = (categoryType: 'activity' | 'expense' | 'health', categoryName: string, newColor: string) => {
    switch (categoryType) {
      case 'activity':
        setActivityCategories(prev => 
          prev.map(cat => 
            cat.name === categoryName ? { ...cat, color: newColor } : cat
          )
        )
        break
      case 'expense':
        setExpenseCategoryList(prev => 
          prev.map(cat => 
            cat.name === categoryName ? { ...cat, color: newColor } : cat
          )
        )
        break
      case 'health':
        setHealthCategoryList(prev => 
          prev.map(cat => 
            cat.name === categoryName ? { ...cat, color: newColor } : cat
          )
        )
        break
    }
  }

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return

    const newCategory: CategoryColor = {
      name: newCategoryName.trim(),
      color: '#' + Math.floor(Math.random()*16777215).toString(16),
      defaultColor: '#' + Math.floor(Math.random()*16777215).toString(16)
    }

    switch (newCategoryType) {
      case 'activity':
        setActivityCategories(prev => [...prev, newCategory])
        break
      case 'expense':
        setExpenseCategoryList(prev => [...prev, newCategory])
        break
      case 'health':
        setHealthCategoryList(prev => [...prev, newCategory])
        break
    }

    setNewCategoryName('')
  }

  const handleDeleteCategory = (categoryType: 'activity' | 'expense' | 'health', categoryName: string) => {
    switch (categoryType) {
      case 'activity':
        setActivityCategories(prev => prev.filter(cat => cat.name !== categoryName))
        break
      case 'expense':
        setExpenseCategoryList(prev => prev.filter(cat => cat.name !== categoryName))
        break
      case 'health':
        setHealthCategoryList(prev => prev.filter(cat => cat.name !== categoryName))
        break
    }
  }

  const handleResetColors = () => {
    setActivityCategories(defaultCategories)
    setExpenseCategoryList(expenseCategories)
    setHealthCategoryList(healthCategories)
  }

  const handleSaveColors = () => {
    const colors = {
      activities: activityCategories.reduce((acc, cat) => {
        acc[cat.name] = cat.color
        return acc
      }, {} as Record<string, string>),
      expenses: expenseCategoryList.reduce((acc, cat) => {
        acc[cat.name] = cat.color
        return acc
      }, {} as Record<string, string>),
      health: healthCategoryList.reduce((acc, cat) => {
        acc[cat.name] = cat.color
        return acc
      }, {} as Record<string, string>)
    }
    
    setCategoryColors(colors)
  }

  const renderCategoryList = (
    categories: CategoryColor[], 
    categoryType: 'activity' | 'expense' | 'health',
    title: string
  ) => (
    <Card style={{ backgroundColor: theme.cardBg, borderColor: theme.borderColor }}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2" style={{ color: theme.text }}>
          <Palette className="w-5 h-5" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categories.map((category) => (
            <div key={category.name} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: theme.borderColor }}>
              <div className="flex items-center gap-3">
                <div 
                  className="w-6 h-6 rounded-full border-2"
                  style={{ 
                    backgroundColor: category.color,
                    borderColor: theme.borderColor
                  }}
                />
                <span style={{ color: theme.text }} className="font-medium">
                  {category.name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={category.color}
                  onChange={(e) => handleColorChange(categoryType, category.name, e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer"
                />
                {category.name !== 'Other' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteCategory(categoryType, category.name)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {/* Add new category */}
        <div className="flex items-center gap-2 p-3 rounded-lg border" style={{ borderColor: theme.borderColor }}>
          <Input
            placeholder="New category name"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            className="flex-1"
            style={{ 
              backgroundColor: theme.secondary,
              borderColor: theme.borderColor,
              color: theme.text
            }}
          />
          <select
            value={newCategoryType}
            onChange={(e) => setNewCategoryType(e.target.value as 'activity' | 'expense' | 'health')}
            className="px-3 py-2 rounded border"
            style={{ 
              backgroundColor: theme.secondary,
              borderColor: theme.borderColor,
              color: theme.text
            }}
          >
            <option value="activity">Activity</option>
            <option value="expense">Expense</option>
            <option value="health">Health</option>
          </select>
          <Button
            onClick={handleAddCategory}
            size="sm"
            className="flex items-center gap-1"
          >
            <Plus className="w-4 h-4" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Palette className="w-6 h-6" style={{ color: theme.primary }} />
          <h3 className="text-xl font-semibold" style={{ color: theme.text }}>
            Category Colors
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={handleResetColors}
            className="flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
          <Button
            onClick={handleSaveColors}
            className="flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Colors
          </Button>
        </div>
      </div>

      {renderCategoryList(activityCategories, 'activity', 'Activity Categories')}
      {renderCategoryList(expenseCategoryList, 'expense', 'Expense Categories')}
      {renderCategoryList(healthCategoryList, 'health', 'Health Categories')}

      <div className="p-4 rounded-lg" style={{ backgroundColor: theme.secondary + '20' }}>
        <p style={{ color: theme.text, opacity: 0.8 }} className="text-sm">
          Customize the colors for your categories to make your data more visually organized. 
          These colors will be used throughout the app in charts, lists, and calendar views.
        </p>
      </div>
    </div>
  )
}