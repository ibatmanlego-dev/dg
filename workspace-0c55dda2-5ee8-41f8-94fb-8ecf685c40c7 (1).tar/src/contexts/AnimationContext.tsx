'use client'

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'

export interface AnimationSettings {
  enabled: boolean
  duration: number // in milliseconds
  easing: string
  particleEffects: boolean
  backgroundAnimations: boolean
  hoverEffects: boolean
  transitionEffects: boolean
  customTransitions: {
    enter: string
    exit: string
    hover: string
    click: string
  }
  performanceMode: 'high' | 'medium' | 'low'
}

const defaultAnimationSettings: AnimationSettings = {
  enabled: false, // DISABLED - remove all smoke/fade animations
  duration: 0,
  easing: 'none',
  particleEffects: false, // DISABLED - remove smoke effects
  backgroundAnimations: false, // DISABLED - remove background animations
  hoverEffects: false, // DISABLED - remove hover effects
  transitionEffects: false, // DISABLED - remove all transitions
  customTransitions: {
    enter: 'none',
    exit: 'none',
    hover: 'none',
    click: 'none'
  },
  performanceMode: 'low'
}

const presetTransitions = {
  smooth: {
    enter: 'transform 0.4s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    exit: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    hover: 'transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    click: 'transform 0.1s cubic-bezier(0.4, 0, 0.2, 1)'
  },
  snappy: {
    enter: 'transform 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
    exit: 'transform 0.15s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.15s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
    hover: 'transform 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
    click: 'transform 0.05s cubic-bezier(0.25, 0.46, 0.45, 0.94)'
  },
  bouncy: {
    enter: 'transform 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55), opacity 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    exit: 'transform 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55), opacity 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    hover: 'transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55), box-shadow 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    click: 'transform 0.2s cubic-bezier(0.68, -0.55, 0.265, 1.55)'
  },
  elegant: {
    enter: 'transform 0.5s cubic-bezier(0.23, 1, 0.32, 1), opacity 0.5s cubic-bezier(0.23, 1, 0.32, 1)',
    exit: 'transform 0.4s cubic-bezier(0.23, 1, 0.32, 1), opacity 0.4s cubic-bezier(0.23, 1, 0.32, 1)',
    hover: 'transform 0.25s cubic-bezier(0.23, 1, 0.32, 1), box-shadow 0.25s cubic-bezier(0.23, 1, 0.32, 1)',
    click: 'transform 0.15s cubic-bezier(0.23, 1, 0.32, 1)'
  }
}

interface AnimationContextType {
  settings: AnimationSettings
  updateSettings: (newSettings: Partial<AnimationSettings>) => void
  toggleAnimations: () => void
  setPresetTransitions: (preset: keyof typeof presetTransitions) => void
  resetToDefaults: () => void
  presets: typeof presetTransitions
}

const AnimationContext = createContext<AnimationContextType | undefined>(undefined)

export function AnimationProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AnimationSettings>(defaultAnimationSettings)

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('vibetracker-animation-settings')
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings)
        setSettings({ ...defaultAnimationSettings, ...parsed })
      } catch (error) {
        console.error('Failed to parse animation settings:', error)
      }
    }
  }, [])

  // Save settings to localStorage
  useEffect(() => {
    localStorage.setItem('vibetracker-animation-settings', JSON.stringify(settings))
  }, [settings])

  // Apply animation settings to CSS variables
  useEffect(() => {
    const root = document.documentElement
    
    if (settings.enabled) {
      root.style.setProperty('--animation-duration', `${settings.duration}ms`)
      root.style.setProperty('--animation-easing', settings.easing)
      root.style.setProperty('--transition-enter', settings.customTransitions.enter)
      root.style.setProperty('--transition-exit', settings.customTransitions.exit)
      root.style.setProperty('--transition-hover', settings.customTransitions.hover)
      root.style.setProperty('--transition-click', settings.customTransitions.click)
      
      // Set data attributes for conditional animations
      root.setAttribute('data-animations-enabled', 'true')
      root.setAttribute('data-particles', settings.particleEffects ? 'true' : 'false')
      root.setAttribute('data-bg-animations', settings.backgroundAnimations ? 'true' : 'false')
      root.setAttribute('data-hover-effects', settings.hoverEffects ? 'true' : 'false')
      root.setAttribute('data-performance-mode', settings.performanceMode)
    } else {
      root.setAttribute('data-animations-enabled', 'false')
      root.removeAttribute('--animation-duration')
      root.removeAttribute('--animation-easing')
      root.removeAttribute('--transition-enter')
      root.removeAttribute('--transition-exit')
      root.removeAttribute('--transition-hover')
      root.removeAttribute('--transition-click')
    }
  }, [settings])

  const updateSettings = (newSettings: Partial<AnimationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }))
  }

  const toggleAnimations = () => {
    setSettings(prev => ({ ...prev, enabled: !prev.enabled }))
  }

  const setPresetTransitions = (preset: keyof typeof presetTransitions) => {
    setSettings(prev => ({
      ...prev,
      customTransitions: presetTransitions[preset]
    }))
  }

  const resetToDefaults = () => {
    setSettings(defaultAnimationSettings)
  }

  const value: AnimationContextType = {
    settings,
    updateSettings,
    toggleAnimations,
    setPresetTransitions,
    resetToDefaults,
    presets: presetTransitions
  }

  return (
    <AnimationContext.Provider value={value}>
      {children}
    </AnimationContext.Provider>
  )
}

export function useAnimation() {
  const context = useContext(AnimationContext)
  if (context === undefined) {
    throw new Error('useAnimation must be used within an AnimationProvider')
  }
  return context
}