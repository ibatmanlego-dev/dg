'use client'

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { isWithinInterval, parseISO, startOfDay, endOfDay } from 'date-fns'

// Simplified types for faster loading
export interface UserSettings {
  id: string
  userId: string
  theme: string
  currency: string
  pin?: string
  streak: number
  level: number
  vibePoints: number
  lastActive: Date
  showVibeScore: boolean
  showLevelProgress: boolean
  showStreak: boolean
  showCharts: boolean
  showSummaryCards: boolean
  periodTrackerEnabled: boolean
  categoryColors: string
}

export interface Activity {
  id: string
  title: string
  category: string
  description?: string
  priority: 'low' | 'medium' | 'high'
  scheduledDate: string
  scheduledTime: string
  isRecurring: boolean
  alertEnabled: boolean
  completed: boolean
  createdAt: string
  completedAt?: string
}

export interface Expense {
  id: string
  title: string
  amount: number
  category: string
  date: string
  description?: string
  createdAt: string
}

export interface HealthMetric {
  id: string
  type: 'weight' | 'blood_pressure' | 'heart_rate' | 'water' | 'sleep' | 'exercise'
  value: string
  unit: string
  date: string
  notes?: string
  createdAt: string
}

export interface DateFilter {
  startDate?: string
  endDate?: string
  dataTypes: {
    activities: boolean
    expenses: boolean
    health: boolean
  }
}

interface DataContextType {
  // User data
  settings: UserSettings | null
  
  // Activities
  activities: Activity[]
  filteredActivities: Activity[]
  addActivity: (activity: Omit<Activity, 'id' | 'createdAt'>) => Promise<void>
  updateActivity: (id: string, updates: Partial<Activity>) => Promise<void>
  deleteActivity: (id: string) => Promise<void>
  
  // Expenses
  expenses: Expense[]
  filteredExpenses: Expense[]
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => Promise<void>
  updateExpense: (id: string, updates: Partial<Expense>) => Promise<void>
  deleteExpense: (id: string) => Promise<void>
  
  // Health metrics
  healthMetrics: HealthMetric[]
  filteredHealthMetrics: HealthMetric[]
  addHealthMetric: (metric: Omit<HealthMetric, 'id' | 'createdAt'>) => Promise<void>
  updateHealthMetric: (id: string, updates: Partial<HealthMetric>) => Promise<void>
  deleteHealthMetric: (id: string) => Promise<void>
  
  // Date filtering
  dateFilter: DateFilter
  setDateFilter: (filter: DateFilter) => void
  
  // Settings
  updateSettings: (updates: Partial<UserSettings>) => Promise<void>
  
  // Data export/import
  exportData: () => any
  importData: (data: any) => void
  clearAllData: () => void
  
  // Loading state
  loading: boolean
  refresh: () => Promise<void>
}

const DataContext = createContext<DataContextType | undefined>(undefined)

export function DataProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [activities, setActivities] = useState<Activity[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [healthMetrics, setHealthMetrics] = useState<HealthMetric[]>([])
  const [loading, setLoading] = useState(true)
  const [dateFilter, setDateFilter] = useState<DateFilter>({
    dataTypes: {
      activities: true,
      expenses: true,
      health: true
    }
  })

  // Initialize with default settings immediately for faster loading
  useEffect(() => {
    const initializeSettings = async () => {
      try {
        // Set default settings immediately
        const defaultSettings: UserSettings = {
          id: 'default',
          userId: 'default',
          theme: 'dark',
          currency: 'USD',
          streak: 0,
          level: 1,
          vibePoints: 0,
          lastActive: new Date(),
          showVibeScore: true,
          showLevelProgress: true,
          showStreak: true,
          showCharts: true,
          showSummaryCards: true,
          periodTrackerEnabled: false,
          categoryColors: '{}',
        }
        
        setSettings(defaultSettings)
        
        // Load data from localStorage as fallback
        try {
          const storedActivities = localStorage.getItem('activities')
          if (storedActivities) {
            setActivities(JSON.parse(storedActivities))
          }
          
          const storedExpenses = localStorage.getItem('expenses')
          if (storedExpenses) {
            setExpenses(JSON.parse(storedExpenses))
          }
          
          const storedMetrics = localStorage.getItem('healthMetrics')
          if (storedMetrics) {
            setHealthMetrics(JSON.parse(storedMetrics))
          }
        } catch (localStorageError) {
          console.log('localStorage not available, using empty arrays')
          setActivities([])
          setExpenses([])
          setHealthMetrics([])
        }
        
        setLoading(false)
        
        // Try to load from database in background
        try {
          const { db } = await import('@/lib/db')
          let user = await db.user.findFirst()
          
          if (!user) {
            user = await db.user.create({
              data: {
                name: 'User',
                email: 'user@example.com',
              },
            })
            
            await db.userSettings.create({
              data: {
                userId: user.id,
              },
            })
          }
          
          const userSettings = await db.userSettings.findUnique({
            where: { userId: user.id },
          })
          
          if (userSettings) {
            setSettings(userSettings)
          }
          
          // Load activities
          const activitiesData = await db.activity.findMany({
            where: { userId: user.id },
            orderBy: { createdAt: 'desc' }
          })
          setActivities(activitiesData)
          
          // Load expenses
          const expensesData = await db.expense.findMany({
            where: { userId: user.id },
            orderBy: { createdAt: 'desc' }
          })
          setExpenses(expensesData)
          
          // Load health metrics
          const metrics = await db.healthMetric.findMany({
            where: { userId: user.id },
            orderBy: { date: 'desc' }
          })
          setHealthMetrics(metrics)
          
        } catch (dbError) {
          console.log('Database not available, using defaults')
        }
        
      } catch (error) {
        console.error('Error initializing settings:', error)
        setLoading(false)
      }
    }
    
    initializeSettings()
  }, [])

  const updateSettings = async (updates: Partial<UserSettings>) => {
    if (!settings) return
    
    try {
      // Update local state immediately for responsiveness
      const updatedSettings = { ...settings, ...updates }
      setSettings(updatedSettings)
      
      // Try to update database
      try {
        const { db } = await import('@/lib/db')
        await db.userSettings.update({
          where: { id: settings.id },
          data: updates,
        })
      } catch (dbError) {
        console.log('Database update failed, changes are local only')
      }
    } catch (error) {
      console.error('Error updating settings:', error)
    }
  }

  // Activity CRUD operations
  const addActivity = async (activity: Omit<Activity, 'id' | 'createdAt'>) => {
    try {
      // Update local state immediately
      const newActivity: Activity = {
        ...activity,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
      setActivities(prev => {
        const updated = [newActivity, ...prev]
        // Save to localStorage as fallback
        try {
          localStorage.setItem('activities', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to save to database
      try {
        const { db } = await import('@/lib/db')
        const user = await db.user.findFirst()
        if (user) {
          await db.activity.create({
            data: {
              ...activity,
              userId: user.id,
            },
          })
        }
      } catch (dbError) {
        console.log('Database save failed, activity is local only')
      }
    } catch (error) {
      console.error('Error adding activity:', error)
    }
  }

  const updateActivity = async (id: string, updates: Partial<Activity>) => {
    try {
      // Update local state immediately
      setActivities(prev => {
        const updated = prev.map(activity => 
          activity.id === id ? { ...activity, ...updates } : activity
        )
        // Save to localStorage as fallback
        try {
          localStorage.setItem('activities', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to update database
      try {
        const { db } = await import('@/lib/db')
        await db.activity.update({
          where: { id },
          data: updates,
        })
      } catch (dbError) {
        console.log('Database update failed, changes are local only')
      }
    } catch (error) {
      console.error('Error updating activity:', error)
    }
  }

  const deleteActivity = async (id: string) => {
    try {
      // Update local state immediately
      setActivities(prev => {
        const updated = prev.filter(activity => activity.id !== id)
        // Save to localStorage as fallback
        try {
          localStorage.setItem('activities', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to delete from database
      try {
        const { db } = await import('@/lib/db')
        await db.activity.delete({
          where: { id },
        })
      } catch (dbError) {
        console.log('Database delete failed, activity is removed from local only')
      }
    } catch (error) {
      console.error('Error deleting activity:', error)
    }
  }

  // Expense CRUD operations
  const addExpense = async (expense: Omit<Expense, 'id' | 'createdAt'>) => {
    try {
      // Update local state immediately
      const newExpense: Expense = {
        ...expense,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
      setExpenses(prev => {
        const updated = [newExpense, ...prev]
        // Save to localStorage as fallback
        try {
          localStorage.setItem('expenses', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to save to database
      try {
        const { db } = await import('@/lib/db')
        const user = await db.user.findFirst()
        if (user) {
          await db.expense.create({
            data: {
              ...expense,
              userId: user.id,
            },
          })
        }
      } catch (dbError) {
        console.log('Database save failed, expense is local only')
      }
    } catch (error) {
      console.error('Error adding expense:', error)
    }
  }

  const updateExpense = async (id: string, updates: Partial<Expense>) => {
    try {
      // Update local state immediately
      setExpenses(prev => {
        const updated = prev.map(expense => 
          expense.id === id ? { ...expense, ...updates } : expense
        )
        // Save to localStorage as fallback
        try {
          localStorage.setItem('expenses', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to update database
      try {
        const { db } = await import('@/lib/db')
        await db.expense.update({
          where: { id },
          data: updates,
        })
      } catch (dbError) {
        console.log('Database update failed, changes are local only')
      }
    } catch (error) {
      console.error('Error updating expense:', error)
    }
  }

  const deleteExpense = async (id: string) => {
    try {
      // Update local state immediately
      setExpenses(prev => {
        const updated = prev.filter(expense => expense.id !== id)
        // Save to localStorage as fallback
        try {
          localStorage.setItem('expenses', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to delete from database
      try {
        const { db } = await import('@/lib/db')
        await db.expense.delete({
          where: { id },
        })
      } catch (dbError) {
        console.log('Database delete failed, expense is removed from local only')
      }
    } catch (error) {
      console.error('Error deleting expense:', error)
    }
  }

  const addHealthMetric = async (metric: Omit<HealthMetric, 'id' | 'createdAt'>) => {
    try {
      // Update local state immediately
      const newMetric: HealthMetric = {
        ...metric,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
      setHealthMetrics(prev => {
        const updated = [newMetric, ...prev]
        // Save to localStorage as fallback
        try {
          localStorage.setItem('healthMetrics', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to save to database
      try {
        const { db } = await import('@/lib/db')
        const user = await db.user.findFirst()
        if (user) {
          await db.healthMetric.create({
            data: {
              ...metric,
              userId: user.id,
            },
          })
        }
      } catch (dbError) {
        console.log('Database save failed, metric is local only')
      }
    } catch (error) {
      console.error('Error adding health metric:', error)
    }
  }

  const updateHealthMetric = async (id: string, updates: Partial<HealthMetric>) => {
    try {
      // Update local state immediately
      setHealthMetrics(prev => {
        const updated = prev.map(metric => 
          metric.id === id ? { ...metric, ...updates } : metric
        )
        // Save to localStorage as fallback
        try {
          localStorage.setItem('healthMetrics', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to update database
      try {
        const { db } = await import('@/lib/db')
        await db.healthMetric.update({
          where: { id },
          data: updates,
        })
      } catch (dbError) {
        console.log('Database update failed, changes are local only')
      }
    } catch (error) {
      console.error('Error updating health metric:', error)
    }
  }

  const deleteHealthMetric = async (id: string) => {
    try {
      // Update local state immediately
      setHealthMetrics(prev => {
        const updated = prev.filter(metric => metric.id !== id)
        // Save to localStorage as fallback
        try {
          localStorage.setItem('healthMetrics', JSON.stringify(updated))
        } catch (error) {
          console.log('localStorage save failed')
        }
        return updated
      })
      
      // Try to delete from database
      try {
        const { db } = await import('@/lib/db')
        await db.healthMetric.delete({
          where: { id },
        })
      } catch (dbError) {
        console.log('Database delete failed, metric is removed from local only')
      }
    } catch (error) {
      console.error('Error deleting health metric:', error)
    }
  }

  const refresh = async () => {
    // Simple refresh - just reload settings and all data
    try {
      const { db } = await import('@/lib/db')
      const user = await db.user.findFirst()
      if (user) {
        const userSettings = await db.userSettings.findUnique({
          where: { userId: user.id },
        })
        if (userSettings) {
          setSettings(userSettings)
        }
        
        // Reload activities
        const activitiesData = await db.activity.findMany({
          where: { userId: user.id },
          orderBy: { createdAt: 'desc' }
        })
        setActivities(activitiesData)
        
        // Reload expenses
        const expensesData = await db.expense.findMany({
          where: { userId: user.id },
          orderBy: { createdAt: 'desc' }
        })
        setExpenses(expensesData)
        
        // Reload health metrics
        const metrics = await db.healthMetric.findMany({
          where: { userId: user.id },
          orderBy: { date: 'desc' }
        })
        setHealthMetrics(metrics)
      }
    } catch (error) {
      console.log('Refresh failed, keeping current data')
    }
  }

  // Export all data
  const exportData = () => {
    return {
      settings,
      activities,
      expenses,
      healthMetrics,
      exportDate: new Date().toISOString(),
      version: '1.0.0'
    }
  }

  // Import data
  const importData = (data: any) => {
    try {
      if (data.settings) {
        setSettings(data.settings)
        // Save to localStorage
        try {
          localStorage.setItem('userSettings', JSON.stringify(data.settings))
        } catch (error) {
          console.log('localStorage save failed')
        }
      }
      
      if (data.activities) {
        setActivities(data.activities)
        // Save to localStorage
        try {
          localStorage.setItem('activities', JSON.stringify(data.activities))
        } catch (error) {
          console.log('localStorage save failed')
        }
      }
      
      if (data.expenses) {
        setExpenses(data.expenses)
        // Save to localStorage
        try {
          localStorage.setItem('expenses', JSON.stringify(data.expenses))
        } catch (error) {
          console.log('localStorage save failed')
        }
      }
      
      if (data.healthMetrics) {
        setHealthMetrics(data.healthMetrics)
        // Save to localStorage
        try {
          localStorage.setItem('healthMetrics', JSON.stringify(data.healthMetrics))
        } catch (error) {
          console.log('localStorage save failed')
        }
      }
    } catch (error) {
      console.error('Error importing data:', error)
      throw new Error('Failed to import data')
    }
  }

  // Clear all data
  const clearAllData = () => {
    setSettings(null)
    setActivities([])
    setExpenses([])
    setHealthMetrics([])
    
    // Clear localStorage
    try {
      localStorage.removeItem('userSettings')
      localStorage.removeItem('activities')
      localStorage.removeItem('expenses')
      localStorage.removeItem('healthMetrics')
    } catch (error) {
      console.log('localStorage clear failed')
    }
  }

  // Filter data based on date filter
  const filterDataByDate = (data: any[], dateField: string) => {
    if (!dateFilter.startDate && !dateFilter.endDate) {
      return data
    }

    return data.filter(item => {
      const itemDate = parseISO(item[dateField])
      
      if (dateFilter.startDate && dateFilter.endDate) {
        return isWithinInterval(itemDate, {
          start: startOfDay(parseISO(dateFilter.startDate)),
          end: endOfDay(parseISO(dateFilter.endDate))
        })
      } else if (dateFilter.startDate) {
        return itemDate >= startOfDay(parseISO(dateFilter.startDate))
      } else if (dateFilter.endDate) {
        return itemDate <= endOfDay(parseISO(dateFilter.endDate))
      }
      
      return true
    })
  }

  const filteredActivities = dateFilter.dataTypes.activities 
    ? filterDataByDate(activities, 'scheduledDate')
    : []

  const filteredExpenses = dateFilter.dataTypes.expenses 
    ? filterDataByDate(expenses, 'date')
    : []

  const filteredHealthMetrics = dateFilter.dataTypes.health 
    ? filterDataByDate(healthMetrics, 'date')
    : []

  return (
    <DataContext.Provider value={{
      settings,
      activities,
      filteredActivities,
      expenses,
      filteredExpenses,
      healthMetrics,
      filteredHealthMetrics,
      addActivity,
      updateActivity,
      deleteActivity,
      addExpense,
      updateExpense,
      deleteExpense,
      addHealthMetric,
      updateHealthMetric,
      deleteHealthMetric,
      dateFilter,
      setDateFilter,
      updateSettings,
      exportData,
      importData,
      clearAllData,
      loading,
      refresh,
    }}>
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider')
  }
  return context
}