'use client'

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'

interface CategoryColors {
  activities: Record<string, string>
  expenses: Record<string, string>
  health: Record<string, string>
}

interface Currency {
  code: string
  symbol: string
  country: string
}

interface SettingsContextType {
  periodTrackerEnabled: boolean
  setPeriodTrackerEnabled: (enabled: boolean) => void
  vaultEnabled: boolean
  setVaultEnabled: (enabled: boolean) => void
  notificationsEnabled: boolean
  setNotificationsEnabled: (enabled: boolean) => void
  autoBackupEnabled: boolean
  setAutoBackupEnabled: (enabled: boolean) => void
  userName: string
  setUserName: (name: string) => void
  profilePicture: string | null
  setProfilePicture: (picture: string | null) => void
  categoryColors: CategoryColors | null
  setCategoryColors: (colors: CategoryColors | null) => void
  currency: Currency
  setCurrency: (currency: Currency) => void
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [periodTrackerEnabled, setPeriodTrackerEnabled] = useState(false)
  const [vaultEnabled, setVaultEnabled] = useState(false)
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const [autoBackupEnabled, setAutoBackupEnabled] = useState(false)
  const [userName, setUserName] = useState('User')
  const [profilePicture, setProfilePicture] = useState<string | null>(null)
  const [categoryColors, setCategoryColors] = useState<CategoryColors | null>(null)
  const [currency, setCurrency] = useState<Currency>({
    code: 'USD',
    symbol: '$',
    country: 'United States'
  })

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('vibetracker-settings')
    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings)
        setPeriodTrackerEnabled(settings.periodTrackerEnabled || false)
        setVaultEnabled(settings.vaultEnabled || false)
        setNotificationsEnabled(settings.notificationsEnabled !== false) // default true
        setAutoBackupEnabled(settings.autoBackupEnabled || false)
        setUserName(settings.userName || 'User')
        setProfilePicture(settings.profilePicture || null)
        setCategoryColors(settings.categoryColors || null)
        setCurrency(settings.currency || { code: 'USD', symbol: '$', country: 'United States' })
      } catch (error) {
        console.error('Failed to load settings:', error)
      }
    }
  }, [])

  // Save settings to localStorage
  useEffect(() => {
    const settings = {
      periodTrackerEnabled,
      vaultEnabled,
      notificationsEnabled,
      autoBackupEnabled,
      userName,
      profilePicture,
      categoryColors,
      currency
    }
    localStorage.setItem('vibetracker-settings', JSON.stringify(settings))
  }, [periodTrackerEnabled, vaultEnabled, notificationsEnabled, autoBackupEnabled, userName, profilePicture, categoryColors, currency])

  const value: SettingsContextType = {
    periodTrackerEnabled,
    setPeriodTrackerEnabled,
    vaultEnabled,
    setVaultEnabled,
    notificationsEnabled,
    setNotificationsEnabled,
    autoBackupEnabled,
    setAutoBackupEnabled,
    userName,
    setUserName,
    profilePicture,
    setProfilePicture,
    categoryColors,
    setCategoryColors,
    currency,
    setCurrency
  }

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider')
  }
  return context
}