'use client'

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'

export interface Theme {
  name: string
  displayName: string
  bg: string
  text: string
  primary: string
  secondary: string
  accent: string
  cardBg: string
  borderColor: string
  danger: string
  gradient?: string
  particleColor?: string
  glowColor?: string
  animationType?: 'pulse' | 'wave' | 'aurora' | 'cosmic' | 'none'
  glassEffect?: boolean
  neonEffect?: boolean
  gradientBg?: string
  shadowColor?: string
}

const visualMasterpieceThemes: Record<string, Theme> = {
  // Basic Light Theme
  light: {
    name: 'light',
    displayName: '☀️ Light',
    bg: '#ffffff',
    text: '#000000',
    primary: '#3b82f6',
    secondary: '#f3f4f6',
    accent: '#10b981',
    cardBg: '#ffffff',
    borderColor: '#e5e7eb',
    danger: '#ef4444',
    animationType: 'none',
    glassEffect: false,
    neonEffect: false
  },

  // Basic Dark Theme
  dark: {
    name: 'dark',
    displayName: '🌙 Dark',
    bg: '#000000',
    text: '#ffffff',
    primary: '#3b82f6',
    secondary: '#374151',
    accent: '#10b981',
    cardBg: '#1f2937',
    borderColor: '#4b5563',
    danger: '#ef4444',
    animationType: 'none',
    glassEffect: false,
    neonEffect: false
  },

  // 🌌 Cosmic Dreams - Deep space with nebula effects
  cosmic: {
    name: 'cosmic',
    displayName: '🌌 Cosmic Dreams',
    bg: '#000814',
    text: '#ffffff',
    primary: '#7209b7',
    secondary: '#1a1a2e',
    accent: '#f72585',
    cardBg: 'rgba(114, 9, 183, 0.1)',
    borderColor: 'rgba(247, 37, 133, 0.3)',
    danger: '#ff0040',
    gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    particleColor: '#f72585',
    glowColor: '#7209b7',
    animationType: 'cosmic',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'radial-gradient(ellipse at top, #1a1a2e 0%, #000814 50%, #000000 100%)',
    shadowColor: 'rgba(114, 9, 183, 0.5)'
  },

  // 🌊 Aurora Borealis - Northern lights effect
  aurora: {
    name: 'aurora',
    displayName: '🌊 Aurora Borealis',
    bg: '#001122',
    text: '#e0f7fa',
    primary: '#00ff88',
    secondary: '#003366',
    accent: '#00ffff',
    cardBg: 'rgba(0, 255, 136, 0.08)',
    borderColor: 'rgba(0, 255, 255, 0.4)',
    danger: '#ff4444',
    gradient: 'linear-gradient(45deg, #00ff88, #00ffff, #0088ff)',
    particleColor: '#00ffff',
    glowColor: '#00ff88',
    animationType: 'aurora',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'linear-gradient(180deg, #001122 0%, #002244 50%, #001133 100%)',
    shadowColor: 'rgba(0, 255, 136, 0.4)'
  },

  // 🔥 Phoenix Fire - Mystical flames
  phoenix: {
    name: 'phoenix',
    displayName: '🔥 Phoenix Fire',
    bg: '#1a0000',
    text: '#fff5e6',
    primary: '#ff6b35',
    secondary: '#4a0e0e',
    accent: '#ffd700',
    cardBg: 'rgba(255, 107, 53, 0.12)',
    borderColor: 'rgba(255, 215, 0, 0.4)',
    danger: '#ff0000',
    gradient: 'linear-gradient(135deg, #ff6b35 0%, #f7931e 50%, #ffd700 100%)',
    particleColor: '#ffd700',
    glowColor: '#ff6b35',
    animationType: 'pulse',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'radial-gradient(circle at center, #2a0a0a 0%, #1a0000 60%, #0a0000 100%)',
    shadowColor: 'rgba(255, 107, 53, 0.6)'
  },

  // 🌸 Cherry Blossom - Ethereal Japanese aesthetic
  sakura: {
    name: 'sakura',
    displayName: '🌸 Cherry Blossom',
    bg: '#2d1b3d',
    text: '#ffe0ec',
    primary: '#ff69b4',
    secondary: '#4a2c4a',
    accent: '#ffb6c1',
    cardBg: 'rgba(255, 105, 180, 0.1)',
    borderColor: 'rgba(255, 182, 193, 0.3)',
    danger: '#ff1493',
    gradient: 'linear-gradient(135deg, #ff69b4 0%, #ffb6c1 50%, #ffc0cb 100%)',
    particleColor: '#ffb6c1',
    glowColor: '#ff69b4',
    animationType: 'wave',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'linear-gradient(180deg, #2d1b3d 0%, #3d2b4d 50%, #2d1b3d 100%)',
    shadowColor: 'rgba(255, 105, 180, 0.4)'
  },

  // 🚀 Neon Cyberpunk - Futuristic city vibes
  neon: {
    name: 'neon',
    displayName: '🚀 Neon Cyberpunk',
    bg: '#0a0a0f',
    text: '#00ff88',
    primary: '#ff00ff',
    secondary: '#1a0033',
    accent: '#00ffff',
    cardBg: 'rgba(255, 0, 255, 0.08)',
    borderColor: 'rgba(0, 255, 255, 0.5)',
    danger: '#ff0080',
    gradient: 'linear-gradient(45deg, #ff00ff, #00ffff, #ff0088)',
    particleColor: '#00ffff',
    glowColor: '#ff00ff',
    animationType: 'pulse',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'linear-gradient(135deg, #0a0a0f 0%, #1a0033 50%, #0f0a1a 100%)',
    shadowColor: 'rgba(255, 0, 255, 0.6)'
  },

  // 🌿 Emerald Forest - Mystical nature
  emerald: {
    name: 'emerald',
    displayName: '🌿 Emerald Forest',
    bg: '#0d2818',
    text: '#a7f3d0',
    primary: '#10b981',
    secondary: '#14532d',
    accent: '#34d399',
    cardBg: 'rgba(16, 185, 129, 0.12)',
    borderColor: 'rgba(52, 211, 153, 0.3)',
    danger: '#dc2626',
    gradient: 'linear-gradient(135deg, #10b981 0%, #34d399 50%, #6ee7b7 100%)',
    particleColor: '#34d399',
    glowColor: '#10b981',
    animationType: 'none',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'radial-gradient(ellipse at top, #14532d 0%, #0d2818 60%, #061410 100%)',
    shadowColor: 'rgba(16, 185, 129, 0.5)'
  },

  // 🌙 Midnight Galaxy - Deep space elegance
  midnight: {
    name: 'midnight',
    displayName: '🌙 Midnight Galaxy',
    bg: '#000000',
    text: '#e0e7ff',
    primary: '#6366f1',
    secondary: '#1e1b4b',
    accent: '#818cf8',
    cardBg: 'rgba(99, 102, 241, 0.08)',
    borderColor: 'rgba(129, 140, 248, 0.3)',
    danger: '#8b5cf6',
    gradient: 'linear-gradient(135deg, #6366f1 0%, #818cf8 50%, #a5b4fc 100%)',
    particleColor: '#818cf8',
    glowColor: '#6366f1',
    animationType: 'none',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'radial-gradient(circle at center, #1e1b4b 0%, #000000 70%, #000000 100%)',
    shadowColor: 'rgba(99, 102, 241, 0.5)'
  },

  // 🏖️ Tropical Paradise - Vibrant island vibes
  tropical: {
    name: 'tropical',
    displayName: '🏖️ Tropical Paradise',
    bg: '#006400',
    text: '#fff5e6',
    primary: '#ff6b6b',
    secondary: '#2d5016',
    accent: '#ffd93d',
    cardBg: 'rgba(255, 107, 107, 0.12)',
    borderColor: 'rgba(255, 217, 61, 0.4)',
    danger: '#ff4444',
    gradient: 'linear-gradient(135deg, #ff6b6b 0%, #ffd93d 50%, #6bcf7f 100%)',
    particleColor: '#ffd93d',
    glowColor: '#ff6b6b',
    animationType: 'none',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'linear-gradient(180deg, #006400 0%, #2d5016 50%, #1a3009 100%)',
    shadowColor: 'rgba(255, 107, 107, 0.5)'
  },

  // ❄️ Arctic Ice - Cool crystalline beauty
  arctic: {
    name: 'arctic',
    displayName: '❄️ Arctic Ice',
    bg: '#0f172a',
    text: '#f0f9ff',
    primary: '#0ea5e9',
    secondary: '#1e293b',
    accent: '#38bdf8',
    cardBg: 'rgba(14, 165, 233, 0.1)',
    borderColor: 'rgba(56, 189, 248, 0.3)',
    danger: '#0284c7',
    gradient: 'linear-gradient(135deg, #0ea5e9 0%, #38bdf8 50%, #7dd3fc 100%)',
    particleColor: '#38bdf8',
    glowColor: '#0ea5e9',
    animationType: 'none',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'radial-gradient(ellipse at top, #1e293b 0%, #0f172a 60%, #020617 100%)',
    shadowColor: 'rgba(14, 165, 233, 0.4)'
  },

  // 🎆 Royal Velvet - Luxurious purple elegance
  royal: {
    name: 'royal',
    displayName: '🎆 Royal Velvet',
    bg: '#2e1065',
    text: '#f3e8ff',
    primary: '#9333ea',
    secondary: '#4c1d95',
    accent: '#a855f7',
    cardBg: 'rgba(147, 51, 234, 0.12)',
    borderColor: 'rgba(168, 85, 247, 0.3)',
    danger: '#c026d3',
    gradient: 'linear-gradient(135deg, #9333ea 0%, #a855f7 50%, #c084fc 100%)',
    particleColor: '#a855f7',
    glowColor: '#9333ea',
    animationType: 'none',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'radial-gradient(circle at center, #4c1d95 0%, #2e1065 60%, #1e0a3a 100%)',
    shadowColor: 'rgba(147, 51, 234, 0.5)'
  },

  // 🌅 Golden Hour - Warm sunset vibes
  golden: {
    name: 'golden',
    displayName: '🌅 Golden Hour',
    bg: '#2d1810',
    text: '#fef3c7',
    primary: '#f59e0b',
    secondary: '#451a03',
    accent: '#fbbf24',
    cardBg: 'rgba(245, 158, 11, 0.12)',
    borderColor: 'rgba(251, 191, 36, 0.3)',
    danger: '#dc2626',
    gradient: 'linear-gradient(135deg, #f59e0b 0%, #fbbf24 50%, #fcd34d 100%)',
    particleColor: '#fbbf24',
    glowColor: '#f59e0b',
    animationType: 'none',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'radial-gradient(ellipse at top, #451a03 0%, #2d1810 60%, #1a0e05 100%)',
    shadowColor: 'rgba(245, 158, 11, 0.6)'
  },

  // 🌺 Tropical Paradise - Vibrant island dreams
  paradise: {
    name: 'paradise',
    displayName: '🌺 Tropical Paradise',
    bg: '#064e3b',
    text: '#ecfdf5',
    primary: '#10b981',
    secondary: '#022c22',
    accent: '#34d399',
    cardBg: 'rgba(16, 185, 129, 0.1)',
    borderColor: 'rgba(52, 211, 153, 0.3)',
    danger: '#059669',
    gradient: 'linear-gradient(135deg, #10b981 0%, #34d399 50%, #6ee7b7 100%)',
    particleColor: '#34d399',
    glowColor: '#10b981',
    animationType: 'none',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'linear-gradient(180deg, #064e3b 0%, #022c22 50%, #065f46 100%)',
    shadowColor: 'rgba(16, 185, 129, 0.5)'
  },

  // 🎯 Cyber Matrix - Digital rain effect
  matrix: {
    name: 'matrix',
    displayName: '🎯 Cyber Matrix',
    bg: '#000000',
    text: '#00ff41',
    primary: '#00ff41',
    secondary: '#003300',
    accent: '#00cc33',
    cardBg: 'rgba(0, 255, 65, 0.08)',
    borderColor: 'rgba(0, 255, 65, 0.4)',
    danger: '#ff0000',
    gradient: 'linear-gradient(45deg, #00ff41, #00cc33, #00ff41)',
    particleColor: '#00ff41',
    glowColor: '#00ff41',
    animationType: 'none',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'radial-gradient(circle at center, #001100 0%, #000000 70%, #000000 100%)',
    shadowColor: 'rgba(0, 255, 65, 0.6)'
  },

  // 🏔️ Arctic Aurora - Northern lights majesty
  arctic2: {
    name: 'arctic2',
    displayName: '🏔️ Arctic Aurora',
    bg: '#0c1445',
    text: '#e0f2fe',
    primary: '#0ea5e9',
    secondary: '#1e3a8a',
    accent: '#38bdf8',
    cardBg: 'rgba(14, 165, 233, 0.1)',
    borderColor: 'rgba(56, 189, 248, 0.3)',
    danger: '#0369a1',
    gradient: 'linear-gradient(135deg, #0ea5e9 0%, #38bdf8 25%, #7dd3fc 50%, #38bdf8 75%, #0ea5e9 100%)',
    particleColor: '#38bdf8',
    glowColor: '#0ea5e9',
    animationType: 'none',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'linear-gradient(180deg, #0c1445 0%, #1e3a8a 50%, #172554 100%)',
    shadowColor: 'rgba(14, 165, 233, 0.5)'
  },

  // 🌸 Cherry Blossom - Japanese zen garden
  blossom: {
    name: 'blossom',
    displayName: '🌸 Cherry Blossom',
    bg: '#4a044e',
    text: '#fce7f3',
    primary: '#ec4899',
    secondary: '#701a75',
    accent: '#f9a8d4',
    cardBg: 'rgba(236, 72, 153, 0.1)',
    borderColor: 'rgba(249, 168, 212, 0.3)',
    danger: '#be185d',
    gradient: 'linear-gradient(135deg, #ec4899 0%, #f9a8d4 50%, #fbcfe8 100%)',
    particleColor: '#f9a8d4',
    glowColor: '#ec4899',
    animationType: 'none',
    glassEffect: true,
    neonEffect: false,
    gradientBg: 'radial-gradient(ellipse at top, #701a75 0%, #4a044e 60%, #2e1065 100%)',
    shadowColor: 'rgba(236, 72, 153, 0.5)'
  },

  // 🌊 Ocean Depths - Deep sea mystery
  ocean: {
    name: 'ocean',
    displayName: '🌊 Ocean Depths',
    bg: '#0c4a6e',
    text: '#e0f2fe',
    primary: '#0284c7',
    secondary: '#075985',
    accent: '#0ea5e9',
    cardBg: 'rgba(2, 132, 199, 0.1)',
    borderColor: 'rgba(14, 165, 233, 0.3)',
    danger: '#075985',
    gradient: 'linear-gradient(135deg, #0284c7 0%, #0ea5e9 50%, #38bdf8 100%)',
    particleColor: '#0ea5e9',
    glowColor: '#0284c7',
    animationType: 'none',
    glassEffect: true,
    neonEffect: true,
    gradientBg: 'radial-gradient(ellipse at center, #075985 0%, #0c4a6e 60%, #0c2d48 100%)',
    shadowColor: 'rgba(2, 132, 199, 0.6)'
  }
}

interface ThemeContextType {
  theme: Theme
  themeName: string
  setTheme: (themeName: string) => void
  themes: Record<string, Theme>
  customTheme: Theme | null
  setCustomTheme: (theme: Theme) => void
  isTransitioning: boolean
  // Theme customizer functions
  updateThemeColor: (property: keyof Theme, color: string) => void
  resetThemeColors: () => void
  exportTheme: () => string
  importTheme: (themeJson: string) => boolean
  createCustomTheme: (baseTheme: string, name: string) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [themeName, setThemeName] = useState('cosmic')
  const [customTheme, setCustomTheme] = useState<Theme | null>(null)
  const [isTransitioning, setIsTransitioning] = useState(false)

  // Load theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('vibetracker-theme')
    if (savedTheme && visualMasterpieceThemes[savedTheme]) {
      setThemeName(savedTheme)
    }
  }, [])

  // Save theme to localStorage
  useEffect(() => {
    localStorage.setItem('vibetracker-theme', themeName)
  }, [themeName])

  // Apply theme CSS variables instantly - no transitions
  useEffect(() => {
    const theme = customTheme || visualMasterpieceThemes[themeName]
    const root = document.documentElement
    
    // Core theme colors
    root.style.setProperty('--theme-bg', theme.bg)
    root.style.setProperty('--theme-text', theme.text)
    root.style.setProperty('--theme-primary', theme.primary)
    root.style.setProperty('--theme-secondary', theme.secondary)
    root.style.setProperty('--theme-accent', theme.accent)
    root.style.setProperty('--theme-card-bg', theme.cardBg)
    root.style.setProperty('--theme-border-color', theme.borderColor)
    
    // Enhanced visual properties
    if (theme.gradient) {
      root.style.setProperty('--theme-gradient', theme.gradient)
    }
    if (theme.particleColor) {
      root.style.setProperty('--theme-particle-color', theme.particleColor)
    }
    if (theme.glowColor) {
      root.style.setProperty('--theme-glow-color', theme.glowColor)
    }
    if (theme.gradientBg) {
      root.style.setProperty('--theme-gradient-bg', theme.gradientBg)
    }
    if (theme.shadowColor) {
      root.style.setProperty('--theme-shadow-color', theme.shadowColor)
    }

    // Animation classes
    root.setAttribute('data-animation', theme.animationType || 'none')
    root.setAttribute('data-glass-effect', theme.glassEffect ? 'true' : 'false')
    root.setAttribute('data-neon-effect', theme.neonEffect ? 'true' : 'false')
    root.setAttribute('data-theme-name', theme.name)
  }, [themeName, customTheme])

  const handleThemeChange = (newThemeName: string) => {
    // Instant theme change - no delays or transitions
    setThemeName(newThemeName)
  }

  // Theme customizer functions
  const updateThemeColor = (property: keyof Theme, color: string) => {
    const currentTheme = customTheme || visualMasterpieceThemes[themeName]
    const updatedTheme = { ...currentTheme, [property]: color }
    setCustomTheme(updatedTheme)
  }

  const resetThemeColors = () => {
    setCustomTheme(null)
  }

  const exportTheme = () => {
    const currentTheme = customTheme || visualMasterpieceThemes[themeName]
    return JSON.stringify(currentTheme, null, 2)
  }

  const importTheme = (themeJson: string) => {
    try {
      const importedTheme = JSON.parse(themeJson)
      if (importedTheme.name && importedTheme.bg && importedTheme.text) {
        setCustomTheme(importedTheme)
        return true
      }
      return false
    } catch (error) {
      console.error('Failed to import theme:', error)
      return false
    }
  }

  const createCustomTheme = (baseTheme: string, name: string) => {
    const base = visualMasterpieceThemes[baseTheme]
    if (base) {
      const newTheme = { ...base, name, displayName: `🎨 ${name}` }
      setCustomTheme(newTheme)
    }
  }

  const value: ThemeContextType = {
    theme: customTheme || visualMasterpieceThemes[themeName],
    themeName,
    setTheme: handleThemeChange,
    themes: visualMasterpieceThemes,
    customTheme,
    setCustomTheme,
    isTransitioning,
    updateThemeColor,
    resetThemeColors,
    exportTheme,
    importTheme,
    createCustomTheme
  }

  return (
    <ThemeContext.Provider value={value}>
      <div className={`theme-transition ${isTransitioning ? 'transitioning' : ''}`}>
        {children}
      </div>
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}