'use client'

import { useState, useEffect, useCallback } from 'react'
import { useData } from '@/contexts/DataContext'
import { useSettings } from '@/contexts/SettingsContext'
import { loginWithEmail, logoutUser, onAuthChange, syncUserData, getUserData } from '@/lib/firebase'

interface CloudSyncState {
  isOnline: boolean
  isSyncing: boolean
  lastSync: Date | null
  error: string | null
  user: any | null
}

export function useCloudSync() {
  const { exportData, importData } = useData()
  const { userName, profilePicture } = useSettings()
  
  const [cloudState, setCloudState] = useState<CloudSyncState>({
    isOnline: false,
    isSyncing: false,
    lastSync: null,
    error: null,
    user: null
  })

  // Initialize auth state listener
  useEffect(() => {
    const unsubscribe = onAuthChange((user) => {
      setCloudState(prev => ({
        ...prev,
        user,
        isOnline: !!user,
        error: null
      }))

      if (user) {
        // Load user data from cloud when they log in
        loadUserData(user.uid)
      }
    })

    return unsubscribe
  }, [])

  // Load user data from cloud
  const loadUserData = useCallback(async (userId: string) => {
    try {
      setCloudState(prev => ({ ...prev, isSyncing: true, error: null }))
      
      const cloudData = await getUserData(userId)
      if (cloudData) {
        // Import cloud data if it exists
        importData(cloudData)
        console.log('Data loaded from cloud successfully')
      }
      
      setCloudState(prev => ({ 
        ...prev, 
        isSyncing: false,
        lastSync: new Date()
      }))
    } catch (error: any) {
      setCloudState(prev => ({ 
        ...prev, 
        isSyncing: false,
        error: error.message
      }))
    }
  }, [importData])

  // Sync current data to cloud
  const syncToCloud = useCallback(async () => {
    if (!cloudState.user) {
      throw new Error('Not authenticated')
    }

    try {
      setCloudState(prev => ({ ...prev, isSyncing: true, error: null }))
      
      // Get current app data
      const currentData = exportData()
      
      // Add user profile info
      const dataToSync = {
        ...currentData,
        userProfile: {
          userName,
          profilePicture
        }
      }
      
      // Sync to Firebase
      await syncUserData(cloudState.user.uid, dataToSync)
      
      setCloudState(prev => ({ 
        ...prev, 
        isSyncing: false,
        lastSync: new Date(),
        error: null
      }))
      
      return { success: true, message: 'Data synced successfully' }
    } catch (error: any) {
      setCloudState(prev => ({ 
        ...prev, 
        isSyncing: false,
        error: error.message
      }))
      throw error
    }
  }, [cloudState.user, exportData, userName, profilePicture])

  // Login with email and password
  const login = useCallback(async (email: string, password: string) => {
    try {
      setCloudState(prev => ({ ...prev, isSyncing: true, error: null }))
      
      const user = await loginWithEmail(email, password)
      
      setCloudState(prev => ({ 
        ...prev, 
        user,
        isOnline: true,
        isSyncing: false,
        error: null
      }))
      
      return { success: true, user }
    } catch (error: any) {
      setCloudState(prev => ({ 
        ...prev, 
        isSyncing: false,
        error: error.message
      }))
      throw error
    }
  }, [])

  // Logout
  const logout = useCallback(async () => {
    try {
      await logoutUser()
      
      setCloudState({
        isOnline: false,
        isSyncing: false,
        lastSync: null,
        error: null,
        user: null
      })
      
      return { success: true }
    } catch (error: any) {
      setCloudState(prev => ({ 
        ...prev, 
        error: error.message
      }))
      throw error
    }
  }, [])

  // Auto-sync when data changes (if authenticated)
  useEffect(() => {
    if (cloudState.user && !cloudState.isSyncing) {
      const timer = setTimeout(() => {
        syncToCloud().catch(console.error)
      }, 2000) // Wait 2 seconds after data change before syncing

      return () => clearTimeout(timer)
    }
  }, [userName, profilePicture, cloudState.user, cloudState.isSyncing, syncToCloud])

  return {
    ...cloudState,
    login,
    logout,
    syncToCloud,
    loadUserData
  }
}