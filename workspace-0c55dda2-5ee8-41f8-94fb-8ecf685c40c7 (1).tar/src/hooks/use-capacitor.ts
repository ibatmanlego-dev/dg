'use client'

import { useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { 
  Camera, 
  CameraResultType, 
  CameraSource,
  Photo 
} from '@capacitor/camera'
import { 
  LocalNotifications,
  PermissionStatus
} from '@capacitor/local-notifications'
import { Haptics, ImpactStyle } from '@capacitor/haptics'
import { StatusBar, Style } from '@capacitor/status-bar'
import { SplashScreen } from '@capacitor/splash-screen'
import { Filesystem, Directory } from '@capacitor/filesystem'
import { Preferences } from '@capacitor/preferences'

export interface UseCapacitorReturn {
  isNative: boolean
  isPlatform: (platform: 'ios' | 'android' | 'web') => boolean
  
  // Camera
  takePhoto: () => Promise<Photo | null>
  pickPhoto: () => Promise<Photo | null>
  
  // Notifications
  requestNotificationPermission: () => Promise<PermissionStatus>
  scheduleNotification: (title: string, body: string, id?: number) => Promise<void>
  
  // Haptics
  hapticImpact: (style?: ImpactStyle) => Promise<void>
  
  // Status Bar
  setStatusBarStyle: (style: Style) => Promise<void>
  
  // Splash Screen
  hideSplashScreen: () => Promise<void>
  showSplashScreen: () => Promise<void>
  
  // File System
  saveFile: (data: string, filename: string) => Promise<string>
  readFile: (filename: string) => Promise<string>
  
  // Preferences
  setPreference: (key: string, value: string) => Promise<void>
  getPreference: (key: string) => Promise<string | null>
  removePreference: (key: string) => Promise<void>
}

export function useCapacitor(): UseCapacitorReturn {
  const [mounted, setMounted] = useState(false)
  
  useEffect(() => {
    setMounted(true)
  }, [])
  
  const isNative = mounted ? Capacitor.isNativePlatform() : false
  
  const isPlatform = (platform: 'ios' | 'android' | 'web'): boolean => {
    if (!mounted) return false
    return Capacitor.getPlatform() === platform
  }

  // Camera functions
  const takePhoto = async (): Promise<Photo | null> => {
    if (!isNative) return null
    
    try {
      const photo = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Uri,
        source: CameraSource.Camera,
      })
      return photo
    } catch (error) {
      console.error('Error taking photo:', error)
      return null
    }
  }

  const pickPhoto = async (): Promise<Photo | null> => {
    if (!isNative) return null
    
    try {
      const photo = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Uri,
        source: CameraSource.Photos,
      })
      return photo
    } catch (error) {
      console.error('Error picking photo:', error)
      return null
    }
  }

  // Notification functions
  const requestNotificationPermission = async (): Promise<PermissionStatus> => {
    if (!isNative) {
      return { display: 'prompt' as const }
    }
    
    try {
      const permission = await LocalNotifications.requestPermissions()
      return permission
    } catch (error) {
      console.error('Error requesting notification permission:', error)
      return { display: 'denied' as const }
    }
  }

  const scheduleNotification = async (title: string, body: string, id: number = Date.now()): Promise<void> => {
    if (!isNative) return
    
    try {
      await LocalNotifications.schedule({
        notifications: [
          {
            id,
            title,
            body,
            schedule: { at: new Date(Date.now() + 1000) },
            sound: 'default',
            smallIcon: 'ic_stat_icon_config_sample',
            largeIcon: 'ic_launcher',
          },
        ],
      })
    } catch (error) {
      console.error('Error scheduling notification:', error)
    }
  }

  // Haptic functions
  const hapticImpact = async (style: ImpactStyle = ImpactStyle.Medium): Promise<void> => {
    if (!isNative) return
    
    try {
      await Haptics.impact({ style })
    } catch (error) {
      console.error('Error playing haptic:', error)
    }
  }

  // Status Bar functions
  const setStatusBarStyle = async (style: Style): Promise<void> => {
    if (!isNative) return
    
    try {
      await StatusBar.setStyle({ style })
    } catch (error) {
      console.error('Error setting status bar style:', error)
    }
  }

  // Splash Screen functions
  const hideSplashScreen = async (): Promise<void> => {
    if (!isNative) return
    
    try {
      await SplashScreen.hide()
    } catch (error) {
      console.error('Error hiding splash screen:', error)
    }
  }

  const showSplashScreen = async (): Promise<void> => {
    if (!isNative) return
    
    try {
      await SplashScreen.show()
    } catch (error) {
      console.error('Error showing splash screen:', error)
    }
  }

  // File System functions
  const saveFile = async (data: string, filename: string): Promise<string> => {
    if (!isNative) return ''
    
    try {
      const result = await Filesystem.writeFile({
        path: filename,
        data,
        directory: Directory.Documents,
      })
      return result.uri
    } catch (error) {
      console.error('Error saving file:', error)
      return ''
    }
  }

  const readFile = async (filename: string): Promise<string> => {
    if (!isNative) return ''
    
    try {
      const result = await Filesystem.readFile({
        path: filename,
        directory: Directory.Documents,
      })
      return result.data as string
    } catch (error) {
      console.error('Error reading file:', error)
      return ''
    }
  }

  // Preferences functions
  const setPreference = async (key: string, value: string): Promise<void> => {
    try {
      await Preferences.set({ key, value })
    } catch (error) {
      console.error('Error setting preference:', error)
    }
  }

  const getPreference = async (key: string): Promise<string | null> => {
    try {
      const { value } = await Preferences.get({ key })
      return value
    } catch (error) {
      console.error('Error getting preference:', error)
      return null
    }
  }

  const removePreference = async (key: string): Promise<void> => {
    try {
      await Preferences.remove({ key })
    } catch (error) {
      console.error('Error removing preference:', error)
    }
  }

  return {
    isNative,
    isPlatform,
    takePhoto,
    pickPhoto,
    requestNotificationPermission,
    scheduleNotification,
    hapticImpact,
    setStatusBarStyle,
    hideSplashScreen,
    showSplashScreen,
    saveFile,
    readFile,
    setPreference,
    getPreference,
    removePreference,
  }
}