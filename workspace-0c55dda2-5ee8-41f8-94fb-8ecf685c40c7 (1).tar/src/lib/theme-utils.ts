/**
 * Theme-aware utilities for automatic text color contrast
 */

// Helper function to determine if a color is light or dark
export function getContrastColor(backgroundColor: string): string {
  // Handle different color formats
  let hex = backgroundColor
  
  // Remove # if present
  if (hex.startsWith('#')) {
    hex = hex.slice(1)
  }
  
  // Handle rgba() format
  if (hex.startsWith('rgba')) {
    // Extract RGB values from rgba(r, g, b, a)
    const matches = hex.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/)
    if (matches) {
      const r = parseInt(matches[1])
      const g = parseInt(matches[2]) 
      const b = parseInt(matches[3])
      const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
      return luminance > 0.5 ? '#000000' : '#ffffff'
    }
    // Fallback for rgba
    return '#ffffff'
  }
  
  // Handle rgb() format
  if (hex.startsWith('rgb')) {
    const matches = hex.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/)
    if (matches) {
      const r = parseInt(matches[1])
      const g = parseInt(matches[2])
      const b = parseInt(matches[3])
      const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
      return luminance > 0.5 ? '#000000' : '#ffffff'
    }
    // Fallback for rgb
    return '#ffffff'
  }
  
  // If hex is not 6 characters, try to handle common cases
  if (hex.length !== 6) {
    // Handle 3-digit hex
    if (hex.length === 3) {
      hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2]
    } else {
      // Fallback for unknown formats - assume dark background
      return '#ffffff'
    }
  }
  
  // Convert to RGB
  const r = parseInt(hex.substr(0, 2), 16)
  const g = parseInt(hex.substr(2, 2), 16)
  const b = parseInt(hex.substr(4, 2), 16)
  
  // Check if conversion failed
  if (isNaN(r) || isNaN(g) || isNaN(b)) {
    return '#ffffff'
  }
  
  // Calculate luminance
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
  
  // Return black for light backgrounds, white for dark backgrounds
  return luminance > 0.5 ? '#000000' : '#ffffff'
}

// Helper function to get the best text color for outline buttons
export function getOutlineTextColor(theme: any): string {
  // For outline buttons, use the theme's text color but ensure contrast
  const themeText = theme.text || '#ffffff'
  const cardBg = theme.cardBg || '#ffffff'
  
  // If card background is light, use dark text
  if (cardBg === '#ffffff' || cardBg.includes('ff') && cardBg.includes('ff') && cardBg.includes('ff')) {
    return '#000000'
  }
  
  // Otherwise use theme text
  return themeText
}

// Helper function to get the best text color for secondary buttons
export function getSecondaryTextColor(theme: any): string {
  const secondary = theme.secondary || '#f3f4f6'
  return getContrastColor(secondary)
}

// Helper function to get theme-aware button styles
export function getThemeAwareButtonStyles(theme: any, variant: 'default' | 'outline' | 'secondary' | 'ghost' | 'destructive') {
  switch (variant) {
    case 'outline':
      return {
        backgroundColor: theme.cardBg || 'transparent',
        borderColor: theme.borderColor || '#e5e7eb',
        color: getOutlineTextColor(theme),
        '--tw-text-opacity': '1'
      }
    case 'secondary':
      return {
        backgroundColor: theme.secondary || '#f3f4f6',
        color: getSecondaryTextColor(theme),
        '--tw-text-opacity': '1'
      }
    case 'ghost':
      return {
        color: theme.text || '#ffffff',
        '--tw-text-opacity': '1'
      }
    default:
      return {
        backgroundColor: theme.primary || '#3b82f6',
        color: '#ffffff',
        '--tw-text-opacity': '1'
      }
  }
}