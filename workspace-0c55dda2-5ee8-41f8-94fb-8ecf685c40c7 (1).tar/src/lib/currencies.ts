export interface Currency {
  code: string
  symbol: string
  country: string
}

export const currencies: Currency[] = [
  // North America
  { code: 'USD', symbol: '$', country: 'United States' },
  { code: 'CAD', symbol: 'C$', country: 'Canada' },
  { code: 'MXN', symbol: '$', country: 'Mexico' },
  
  // South America
  { code: 'BRL', symbol: 'R$', country: 'Brazil' },
  { code: 'ARS', symbol: '$', country: 'Argentina' },
  { code: 'CLP', symbol: '$', country: 'Chile' },
  { code: 'COP', symbol: '$', country: 'Colombia' },
  { code: 'PEN', symbol: 'S/', country: 'Peru' },
  { code: 'UYU', symbol: '$', country: 'Uruguay' },
  { code: 'VEF', symbol: 'Bs', country: 'Venezuela' },
  { code: 'BOB', symbol: 'Bs', country: 'Bolivia' },
  { code: 'PYG', symbol: '₲', country: 'Paraguay' },
  { code: 'GYD', symbol: '$', country: 'Guyana' },
  { code: 'SRD', symbol: '$', country: 'Suriname' },
  { code: 'ECU', symbol: '$', country: 'Ecuador' },
  
  // Europe
  { code: 'EUR', symbol: '€', country: 'European Union' },
  { code: 'GBP', symbol: '£', country: 'United Kingdom' },
  { code: 'CHF', symbol: 'CHF', country: 'Switzerland' },
  { code: 'NOK', symbol: 'kr', country: 'Norway' },
  { code: 'SEK', symbol: 'kr', country: 'Sweden' },
  { code: 'DKK', symbol: 'kr', country: 'Denmark' },
  { code: 'PLN', symbol: 'zł', country: 'Poland' },
  { code: 'CZK', symbol: 'Kč', country: 'Czech Republic' },
  { code: 'HUF', symbol: 'Ft', country: 'Hungary' },
  { code: 'RON', symbol: 'lei', country: 'Romania' },
  { code: 'BGN', symbol: 'лв', country: 'Bulgaria' },
  { code: 'HRK', symbol: 'kn', country: 'Croatia' },
  { code: 'RUB', symbol: '₽', country: 'Russia' },
  { code: 'UAH', symbol: '₴', country: 'Ukraine' },
  { code: 'RSD', symbol: 'дин', country: 'Serbia' },
  { code: 'ISK', symbol: 'kr', country: 'Iceland' },
  { code: 'BYN', symbol: 'Br', country: 'Belarus' },
  { code: 'ALL', symbol: 'L', country: 'Albania' },
  { code: 'MKD', symbol: 'ден', country: 'North Macedonia' },
  { code: 'MDL', symbol: 'L', country: 'Moldova' },
  { code: 'BAM', symbol: 'KM', country: 'Bosnia and Herzegovina' },
  
  // Africa
  { code: 'ZAR', symbol: 'R', country: 'South Africa' },
  { code: 'NGN', symbol: '₦', country: 'Nigeria' },
  { code: 'EGP', symbol: '£', country: 'Egypt' },
  { code: 'KES', symbol: 'KSh', country: 'Kenya' },
  { code: 'GHS', symbol: '₵', country: 'Ghana' },
  { code: 'MAD', symbol: 'د.م.', country: 'Morocco' },
  { code: 'TND', symbol: 'د.ت', country: 'Tunisia' },
  { code: 'DZD', symbol: 'د.ج', country: 'Algeria' },
  { code: 'UGX', symbol: 'USh', country: 'Uganda' },
  { code: 'TZS', symbol: 'TSh', country: 'Tanzania' },
  { code: 'XOF', symbol: 'CFA', country: 'West African CFA' },
  { code: 'XAF', symbol: 'FCFA', country: 'Central African CFA' },
  { code: 'ETB', symbol: 'ብር', country: 'Ethiopia' },
  { code: 'MUR', symbol: '₨', country: 'Mauritius' },
  { code: 'BWP', symbol: 'P', country: 'Botswana' },
  { code: 'NAD', symbol: '$', country: 'Namibia' },
  { code: 'ZMW', symbol: 'ZK', country: 'Zambia' },
  { code: 'MWK', symbol: 'MK', country: 'Malawi' },
  
  // Middle East / GCC
  { code: 'SAR', symbol: '﷼', country: 'Saudi Arabia' },
  { code: 'AED', symbol: 'د.إ', country: 'United Arab Emirates' },
  { code: 'KWD', symbol: 'د.ك', country: 'Kuwait' },
  { code: 'BHD', symbol: 'د.ب', country: 'Bahrain' },
  { code: 'QAR', symbol: 'ر.ق', country: 'Qatar' },
  { code: 'OMR', symbol: 'ر.ع.', country: 'Oman' },
  { code: 'JOD', symbol: 'د.ا', country: 'Jordan' },
  { code: 'LBP', symbol: 'ل.ل', country: 'Lebanon' },
  { code: 'ILS', symbol: '₪', country: 'Israel' },
  { code: 'IQD', symbol: 'د.ع', country: 'Iraq' },
  { code: 'YER', symbol: 'ر.ي', country: 'Yemen' },
  { code: 'IRR', symbol: '﷼', country: 'Iran' },
  { code: 'AFN', symbol: '؋', country: 'Afghanistan' },
  
  // Asia
  { code: 'CNY', symbol: '¥', country: 'China' },
  { code: 'JPY', symbol: '¥', country: 'Japan' },
  { code: 'INR', symbol: '₹', country: 'India' },
  { code: 'KRW', symbol: '₩', country: 'South Korea' },
  { code: 'HKD', symbol: '$', country: 'Hong Kong' },
  { code: 'SGD', symbol: '$', country: 'Singapore' },
  { code: 'THB', symbol: '฿', country: 'Thailand' },
  { code: 'MYR', symbol: 'RM', country: 'Malaysia' },
  { code: 'IDR', symbol: 'Rp', country: 'Indonesia' },
  { code: 'PHP', symbol: '₱', country: 'Philippines' },
  { code: 'VND', symbol: '₫', country: 'Vietnam' },
  { code: 'PKR', symbol: '₨', country: 'Pakistan' },
  { code: 'BDT', symbol: '৳', country: 'Bangladesh' },
  { code: 'LKR', symbol: 'රු', country: 'Sri Lanka' },
  { code: 'NPR', symbol: 'रू', country: 'Nepal' },
  { code: 'MMK', symbol: 'K', country: 'Myanmar' },
  { code: 'KHR', symbol: '៛', country: 'Cambodia' },
  { code: 'LAK', symbol: '₭', country: 'Laos' },
  { code: 'MNT', symbol: '₮', country: 'Mongolia' },
  { code: 'KZT', symbol: '₸', country: 'Kazakhstan' },
  { code: 'UZS', symbol: 'сўм', country: 'Uzbekistan' },
  { code: 'KGS', symbol: 'с', country: 'Kyrgyzstan' },
  { code: 'TJS', symbol: 'с', country: 'Tajikistan' },
  { code: 'TMT', symbol: 'm', country: 'Turkmenistan' },
  { code: 'GEL', symbol: 'ლ', country: 'Georgia' },
  { code: 'AMD', symbol: '֏', country: 'Armenia' },
  { code: 'AZN', symbol: '₼', country: 'Azerbaijan' },
  
  // Oceania
  { code: 'AUD', symbol: '$', country: 'Australia' },
  { code: 'NZD', symbol: '$', country: 'New Zealand' },
  { code: 'FJD', symbol: '$', country: 'Fiji' },
  { code: 'PGK', symbol: 'K', country: 'Papua New Guinea' },
  { code: 'VUV', symbol: 'VT', country: 'Vanuatu' },
  { code: 'SBD', symbol: '$', country: 'Solomon Islands' },
  { code: 'WST', symbol: 'T', country: 'Samoa' },
  { code: 'TOP', symbol: 'T$', country: 'Tonga' },
  { code: 'NRS', symbol: '$', country: 'Nauru' },
  { code: 'KIR', symbol: '$', country: 'Kiribati' },
  { code: 'TVU', symbol: '$', country: 'Tuvalu' },
  
  // Caribbean
  { code: 'JMD', symbol: 'J$', country: 'Jamaica' },
  { code: 'TTD', symbol: 'TT$', country: 'Trinidad and Tobago' },
  { code: 'BBD', symbol: 'Bds$', country: 'Barbados' },
  { code: 'BSD', symbol: 'B$', country: 'Bahamas' },
  { code: 'BZD', symbol: 'BZ$', country: 'Belize' },
  { code: 'GTQ', symbol: 'Q', country: 'Guatemala' },
  { code: 'HNL', symbol: 'L', country: 'Honduras' },
  { code: 'NIO', symbol: 'C$', country: 'Nicaragua' },
  { code: 'CRC', symbol: '₡', country: 'Costa Rica' },
  { code: 'PAB', symbol: 'B/', country: 'Panama' },
  { code: 'DOP', symbol: 'RD$', country: 'Dominican Republic' },
  { code: 'HTG', symbol: 'G', country: 'Haiti' },
  { code: 'XCD', symbol: '$', country: 'East Caribbean Dollar' },
  
  // Central America
  { code: 'GTQ', symbol: 'Q', country: 'Guatemala' },
  { code: 'HNL', symbol: 'L', country: 'Honduras' },
  { code: 'SVC', symbol: '$', country: 'El Salvador' },
  { code: 'NIO', symbol: 'C$', country: 'Nicaragua' },
  { code: 'CRC', symbol: '₡', country: 'Costa Rica' },
  { code: 'PAB', symbol: 'B/', country: 'Panama' },
]

export const currenciesByRegion = {
  'North America': currencies.filter(c => 
    ['USD', 'CAD', 'MXN'].includes(c.code)
  ),
  'South America': currencies.filter(c => 
    ['BRL', 'ARS', 'CLP', 'COP', 'PEN', 'UYU', 'VEF', 'BOB', 'PYG', 'GYD', 'SRD', 'ECU'].includes(c.code)
  ),
  'Europe': currencies.filter(c => 
    ['EUR', 'GBP', 'CHF', 'NOK', 'SEK', 'DKK', 'PLN', 'CZK', 'HUF', 'RON', 'BGN', 'HRK', 'RUB', 'UAH', 'RSD', 'ISK', 'BYN', 'ALL', 'MKD', 'MDL', 'BAM'].includes(c.code)
  ),
  'Middle East & GCC': currencies.filter(c => 
    ['SAR', 'AED', 'KWD', 'BHD', 'QAR', 'OMR', 'JOD', 'LBP', 'ILS', 'IQD', 'YER', 'IRR', 'AFN'].includes(c.code)
  ),
  'Asia': currencies.filter(c => 
    ['CNY', 'JPY', 'INR', 'KRW', 'HKD', 'SGD', 'THB', 'MYR', 'IDR', 'PHP', 'VND', 'PKR', 'BDT', 'LKR', 'NPR', 'MMK', 'KHR', 'LAK', 'MNT', 'KZT', 'UZS', 'KGS', 'TJS', 'TMT', 'GEL', 'AMD', 'AZN'].includes(c.code)
  ),
  'Africa': currencies.filter(c => 
    ['ZAR', 'NGN', 'EGP', 'KES', 'GHS', 'MAD', 'TND', 'DZD', 'UGX', 'TZS', 'XOF', 'XAF', 'ETB', 'MUR', 'BWP', 'NAD', 'ZMW', 'MWK'].includes(c.code)
  ),
  'Oceania': currencies.filter(c => 
    ['AUD', 'NZD', 'FJD', 'PGK', 'VUV', 'SBD', 'WST', 'TOP', 'NRS', 'KIR', 'TVU'].includes(c.code)
  ),
  'Caribbean & Central America': currencies.filter(c => 
    ['JMD', 'TTD', 'BBD', 'BSD', 'BZD', 'GTQ', 'HNL', 'NIO', 'CRC', 'PAB', 'DOP', 'HTG', 'XCD', 'SVC'].includes(c.code)
  ),
}