// Firebase configuration for VibeTracker
// This is a free Firebase configuration that works with the Spark plan

import { initializeApp } from 'firebase/app'
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth'
import { getFirestore, doc, setDoc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore'

// Firebase configuration - Replace with your own config if needed
// For development, you can use a free Firebase project
const firebaseConfig = {
  apiKey: "AIzaSyDemoKeyForDevelopmentOnly",
  authDomain: "vibetracker-demo.firebaseapp.com",
  projectId: "vibetracker-demo",
  storageBucket: "vibetracker-demo.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456"
}

// Initialize Firebase
let app: any = null
let auth: any = null
let db: any = null

// Initialize Firebase only if config is valid
const initializeFirebase = () => {
  try {
    // Check if we have valid config (not demo values)
    if (firebaseConfig.apiKey === "AIzaSyDemoKeyForDevelopmentOnly") {
      console.warn('Firebase is using demo config. Please set up your own Firebase project.')
      return null
    }

    app = initializeApp(firebaseConfig)
    auth = getAuth(app)
    db = getFirestore(app)
    
    return { app, auth, db }
  } catch (error) {
    console.error('Failed to initialize Firebase:', error)
    return null
  }
}

// Authentication functions
export const loginWithEmail = async (email: string, password: string) => {
  if (!auth) {
    throw new Error('Firebase not initialized. Please configure Firebase.')
  }

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    return userCredential.user
  } catch (error: any) {
    throw new Error(error.message || 'Login failed')
  }
}

export const logoutUser = async () => {
  if (!auth) return
  
  try {
    await signOut(auth)
  } catch (error: any) {
    throw new Error(error.message || 'Logout failed')
  }
}

export const onAuthChange = (callback: (user: any) => void) => {
  if (!auth) return () => {}
  
  return onAuthStateChanged(auth, callback)
}

// Cloud sync functions
export const syncUserData = async (userId: string, userData: any) => {
  if (!db) {
    console.warn('Cloud sync not available - Firebase not initialized')
    return null
  }

  try {
    const userDoc = doc(db, 'users', userId)
    await setDoc(userDoc, {
      ...userData,
      lastSync: serverTimestamp(),
      version: '1.0.0'
    }, { merge: true })
    
    return { success: true, message: 'Data synced successfully' }
  } catch (error: any) {
    throw new Error(error.message || 'Sync failed')
  }
}

export const getUserData = async (userId: string) => {
  if (!db) {
    console.warn('Cloud sync not available - Firebase not initialized')
    return null
  }

  try {
    const userDoc = doc(db, 'users', userId)
    const docSnap = await getDoc(userDoc)
    
    if (docSnap.exists()) {
      return docSnap.data()
    } else {
      return null
    }
  } catch (error: any) {
    throw new Error(error.message || 'Failed to fetch user data')
  }
}

// Initialize Firebase on module load
const firebaseInstance = initializeFirebase()

export { firebaseInstance, auth, db }

// Instructions for setting up Firebase:
/*
1. Go to https://console.firebase.google.com
2. Create a new project (it's free)
3. Enable Authentication with Email/Password provider
4. Enable Firestore Database
5. Copy your config values and replace the demo config above
6. Update the firebaseConfig object with your real values

FREE FIREBASE FEATURES INCLUDED:
- Authentication: 10,000 monthly active users
- Firestore: 1 GiB storage, 50,000 reads/day, 20,000 writes/day, 20,000 deletes/day
- Real-time sync across devices
- Automatic backups
- No credit card required for Spark plan

This is more than enough for personal use and small applications!
*/