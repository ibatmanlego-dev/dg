import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import "../styles/select-fix.css";
import { Toaster } from "@/components/ui/toaster";
import { DataProvider } from "@/contexts/DataContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { AnimationProvider } from "@/contexts/AnimationContext";
import { SettingsProvider } from "@/contexts/SettingsContext";
import { CapacitorInit } from "@/components/mobile/capacitor-init";
import { CSSParticles } from "@/components/ui/particle-effects";
import { FloatingCalendarButton } from "@/components/calendar/floating-calendar-button";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "VibeTracker - Visual Masterpiece",
  description: "Experience the future of personal tracking with stunning visual themes, particle effects, and mesmerizing animations",
  keywords: ["VibeTracker", "visual masterpiece", "personal tracking", "themes", "animations", "particle effects"],
  authors: [{ name: "VibeTracker Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "VibeTracker - Visual Masterpiece",
    description: "Experience the future of personal tracking with stunning visual themes",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "VibeTracker - Visual Masterpiece",
    description: "Experience the future of personal tracking with stunning visual themes",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="theme-color" content="#6366f1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="VibeTracker" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="VibeTracker" />
        <style>
          {`
            :root {
              --theme-bg: #0a0a0a;
              --theme-text: #ffffff;
              --theme-primary: #6366f1;
              --theme-secondary: #1f2937;
              --theme-accent: #ec4899;
              --theme-card-bg: rgba(255, 255, 255, 0.05);
              --theme-border-color: rgba(255, 255, 255, 0.1);
            }
            
            * {
              -webkit-tap-highlight-color: transparent;
              -webkit-touch-callout: none;
            }
            
            body {
              overscroll-behavior: none;
              -webkit-font-smoothing: antialiased;
              -moz-osx-font-smoothing: grayscale;
              -webkit-overflow-scrolling: touch;
              color: var(--theme-text);
              background-color: var(--theme-bg);
            }
            
            /* Only disable user select for interactive elements */
            button, .btn, [role="button"] {
              -webkit-user-select: none;
              user-select: none;
            }
            
            /* Ensure text is selectable in inputs and text areas */
            input, textarea {
              -webkit-user-select: text;
              user-select: text;
              color: var(--theme-text);
              background-color: var(--theme-secondary);
            }
            
            .pb-safe {
              padding-bottom: env(safe-area-inset-bottom);
            }
            
            .pt-safe {
              padding-top: env(safe-area-inset-top);
            }
          `}
        </style>
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        style={{
          backgroundColor: 'var(--theme-bg)',
          color: 'var(--theme-text)',
          margin: 0,
          padding: 0,
          minHeight: '100vh',
        }}
      >
        <ThemeProvider>
          <AnimationProvider>
            <SettingsProvider>
              <DataProvider>
                <CapacitorInit />
                <CSSParticles />
                <div className="relative z-10">
                  {children}
                </div>
                <FloatingCalendarButton />
                <Toaster />
              </DataProvider>
            </SettingsProvider>
          </AnimationProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
